package com.peseditor;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Paint;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class NomesProcessActivity extends BaseActivity {

    private static final int PICK_INPUT_FOLDER = 501;
    private static final int PICK_INPUT_ZIP = 502;
    private static final int PICK_OUTPUT_FOLDER = 503;

    private EditText edtPorcentagem;
    private TextView txtStatus;

    private Uri inputUri;
    private boolean inputIsZip = false;
    private Uri outputUri;

    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(18), dp(24), dp(18), dp(18));
        layout.setBackgroundColor(0xff101112);

        TextView titulo = new TextView(this);
        titulo.setText("NOMES");
        titulo.setTextSize(26);
        titulo.setTextColor(Color.WHITE);
        titulo.setTypeface(null, android.graphics.Typeface.BOLD);
        titulo.setPadding(0, 0, 0, 25);
        layout.addView(titulo);

        TextView explicacao = new TextView(this);
        explicacao.setText(
                "Redimensiona os nomes mantendo a posição original.\n\n" +
                "Escolha uma pasta com os PNGs ou um ZIP."
        );
        explicacao.setTextSize(16);
        layout.addView(explicacao);

        Button btnPasta = new Button(this);
        btnPasta.setText("SELECIONAR PASTA");
        styleButton(btnPasta);
        layout.addView(btnPasta);

        TextView lblPorcentagem = new TextView(this);
        lblPorcentagem.setText("\nPorcentagem (10–300):");
        lblPorcentagem.setTextSize(16);
        layout.addView(lblPorcentagem);

        edtPorcentagem = new EditText(this);
        styleEdit(edtPorcentagem);
        edtPorcentagem.setText("100");
        edtPorcentagem.setInputType(
                android.text.InputType.TYPE_CLASS_NUMBER
        );
        layout.addView(edtPorcentagem);

        Button btnProcessar = new Button(this);
        btnProcessar.setText("PROCESSAR NOMES");
        styleButton(btnProcessar);
        layout.addView(btnProcessar);

        txtStatus = new TextView(this);
        txtStatus.setText("\nNenhuma entrada selecionada.");
        txtStatus.setTextSize(15);
        layout.addView(txtStatus);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(layout);
        setContentView(scroll);

        btnPasta.setOnClickListener(v -> selecionarPastaEntrada());
        btnProcessar.setOnClickListener(v -> iniciarProcessamento());
    }

    private void selecionarPastaEntrada() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        );
        startActivityForResult(intent, PICK_INPUT_FOLDER);
    }

    private void selecionarZip() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(intent, PICK_INPUT_ZIP);
    }

    private void selecionarPastaSaida() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION |
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        );
        startActivityForResult(intent, PICK_OUTPUT_FOLDER);
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data
    ) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != RESULT_OK || data == null) return;

        Uri uri = data.getData();
        if (uri == null) return;

        if (requestCode == PICK_INPUT_FOLDER) {
            inputUri = uri;
            inputIsZip = false;
            txtStatus.setText("📁 Pasta de entrada selecionada.");
        } else if (requestCode == PICK_INPUT_ZIP) {
            inputUri = uri;
            inputIsZip = true;
            txtStatus.setText("📦 ZIP selecionado.");
        } else if (requestCode == PICK_OUTPUT_FOLDER) {
            outputUri = uri;
            txtStatus.setText("📂 Pasta de saída selecionada.");
            iniciarProcessamento();
        }
    }

    private void iniciarProcessamento() {
        if (inputUri == null) {
            Toast.makeText(
                    this,
                    "Selecione uma pasta ou ZIP primeiro.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        if (outputUri == null) {
            selecionarPastaSaida();
            return;
        }

        int porcentagem;

        try {
            porcentagem = Integer.parseInt(
                    edtPorcentagem.getText().toString().trim()
            );
        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "Porcentagem inválida.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        if (porcentagem < 10 || porcentagem > 300) {
            Toast.makeText(
                    this,
                    "Use uma porcentagem entre 10 e 300.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        final int escala = porcentagem;

        txtStatus.setText("⏳ Preparando...");

        new Thread(() -> {
            try {
                int total;
                int processados = 0;

                if (inputIsZip) {
                    total = processarZip(escala);
                } else {
                    total = processarPasta(inputUri, escala);
                }

                final int resultadoFinal = total;

                handler.post(() -> txtStatus.setText(
                        "====================================\n" +
                        "✅ CONCLUÍDO!\n" +
                        "====================================\n\n" +
                        "Porcentagem: " + escala + "%\n\n" +
                        "PNG processados: " + resultadoFinal + "\n\n" +
                        "Os resultados foram salvos na pasta escolhida."
                ));

            } catch (Exception e) {
                final String erro = e.getMessage() == null
                        ? e.toString()
                        : e.getMessage();

                handler.post(() -> txtStatus.setText(
                        "❌ ERRO:\n\n" + erro
                ));
            }
        }).start();
    }

    private int processarZip(int porcentagem) throws Exception {

        int processados = 0;

        InputStream raw = getContentResolver().openInputStream(inputUri);

        if (raw == null) {
            throw new Exception("Não foi possível abrir o ZIP.");
        }

        ZipInputStream zis = new ZipInputStream(
                new BufferedInputStream(raw)
        );

        ZipEntry entry;

        while ((entry = zis.getNextEntry()) != null) {

            if (entry.isDirectory()) {
                zis.closeEntry();
                continue;
            }

            String nome = entry.getName();

            if (!nome.toLowerCase().endsWith(".png")) {
                zis.closeEntry();
                continue;
            }

            String nomeArquivo = nome;

            int slash = nomeArquivo.lastIndexOf('/');
            if (slash >= 0) {
                nomeArquivo = nomeArquivo.substring(slash + 1);
            }

            if (nomeArquivo.startsWith("#")) {
                zis.closeEntry();
                continue;
            }

            ByteArrayOutputStream baos =
                    new ByteArrayOutputStream();

            byte[] buffer = new byte[8192];
            int n;

            while ((n = zis.read(buffer)) != -1) {
                baos.write(buffer, 0, n);
            }

            byte[] dados = baos.toByteArray();

            salvarResultado(
                    nomeArquivo,
                    dados,
                    porcentagem
            );

            processados++;

            final int atual = processados;

            handler.post(() -> txtStatus.setText(
                    "⏳ Processando...\n\n" +
                    "Arquivos processados: " + atual
            ));

            zis.closeEntry();
        }

        zis.close();

        return processados;
    }

    private int processarPasta(
            Uri treeUri,
            int porcentagem
    ) throws Exception {

        List<Uri> arquivos = new ArrayList<>();

        listarPngs(treeUri, arquivos);

        int processados = 0;

        for (Uri arquivo : arquivos) {

            String nome = obterNome(arquivo);

            if (nome.startsWith("#")) {
                continue;
            }

            InputStream in =
                    getContentResolver().openInputStream(arquivo);

            if (in == null) continue;

            ByteArrayOutputStream baos =
                    new ByteArrayOutputStream();

            byte[] buffer = new byte[8192];
            int n;

            while ((n = in.read(buffer)) != -1) {
                baos.write(buffer, 0, n);
            }

            in.close();

            salvarResultado(
                    nome,
                    baos.toByteArray(),
                    porcentagem
            );

            processados++;

            final int atual = processados;

            handler.post(() -> txtStatus.setText(
                    "⏳ Processando...\n\n" +
                    "Arquivos processados: " + atual
            ));
        }

        return processados;
    }

    private void listarPngs(
            Uri treeUri,
            List<Uri> resultado
    ) {

        String documentId =
                DocumentsContract.getTreeDocumentId(treeUri);

        Uri childrenUri =
                DocumentsContract.buildChildDocumentsUriUsingTree(
                        treeUri,
                        documentId
                );

        android.database.Cursor cursor = getContentResolver()
                .query(
                        childrenUri,
                        new String[]{
                                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                                DocumentsContract.Document.COLUMN_MIME_TYPE
                        },
                        null,
                        null,
                        null
                );

        if (cursor == null) return;

        try {

            while (cursor.moveToNext()) {

                String id = cursor.getString(0);
                String nome = cursor.getString(1);
                String mime = cursor.getString(2);

                Uri childUri =
                        DocumentsContract.buildDocumentUriUsingTree(
                                treeUri,
                                id
                        );

                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {

                    listarPngs(childUri, resultado);

                } else if (
                        nome != null &&
                        nome.toLowerCase().endsWith(".png")
                ) {

                    resultado.add(childUri);
                }
            }

        } finally {
            cursor.close();
        }
    }

    private void salvarResultado(
            String nomeArquivo,
            byte[] dados,
            int porcentagem
    ) throws Exception {

        Bitmap imagem = BitmapFactory.decodeByteArray(
                dados,
                0,
                dados.length
        );

        if (imagem == null) {
            return;
        }

        imagem = imagem.copy(
                Bitmap.Config.ARGB_8888,
                false
        );

        int largura = imagem.getWidth();
        int altura = imagem.getHeight();

        int esquerda = largura;
        int topo = altura;
        int direita = 0;
        int baixo = 0;

        boolean encontrou = false;

        int[] pixels = new int[largura * altura];
        imagem.getPixels(
                pixels,
                0,
                largura,
                0,
                0,
                largura,
                altura
        );

        for (int y = 0; y < altura; y++) {

            for (int x = 0; x < largura; x++) {

                int alpha =
                        Color.alpha(pixels[y * largura + x]);

                if (alpha > 0) {

                    encontrou = true;

                    if (x < esquerda) esquerda = x;
                    if (y < topo) topo = y;
                    if (x + 1 > direita) direita = x + 1;
                    if (y + 1 > baixo) baixo = y + 1;
                }
            }
        }

        if (!encontrou) {
            imagem.recycle();
            return;
        }

        int larguraNome = direita - esquerda;
        int alturaNome = baixo - topo;

        int novaLargura = Math.max(
                1,
                Math.round(
                        larguraNome * porcentagem / 100f
                )
        );

        int novaAltura = Math.max(
                1,
                Math.round(
                        alturaNome * porcentagem / 100f
                )
        );

        Bitmap recorte = Bitmap.createBitmap(
                imagem,
                esquerda,
                topo,
                larguraNome,
                alturaNome
        );

        Bitmap redimensionado =
                Bitmap.createScaledBitmap(
                        recorte,
                        novaLargura,
                        novaAltura,
                        true
                );

        float centroX =
                (esquerda + direita) / 2f;

        float centroY =
                (topo + baixo) / 2f;

        int novaEsquerda = Math.round(
                centroX - novaLargura / 2f
        );

        int novaTopo = Math.round(
                centroY - novaAltura / 2f
        );

        Bitmap resultado = Bitmap.createBitmap(
                largura,
                altura,
                Bitmap.Config.ARGB_8888
        );

        resultado.eraseColor(Color.TRANSPARENT);

        Canvas canvas = new Canvas(resultado);

        Paint paint = new Paint(
                Paint.ANTI_ALIAS_FLAG |
                Paint.FILTER_BITMAP_FLAG
        );

        canvas.drawBitmap(
                redimensionado,
                novaEsquerda,
                novaTopo,
                paint
        );

        Uri arquivoSaida =
                criarArquivoSaida(nomeArquivo);

        OutputStream out =
                getContentResolver().openOutputStream(
                        arquivoSaida
                );

        if (out == null) {
            throw new Exception(
                    "Não foi possível criar: " + nomeArquivo
            );
        }

        BufferedOutputStream bos =
                new BufferedOutputStream(out);

        resultado.compress(
                Bitmap.CompressFormat.PNG,
                100,
                bos
        );

        bos.flush();
        bos.close();

        imagem.recycle();
        recorte.recycle();
        redimensionado.recycle();
        resultado.recycle();
    }

    private Uri criarArquivoSaida(
            String nomeArquivo
    ) throws Exception {

        String documentId =
                DocumentsContract.getTreeDocumentId(outputUri);

        Uri parentDocumentUri =
                DocumentsContract.buildDocumentUriUsingTree(
                        outputUri,
                        documentId
                );

        Uri childrenUri =
                DocumentsContract.buildChildDocumentsUriUsingTree(
                        outputUri,
                        documentId
                );

        Uri existente = null;

        android.database.Cursor cursor =
                getContentResolver().query(
                        childrenUri,
                        new String[]{
                                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                                DocumentsContract.Document.COLUMN_DISPLAY_NAME
                        },
                        null,
                        null,
                        null
                );

        if (cursor != null) {

            try {

                while (cursor.moveToNext()) {

                    String id = cursor.getString(0);
                    String nome = cursor.getString(1);

                    if (nomeArquivo.equals(nome)) {

                        existente =
                                DocumentsContract.buildDocumentUriUsingTree(
                                        outputUri,
                                        id
                                );

                        break;
                    }
                }

            } finally {
                cursor.close();
            }
        }

        if (existente != null) {
            return existente;
        }

        return DocumentsContract.createDocument(
                getContentResolver(),
                parentDocumentUri,
                "image/png",
                nomeArquivo
        );
    }

    private String obterNome(Uri uri) {

        android.database.Cursor cursor =
                getContentResolver().query(
                        uri,
                        new String[]{
                                DocumentsContract.Document.COLUMN_DISPLAY_NAME
                        },
                        null,
                        null,
                        null
                );

        if (cursor != null) {

            try {

                if (cursor.moveToFirst()) {
                    return cursor.getString(0);
                }

            } finally {
                cursor.close();
            }
        }

        return "arquivo.png";
    }
    private void styleButton(Button b) {
        b.setTextSize(15);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackground(round(0xff242629, 14, 0xff3a3d42));
        b.setPadding(dp(16), 0, dp(16), 0);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(58));
        p.topMargin = dp(8);
        p.bottomMargin = dp(8);
        b.setLayoutParams(p);
    }

    private void styleEdit(EditText e) {
        e.setTextColor(Color.WHITE);
        e.setTextSize(18);
        e.setPadding(dp(14), 0, dp(14), 0);
        e.setBackground(round(0xff191b1d, 12, 0xff3a3d42));
        e.setMinHeight(dp(54));
    }

    private GradientDrawable round(int fill, int radius, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radius));
        g.setStroke(dp(1), stroke);
        return g;
    }

    private int dp(int n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }

}
