package com.psp.facehaireditor;
import android.graphics.Bitmap;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import java.nio.*;
import java.util.*;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** Draws directly to a GLSurfaceView. No glReadPixels and no GPU->Canvas copies. */
public final class DirectGpuRenderer implements GLSurfaceView.Renderer {
  static final class Batch { final float[] data; final Bitmap texture;
    Batch(float[] d,Bitmap t){data=d;texture=t;} }
  private volatile List<Batch> scene=Collections.emptyList();
  private volatile List<Batch> previewScene=Collections.emptyList();
  private volatile int previewHeight=0, previewTop=0;
  public void setPreview(List<Batch> batches,int height,int top,GLSurfaceView surface){
    previewScene=batches==null?Collections.emptyList():batches;
    previewHeight=batches==null?0:Math.max(1,height);
    previewTop=Math.max(0,top);
    if(surface!=null)surface.requestRender();
  }
  private volatile int bg=0xff555555;
  private volatile int visibleHeight=0; private volatile int surfaceWidth=1,surfaceHeight=1;
  public void setVisibleHeight(int h){visibleHeight=Math.max(1,h);}
  private int program, matrixUnused, sampler, textured, tint;
  private volatile float[] backdropLines=new float[0]; private volatile int[] backdropColors=new int[0]; private volatile float[] backdropWidths=new float[0];
  private final IdentityHashMap<Bitmap,Integer> textureIds=new IdentityHashMap<>();
  // Buffer direto reutilizavel: evita alocar memoria nativa a cada frame e por malha.
  private FloatBuffer reusableBuffer;
  private FloatBuffer bufferFor(int floatCount){
    if(reusableBuffer==null||reusableBuffer.capacity()<floatCount){int cap=Math.max(floatCount,reusableBuffer==null?1024:reusableBuffer.capacity()*2);reusableBuffer=ByteBuffer.allocateDirect(cap*4).order(ByteOrder.nativeOrder()).asFloatBuffer();}
    reusableBuffer.clear();return reusableBuffer;
  }
  private static final String VS="#version 300 es\nlayout(location=0) in vec3 pos;layout(location=1) in vec2 uv;out vec2 texUV;void main(){gl_Position=vec4(pos,1.0);texUV=uv;}";
  private static final String FS="#version 300 es\nprecision mediump float;in vec2 texUV;uniform sampler2D tex;uniform int hasTex;uniform vec4 lineColor;out vec4 frag;void main(){frag=hasTex==2?lineColor:(hasTex==1?texture(tex,texUV):vec4(1.0));if(frag.a<0.01)discard;}";
  public void update(List<Batch> batches,int color,GLSurfaceView surface,int w,int h,float cx,float cy,boolean grid,float spacing,int gridColor,int gridOpacity,int horizontalColor,int verticalColor,int axisIntensity,float axisWidth){
    scene=batches;bg=color;visibleHeight=Math.max(1,h);
    ArrayList<Float> vertices=new ArrayList<>();ArrayList<Integer> colors=new ArrayList<>();ArrayList<Float> widths=new ArrayList<>();
    if(w>0&&h>0){
      if(grid&&spacing>=1){
        int col=(gridColor&0x00ffffff)|((Math.max(0,Math.min(100,gridOpacity))*255/100)<<24);
        for(float x=cx%spacing;x<w;x+=spacing)addLine(vertices,colors,widths,x,0,x,h,w,h,col,1f);
        for(float y=cy%spacing;y<h;y+=spacing)addLine(vertices,colors,widths,0,y,w,y,w,h,col,1f);
      }
      int a=Math.max(0,Math.min(100,axisIntensity))*255/100;
      addLine(vertices,colors,widths,0,cy,w,cy,w,h,(horizontalColor&0xffffff)|(a<<24),axisWidth);
      addLine(vertices,colors,widths,cx,0,cx,h,w,h,(verticalColor&0xffffff)|(a<<24),axisWidth);
    }
    float[] lines=new float[vertices.size()];for(int i=0;i<lines.length;i++)lines[i]=vertices.get(i);
    int[] cols=new int[colors.size()];float[] thick=new float[widths.size()];for(int i=0;i<cols.length;i++){cols[i]=colors.get(i);thick[i]=widths.get(i);}
    backdropLines=lines;backdropColors=cols;backdropWidths=thick;
    if(surface!=null)surface.requestRender();
  }
  private static void addLine(ArrayList<Float> out,ArrayList<Integer> colors,ArrayList<Float> widths,float x1,float y1,float x2,float y2,int w,int h,int color,float width){
    float[] a={2*x1/w-1,1-2*y1/h,0.99f,0,0,2*x2/w-1,1-2*y2/h,0.99f,0,0};for(float f:a)out.add(f);colors.add(color);widths.add(width);
  }
  private int shader(int kind,String source){int id=GLES30.glCreateShader(kind);GLES30.glShaderSource(id,source);GLES30.glCompileShader(id);int[] ok=new int[1];GLES30.glGetShaderiv(id,GLES30.GL_COMPILE_STATUS,ok,0);if(ok[0]==0)throw new IllegalStateException(GLES30.glGetShaderInfoLog(id));return id;}
  public void onSurfaceCreated(GL10 unused,EGLConfig config){textureIds.clear();int v=shader(GLES30.GL_VERTEX_SHADER,VS),f=shader(GLES30.GL_FRAGMENT_SHADER,FS);program=GLES30.glCreateProgram();GLES30.glAttachShader(program,v);GLES30.glAttachShader(program,f);GLES30.glLinkProgram(program);GLES30.glDeleteShader(v);GLES30.glDeleteShader(f);sampler=GLES30.glGetUniformLocation(program,"tex");textured=GLES30.glGetUniformLocation(program,"hasTex");tint=GLES30.glGetUniformLocation(program,"lineColor");GLES30.glEnable(GLES30.GL_DEPTH_TEST);GLES30.glDepthFunc(GLES30.GL_LEQUAL);}
  public void onSurfaceChanged(GL10 unused,int w,int h){surfaceWidth=w;surfaceHeight=h;GLES30.glViewport(0,0,w,h);}
  public void onDrawFrame(GL10 unused){int c=bg;GLES30.glClearColor(((c>>16)&255)/255f,((c>>8)&255)/255f,(c&255)/255f,1);GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT|GLES30.GL_DEPTH_BUFFER_BIT);
    int visible=Math.max(1,Math.min(surfaceHeight,visibleHeight));
    GLES30.glViewport(0,surfaceHeight-visible,surfaceWidth,visible);
    GLES30.glUseProgram(program);GLES30.glActiveTexture(GLES30.GL_TEXTURE0);GLES30.glUniform1i(sampler,0);
    float[] lines=backdropLines;int[] cols=backdropColors;float[] widths=backdropWidths;
    if(lines.length>0){
      GLES30.glDisable(GLES30.GL_DEPTH_TEST);GLES30.glEnable(GLES30.GL_BLEND);GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA,GLES30.GL_ONE_MINUS_SRC_ALPHA);
      GLES30.glUniform1i(textured,2);
      FloatBuffer lineBuf=bufferFor(lines.length);lineBuf.put(lines).position(0);
      GLES30.glEnableVertexAttribArray(0);GLES30.glEnableVertexAttribArray(1);
      lineBuf.position(0);GLES30.glVertexAttribPointer(0,3,GLES30.GL_FLOAT,false,20,lineBuf);
      lineBuf.position(3);GLES30.glVertexAttribPointer(1,2,GLES30.GL_FLOAT,false,20,lineBuf);
      for(int i=0;i<cols.length;i++){int color=cols[i];GLES30.glUniform4f(tint,((color>>16)&255)/255f,((color>>8)&255)/255f,(color&255)/255f,((color>>>24)&255)/255f);GLES30.glLineWidth(Math.max(1f,widths[i]));GLES30.glDrawArrays(GLES30.GL_LINES,i*2,2);}
      GLES30.glDisableVertexAttribArray(0);GLES30.glDisableVertexAttribArray(1);GLES30.glEnable(GLES30.GL_DEPTH_TEST);
    }
    List<Batch> upper=scene;
    drawBatches(upper);
    List<Batch> lower=previewScene;
    int lowerHeight=previewHeight;
    if(lowerHeight>0 && !lower.isEmpty()){
      int y=Math.max(0,surfaceHeight-previewTop-lowerHeight);
      int height=Math.min(lowerHeight,surfaceHeight-y);
      if(height>0){
        GLES30.glEnable(GLES30.GL_SCISSOR_TEST);
        GLES30.glScissor(0,y,surfaceWidth,height);
        int back=bg;
        GLES30.glClearColor(((back>>16)&255)/255f,((back>>8)&255)/255f,(back&255)/255f,1);
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT|GLES30.GL_DEPTH_BUFFER_BIT);
        GLES30.glViewport(0,y,surfaceWidth,height);
        drawBatches(lower);
        GLES30.glDisable(GLES30.GL_SCISSOR_TEST);
      }
    }
    // Every drag can produce a new 1024x1024 atlas. Release GL textures
    // not referenced by the currently rendered main/preview batches.
    // This runs only on the GL thread, where glDeleteTextures is safe.
    IdentityHashMap<Bitmap,Boolean> active=new IdentityHashMap<>();
    for(Batch b:upper)if(b.texture!=null)active.put(b.texture,Boolean.TRUE);
    for(Batch b:lower)if(b.texture!=null)active.put(b.texture,Boolean.TRUE);
    Iterator<Map.Entry<Bitmap,Integer>> it=textureIds.entrySet().iterator();
    while(it.hasNext()){
      Map.Entry<Bitmap,Integer> e=it.next();
      if(!active.containsKey(e.getKey())){
        int[] old={e.getValue()};
        GLES30.glDeleteTextures(1,old,0);
        it.remove();
      }
    }
  }
  private void drawBatches(List<Batch> batches){
    GLES30.glEnable(GLES30.GL_DEPTH_TEST);
    for(Batch batch:batches){if(batch.data.length<15)continue;
      if(batch.texture!=null&&!batch.texture.isRecycled()){
        Integer id=textureIds.get(batch.texture);if(id==null){int[] ids=new int[1];GLES30.glGenTextures(1,ids,0);id=ids[0];GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,id);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MIN_FILTER,GLES30.GL_LINEAR);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MAG_FILTER,GLES30.GL_LINEAR);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_WRAP_S,GLES30.GL_CLAMP_TO_EDGE);GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_WRAP_T,GLES30.GL_CLAMP_TO_EDGE);GLUtils.texImage2D(GLES30.GL_TEXTURE_2D,0,batch.texture,0);textureIds.put(batch.texture,id);}else GLES30.glBindTexture(GLES30.GL_TEXTURE_2D,id);
        GLES30.glUniform1i(textured,1);GLES30.glEnable(GLES30.GL_BLEND);GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA,GLES30.GL_ONE_MINUS_SRC_ALPHA);
      }else{GLES30.glUniform1i(textured,0);GLES30.glDisable(GLES30.GL_BLEND);}
      FloatBuffer buf=bufferFor(batch.data.length);buf.put(batch.data).position(0);GLES30.glEnableVertexAttribArray(0);GLES30.glEnableVertexAttribArray(1);buf.position(0);GLES30.glVertexAttribPointer(0,3,GLES30.GL_FLOAT,false,20,buf);buf.position(3);GLES30.glVertexAttribPointer(1,2,GLES30.GL_FLOAT,false,20,buf);GLES30.glDrawArrays(GLES30.GL_TRIANGLES,0,batch.data.length/5);GLES30.glDisableVertexAttribArray(0);GLES30.glDisableVertexAttribArray(1);
    }
  }

}
