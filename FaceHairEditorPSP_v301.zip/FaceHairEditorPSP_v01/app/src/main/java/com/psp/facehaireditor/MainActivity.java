package com.psp.facehaireditor;

import android.app.*;import android.os.*;import android.os.Environment;import android.provider.Settings;import android.content.*;import android.graphics.*;import android.net.Uri;import android.provider.DocumentsContract;import android.database.Cursor;import android.view.*;import android.view.inputmethod.InputMethodManager;import android.view.inputmethod.EditorInfo;import android.widget.*;
import java.io.*;import java.nio.*;import java.nio.charset.StandardCharsets;import java.util.*;import java.util.zip.*;

public class MainActivity extends Activity {
  static final int OPEN_BIN=1,OPEN_OBJ=2,SAVE_OBJ=3,SAVE_BIN=4,OPEN_HAIR_BIN=5,OPEN_HAIR_OBJ=6,SAVE_HAIR_BIN=7,SAVE_HAIR_OBJ=8,CHOOSE_FACE_BIN=9,CHOOSE_HAIR_BIN=10,FACE_TEXTURE=11,HAIR_TEXTURE=12,GRANT_TEXTURE_FOLDER=13,GRANT_ALL_FILES=14,UV_OPEN_IMAGE=15,UV_REPLACE_IMAGE=16,REFERENCE_IMAGE=17,IMPORT_CFG=18,EXPORT_CFG=19,EXPORT_PHOTO_UV=20,COLOR_BASE_IMAGE=21,UV_SWAP_SKIN=22,UV_SAVE_COMPOSITE=23;
  Bitmap uvBaseFace,uvBaseHair,uvLayerFace,uvLayerHair; int uvRed=100,uvGreen=100,uvBlue=100,uvBright=0,uvContrast=100,uvOpacity=100; boolean uvMatchSkin=false;
  Bitmap colorBaseImage; boolean useColorBase=false; boolean matchBaseBrightness=true; int baseBrightnessStrength=100;
  Mesh mesh=new Mesh(); ModelView view; TextView status; byte[] originalBin, decoded; ArrayList<Integer> offsets=new ArrayList<>();
  Mesh faceMesh=mesh, hairMesh=new Mesh(); Bitmap faceTexture,hairTexture;
  byte[] faceOriginal,faceDecoded,hairOriginal,hairDecoded;
  ArrayList<Integer> faceOffsets=new ArrayList<>(),hairOffsets=new ArrayList<>();
  boolean activeHair=false,faceVisible=true,hairVisible=true,faceVertices=true,hairVertices=true;
  boolean highlightSelectedEdges=false; int selectedEdgeColor=0xffffa500;
  // Additional objects keep independent geometry, BIN buffers and texture.
  static class ExtraObject {
    Mesh mesh; byte[] original,decoded; ArrayList<Integer> offsets;
    Bitmap texture; Uri source; boolean visible=true,wire=true,uvWire=true; String name;
  }
  final ArrayList<ExtraObject> extraFaces=new ArrayList<>(),extraHairs=new ArrayList<>();
  int faceIndex=0,hairIndex=0; // 0 is the original Face/Hair slot
  final ArrayList<String> faceNames=new ArrayList<>(),hairNames=new ArrayList<>();
  ArrayList<String> objectNames(boolean hair){return hair?hairNames:faceNames;}
  void syncObjectNames(boolean hair){
    ArrayList<String> names=objectNames(hair);
    int count=extras(hair).size();
    while(names.size()<count)names.add((hair?"Hair ":"Face ")+(names.size()+1));
    while(names.size()>count)names.remove(names.size()-1);
  }
  void renameObject(boolean hair,int index){
    syncObjectNames(hair);
    final int navy=0xff142238, surface=0xff20334b, border=0xff40546b;
    LinearLayout panel=new LinearLayout(this);
    panel.setOrientation(LinearLayout.VERTICAL);
    panel.setPadding(dp(16),dp(15),dp(16),dp(13));
    panel.setBackground(roundRect(navy,border,dp(10),dp(1)));
    TextView title=label("Renomear objeto",16);
    title.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
    panel.addView(title);
    EditText field=new EditText(this);
    field.setSingleLine(true);
    field.setTextSize(14);
    field.setTextColor(0xfff0f5ff);
    field.setHintTextColor(0xff9daec5);
    field.setSelectAllOnFocus(true);
    field.setText(objectNames(hair).get(index));
    field.setPadding(dp(11),0,dp(11),0);
    field.setBackground(roundRect(surface,border,dp(6),dp(1)));
    LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,dp(42));
    fp.topMargin=dp(15);panel.addView(field,fp);
    LinearLayout actions=new LinearLayout(this);
    actions.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);
    LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(36));
    ap.topMargin=dp(16);panel.addView(actions,ap);
    TextView cancel=label("Cancelar",12);
    cancel.setGravity(Gravity.CENTER);
    cancel.setBackground(roundRect(surface,border,dp(6),dp(1)));
    LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(88),dp(34));
    cp.rightMargin=dp(8);actions.addView(cancel,cp);
    TextView save=label("Salvar",12);
    save.setGravity(Gravity.CENTER);
    save.setBackground(roundRect(0xff0878df,0xff0878df,dp(6),dp(1)));
    actions.addView(save,new LinearLayout.LayoutParams(dp(78),dp(34)));
    AlertDialog dialog=new AlertDialog.Builder(this).create();
    dialog.setView(panel,0,0,0,0);
    cancel.setOnClickListener(v->dialog.dismiss());
    save.setOnClickListener(v->{
      String name=field.getText().toString().trim();
      if(name.isEmpty()){field.setError("Digite um nome");return;}
      objectNames(hair).set(index,name);
      refreshObjects();dialog.dismiss();
    });
    dialog.getWindow();
    dialog.show();
    android.view.Window window=dialog.getWindow();
    if(window!=null){window.setBackgroundDrawableResource(android.R.color.transparent);window.setLayout(dp(290),-2);}
  }
  ArrayList<ExtraObject> extras(boolean hair){return hair?extraHairs:extraFaces;}
  int objectIndex(boolean hair){return hair?hairIndex:faceIndex;}
  void setObjectIndex(boolean hair,int index){if(hair)hairIndex=index;else faceIndex=index;}
  ExtraObject snapshot(boolean hair){
    ExtraObject o=new ExtraObject();o.mesh=hair?hairMesh:faceMesh;
    o.original=hair?hairOriginal:faceOriginal;o.decoded=hair?hairDecoded:faceDecoded;
    o.offsets=new ArrayList<>(hair?hairOffsets:faceOffsets);
    o.texture=hair?hairTexture:faceTexture;
    o.source=hair?pendingHairBin:pendingFaceBin;
    o.visible=hair?hairVisible:faceVisible;o.wire=hair?hairWireVisible:faceWireVisible;o.uvWire=hair?hairUvWireVisible:faceUvWireVisible;
    return o;
  }
  void restore(boolean hair,ExtraObject o){
    if(hair){hairMesh=o.mesh;hairOriginal=o.original;hairDecoded=o.decoded;hairOffsets=new ArrayList<>(o.offsets);
      hairTexture=o.texture;pendingHairBin=o.source;hairVisible=o.visible;hairWireVisible=o.wire;hairUvWireVisible=o.uvWire;}
    else{faceMesh=o.mesh;faceOriginal=o.original;faceDecoded=o.decoded;faceOffsets=new ArrayList<>(o.offsets);
      faceTexture=o.texture;pendingFaceBin=o.source;faceVisible=o.visible;faceWireVisible=o.wire;faceUvWireVisible=o.uvWire;}
    if(activeHair==hair){mesh=o.mesh;originalBin=o.original;decoded=o.decoded;offsets=new ArrayList<>(o.offsets);}
  }
  // Each category has one live slot and a list of parked slots. Index 0 is
  // always the live slot; switching exchanges it with the requested parked slot.
  void ensureSlots(boolean hair){
    if(extras(hair).isEmpty())extras(hair).add(null);
  }
  void selectExtra(boolean hair,int index){
    if(activeHair!=hair)switchObject(hair);
    if(index==objectIndex(hair))return;
    syncActive();ensureSlots(hair);
    ArrayList<ExtraObject> list=extras(hair);
    list.set(objectIndex(hair),snapshot(hair));
    ExtraObject target=list.get(index);
    if(target==null)return;
    restore(hair,target);setObjectIndex(hair,index);list.set(index,null);
    undo.clear();redo.clear();undoBinSplits.clear();redoBinSplits.clear();undoSelection.clear();redoSelection.clear();view.selected.clear();refreshObjects();view.invalidate();
    status.setText((hair?"Hair ":"Face ")+(index+1)+": "+mesh.vertices.size()+" vértices");
  }
  void beginNewObject(boolean hair){
    if(activeHair!=hair)switchObject(hair);
    syncActive();ensureSlots(hair);
    ArrayList<ExtraObject> list=extras(hair);
    if(!mesh.vertices.isEmpty()){
      syncObjectNames(hair);
      list.set(objectIndex(hair),snapshot(hair));
      list.add(null);setObjectIndex(hair,list.size()-1);
      syncObjectNames(hair);
    }
    ExtraObject fresh=new ExtraObject();fresh.mesh=new Mesh();fresh.offsets=new ArrayList<>();
    fresh.visible=true;fresh.wire=true;
    restore(hair,fresh);
    undo.clear();redo.clear();undoBinSplits.clear();redoBinSplits.clear();undoSelection.clear();redoSelection.clear();view.selected.clear();
  }
  void removeExtra(boolean hair,int index){
    // Keep the BIN selected in the file panel when deleting its 3D object.
    Uri selectedBinBeforeDelete=hair?pendingHairBin:pendingFaceBin;
    ensureSlots(hair);syncObjectNames(hair);
    if(index>=0&&index<objectNames(hair).size())objectNames(hair).remove(index);
    ArrayList<ExtraObject> list=extras(hair);
    if(index==objectIndex(hair)){
      if(activeHair!=hair)switchObject(hair);
      ExtraObject fresh=new ExtraObject();fresh.mesh=new Mesh();fresh.offsets=new ArrayList<>();
      restore(hair,fresh);undo.clear();redo.clear();undoBinSplits.clear();redoBinSplits.clear();undoSelection.clear();redoSelection.clear();view.selected.clear();
      if(list.size()>1){
        int next=index==0?1:0;
        ExtraObject target=list.get(next);
        list.remove(index);setObjectIndex(hair,next>index?next-1:next);
        restore(hair,target);list.set(objectIndex(hair),null);
      }
    }else{
      list.remove(index);
      if(objectIndex(hair)>index)setObjectIndex(hair,objectIndex(hair)-1);
    }
    // restore() loads object snapshots, whose source can be null. Deleting a
    // mesh must not clear the BIN selected for subsequent re-import.
    if(hair)pendingHairBin=selectedBinBeforeDelete;
    else pendingFaceBin=selectedBinBeforeDelete;
    syncObjectNames(hair);
    refreshObjects();view.invalidate();
  }
  LinearLayout objectList; Uri pendingFaceBin,pendingHairBin; boolean awaitingHairTexture=false; TextView faceFileLabel,hairFileLabel;
  int blue=Color.rgb(35,120,225); int objExportMode=0;
  final ArrayList<Mesh> undo=new ArrayList<>(),redo=new ArrayList<>();
  LinearLayout panel, panelBody, referencePanel, referenceBody; boolean referenceShown=false; FrameLayout stage; Analog analog; DirectionPad directionPad; View directionTool; boolean uvNavigationFocus=false; boolean panelShown=false; int navigationSize=100, navigationSensitivity=100; int analogNavigationColor=0xff2691f0, directionNavigationColor=0xffaaaaaa; int navigationMode=0;
  TextView orientationLabel;
  android.opengl.GLSurfaceView gpuSurface; final DirectGpuRenderer gpuRenderer=new DirectGpuRenderer(); boolean gpuEnabled=true; LinearLayout viewportSplit; View uvDivider; UVView uvView; ModelView previewView; boolean previewEnabled=false; boolean previewPhotoMode=true; boolean previewSolidMode=false; boolean uvEnabled=false; boolean uvDirty=false; float uvRatio=.5f; Bitmap uvPreviewTexture; boolean uvImageCleared=false; LinearLayout uvBottomControls; View zoomPlus,zoomMinus;
  View wireframeTool, solidTool, frontTool, sideTool, rearTool, centerTool, analogTool, fileTab;
  static final int HAIR_ALPHA_BLEND=0, HAIR_ALPHA_CLIP=1, HAIR_OPAQUE=2;
  int hairAlphaMode=HAIR_ALPHA_BLEND;
  void loadHairAlphaMode(){hairAlphaMode=getSharedPreferences("editor_hair",MODE_PRIVATE).getInt("alpha_mode",HAIR_ALPHA_BLEND);}
  void setHairAlphaMode(int mode){
    hairAlphaMode=mode;
    getSharedPreferences("editor_hair",MODE_PRIVATE).edit().putInt("alpha_mode",mode).apply();
    if(view!=null)view.invalidate();
  }
  boolean gridVisible=true;
  int gridSpacingDp=24,gridOpacity=35;
  int gridLineColor=0xff738092;
  int viewportBackgroundColor=0, viewportHorizontalColor=0xff75404b, viewportVerticalColor=0xff34714d;
  int viewportAxisThickness=10, viewportAxisIntensity=100;
  void loadViewportColors(){
    android.content.SharedPreferences prefs=getSharedPreferences("editor_viewport_colors",MODE_PRIVATE);
    viewportBackgroundColor=prefs.getInt("background",blenderTheme?0xff646464:0xff111a27);
    viewportHorizontalColor=prefs.getInt("horizontal",0xff75404b);
    viewportVerticalColor=prefs.getInt("vertical",0xff34714d);
    viewportAxisThickness=prefs.getInt("axis_thickness",10);
    viewportAxisIntensity=Math.max(0,Math.min(100,prefs.getInt("axis_intensity",100)));
  }
  void setViewportColor(int which,int color){
    String key=which==0?"background":which==1?"horizontal":"vertical";
    if(which==0)viewportBackgroundColor=color;
    else if(which==1)viewportHorizontalColor=color;
    else viewportVerticalColor=color;
    getSharedPreferences("editor_viewport_colors",MODE_PRIVATE).edit().putInt(key,color).apply();
    if(view!=null){if(which==0)view.setBackgroundColor(viewportBackgroundColor);view.invalidate();}
  }
  void chooseViewportColor(int which){
    final String[] names={"Branco","Preto","Vermelho","Azul","Verde","Amarelo","Laranja"};
    final int[] colors={0xfff0f2f5,0xff161616,0xffff4545,0xff439cff,0xff36dc88,0xffffdd44,0xffff9933};
    final int old=which==0?viewportBackgroundColor:which==1?viewportHorizontalColor:viewportVerticalColor;
    LinearLayout layout=new LinearLayout(this);layout.setOrientation(1);layout.setPadding(dp(12),dp(10),dp(12),dp(10));layout.setBackgroundColor(PANEL_DARK);
    android.app.Dialog dialog=new android.app.Dialog(this);
    for(int row=0;row<4;row++){
      LinearLayout line=new LinearLayout(this);layout.addView(line,new LinearLayout.LayoutParams(-1,dp(45)));
      for(int col=0;col<2;col++){
        int i=row*2+col;if(i>=colors.length)break;
        LinearLayout cell=new LinearLayout(this);cell.setGravity(Gravity.CENTER_VERTICAL);cell.setPadding(dp(7),0,dp(4),0);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-1,1);cp.setMargins(dp(2),dp(2),dp(2),dp(2));line.addView(cell,cp);
        cell.setBackground(roundRect((old&0xffffff)==(colors[i]&0xffffff)?0xff294c72:TOOL,0xff40546b,dp(5),dp(1)));
        TextView dot=label("●",19);dot.setTextColor(colors[i]);cell.addView(dot);
        TextView name=label(" "+names[i],12);cell.addView(name);
        final int chosen=colors[i];cell.setOnClickListener(v->{setViewportColor(which,chosen);dialog.dismiss();});
      }
    }
    TextView custom=label("◉  Cor personalizada",13);custom.setGravity(Gravity.CENTER);custom.setPadding(dp(8),dp(12),dp(8),dp(12));
    custom.setBackground(roundRect(TOOL,0xff40546b,dp(5),dp(1)));layout.addView(custom);
    custom.setOnClickListener(v->{dialog.dismiss();EditText hex=new EditText(this);hex.setSingleLine(true);hex.setHint("#RRGGBB");hex.setText(String.format(java.util.Locale.US,"#%06X",old&0xffffff));
      new AlertDialog.Builder(this).setTitle("Cor personalizada").setView(hex).setPositiveButton("Aplicar",(d,w)->{try{setViewportColor(which,Color.parseColor(hex.getText().toString().trim()));}catch(Exception ex){toast("Use uma cor no formato #RRGGBB");}}).setNegativeButton("Cancelar",null).show();});
    dialog.setContentView(layout);dialog.show();android.view.Window window=dialog.getWindow();if(window!=null){window.setBackgroundDrawableResource(android.R.color.transparent);window.setLayout(dp(260),-2);}
  }
  void settingsViewportColors(LinearLayout parent){
    LinearLayout group=new LinearLayout(this);group.setOrientation(LinearLayout.VERTICAL);
    group.setPadding(dp(5),dp(6),dp(5),dp(6));
    LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,-2);
    gp.setMargins(0,dp(5),0,dp(7));parent.addView(group,gp);
    TextView thicknessLabel=label("Espessura das linhas: "+(viewportAxisThickness/10f)+" dp",12);
    group.addView(thicknessLabel);
    SeekBar thickness=new SeekBar(this);thickness.setMax(45);thickness.setProgress(Math.max(0,viewportAxisThickness-5));
    group.addView(thickness,new LinearLayout.LayoutParams(-1,dp(34)));
    thickness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
      public void onProgressChanged(SeekBar bar,int progress,boolean user){if(user){viewportAxisThickness=progress+5;thicknessLabel.setText("Espessura das linhas: "+(viewportAxisThickness/10f)+" dp");saveViewportAxisStyle();}}
      public void onStartTrackingTouch(SeekBar bar){}public void onStopTrackingTouch(SeekBar bar){}
    });
    TextView intensityLabel=label("Intensidade das linhas: "+viewportAxisIntensity+"%",12);
    group.addView(intensityLabel);
    SeekBar intensity=new SeekBar(this);intensity.setMax(100);intensity.setProgress(Math.min(100,viewportAxisIntensity));
    group.addView(intensity,new LinearLayout.LayoutParams(-1,dp(34)));
    intensity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
      public void onProgressChanged(SeekBar bar,int progress,boolean user){if(user){viewportAxisIntensity=progress;intensityLabel.setText("Intensidade das linhas: "+viewportAxisIntensity+"%");saveViewportAxisStyle();}}
      public void onStartTrackingTouch(SeekBar bar){}public void onStopTrackingTouch(SeekBar bar){}
    });
    String[] labels={"Cor do Fundo 3D","Cor Linha Vermelha","Cor Linha Verde"};
    for(int i=0;i<3;i++){
      final int index=i;
      TextView button=label(labels[i],12);styleSettingsColorButton(button);
      addStyledButton(group,button,settingsButtonParams(5));
      button.setOnClickListener(v->chooseViewportColor(index));
    }
  }
  void saveViewportAxisStyle(){
    getSharedPreferences("editor_viewport_colors",MODE_PRIVATE).edit()
      .putInt("axis_thickness",viewportAxisThickness).putInt("axis_intensity",viewportAxisIntensity).apply();
    if(view!=null)view.invalidate();
  }

  void loadGridPreferences(){
    android.content.SharedPreferences pref=getSharedPreferences("editor_grid",MODE_PRIVATE);
    gridVisible=pref.getBoolean("visible",true);
    gridSpacingDp=pref.getInt("spacing",24);
    gridOpacity=pref.getInt("opacity",35);
    gridLineColor=pref.getInt("line_color",0xff738092);
  }
  void persistGridPreferences(){
    getSharedPreferences("editor_grid",MODE_PRIVATE).edit()
      .putBoolean("visible",gridVisible).putInt("spacing",gridSpacingDp)
      .putInt("opacity",gridOpacity).putInt("line_color",gridLineColor).apply();
    if(view!=null)view.invalidate();
  }
  static final String ZOOM_PREFS="editor_camera";
  float loadSavedZoom(){
    float value=getSharedPreferences(ZOOM_PREFS,MODE_PRIVATE).getFloat("zoom",1f);
    return Float.isNaN(value)||Float.isInfinite(value)?1f:Math.max(.15f,Math.min(12f,value));
  }
  void saveZoom(float value){getSharedPreferences(ZOOM_PREFS,MODE_PRIVATE).edit().putFloat("zoom",value).apply();}
  float loadSavedVerticalPan(){
    float dpValue=getSharedPreferences(ZOOM_PREFS,MODE_PRIVATE).getFloat("vertical_pan_dp",0f);
    return Float.isNaN(dpValue)||Float.isInfinite(dpValue)?0f:dp(dpValue);
  }
  void saveVerticalPan(float pixels){
    getSharedPreferences(ZOOM_PREFS,MODE_PRIVATE).edit().putFloat("vertical_pan_dp",pixels/getResources().getDisplayMetrics().density).apply();
  }
  boolean faceWireVisible=true,hairWireVisible=true,faceUvWireVisible=true,hairUvWireVisible=true;
  int faceWireColor=0xfff0f2f5,hairWireColor=0xfff0f2f5;
  int uvWireColor=0xfff0f2f5,uvVertexColor=0xfff0f2f5;
  int wireOpacity=60,wireThickness=5; // thickness in tenths of dp
  int vertexSize=6,vertexOpacity=100,faceVertexColor=0xfff0f2f5,hairVertexColor=0xfff0f2f5;
  boolean editArrowsVisible=true,editPointVisible=true,hideArrowsWhileDragging=true;
  boolean cumulativeMultiSelection=true;
  boolean proportionalEditing=false;
  int proportionalRadius=15;
  int editArrowSize=100,editArrowThickness=115,editPointSize=16;
  int editPointColor=0xffffae32,editXColor=0xfff04d4d,editZColor=0xff4b9fff;
  int editSelectionColor=0xff2389ff, editCrossColor=0xffffa32b;
  int editSelectionIntensity=50, editCrossIntensity=50;
  int editSelectionCrossThickness=100;
  // Cache independente por malha: Face e Hair nao devem invalidar o atlas um do outro.
  static final class PreviewPhotoCache {
    Bitmap atlas,source; float x,z,w,h,angle; long signature=Long.MIN_VALUE; float[] vertexSnapshot;
  }
  final java.util.IdentityHashMap<Mesh,PreviewPhotoCache> previewPhotoCaches=new java.util.IdentityHashMap<>();
  // Cache de pixels da imagem de referência, usado pela geração do atlas.
  Bitmap previewPhotoPixelSource;
  int[] previewPhotoSourcePixels;

  long photoGeometrySignature(Mesh m){
    long h=1469598103934665603L;
    h=(h^m.vertices.size())*1099511628211L;
    for(float[] v:m.vertices)for(int k=0;k<3&&k<v.length;k++)h=(h^Float.floatToIntBits(v[k]))*1099511628211L;
    return h;
  }
  Bitmap getPreviewPhotoAtlas(Mesh target){
    if(target==null||referenceImage==null||view==null)return null;
    Bitmap source=previewView!=null?previewView.livePhotoSource():referenceImage;
    if(source==null)return null;
    PreviewPhotoCache cache=previewPhotoCaches.get(target);
    if(cache==null){cache=new PreviewPhotoCache();previewPhotoCaches.put(target,cache);}
    long signature=photoGeometrySignature(target);
    boolean sameSetup=cache.atlas!=null&&cache.source==source&&cache.x==referenceX&&cache.z==referenceZ&&cache.w==referenceWidth&&cache.h==referenceHeight&&cache.angle==referenceRotation;
    if(sameSetup&&cache.signature==signature)return cache.atlas;
    int[] dirty=null;
    if(sameSetup&&cache.vertexSnapshot!=null&&cache.vertexSnapshot.length==target.vertices.size()*3){
      boolean[] changed=new boolean[target.vertices.size()];boolean any=false;
      for(int i=0;i<changed.length;i++){float[] v=target.vertices.get(i);for(int k=0;k<3;k++)if(v[k]!=cache.vertexSnapshot[i*3+k]){changed[i]=true;any=true;break;}}
      if(any){int minX=1024,minY=1024,maxX=-1,maxY=-1;
        for(int fi=0;fi<target.faces.size();fi++){int[] f=target.faces.get(fi);boolean affected=false;for(int vi:f)if(vi>=0&&vi<changed.length&&changed[vi]){affected=true;break;}if(!affected)continue;
          int[] uv=fi<target.faceUvs.size()?target.faceUvs.get(fi):f;for(int ui:uv)if(ui>=0&&ui<target.uvs.size()){float[] v=target.uvs.get(ui);int x=(int)(v[0]*1024),y=(int)((1-v[1])*1024);minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);}}
        if(maxX>=minX&&maxY>=minY)dirty=new int[]{Math.max(0,minX-2),Math.max(0,minY-2),Math.min(1023,maxX+2),Math.min(1023,maxY+2)};
      }
    }
    Bitmap atlas=buildPhotoUvAtlas(target,source,target==hairMesh,dirty,dirty==null?null:cache.atlas);
    if(atlas!=null){cache.atlas=atlas;cache.source=source;cache.x=referenceX;cache.z=referenceZ;cache.w=referenceWidth;cache.h=referenceHeight;cache.angle=referenceRotation;cache.signature=signature;cache.vertexSnapshot=new float[target.vertices.size()*3];for(int i=0;i<target.vertices.size();i++)System.arraycopy(target.vertices.get(i),0,cache.vertexSnapshot,i*3,3);}
    return atlas;
  }
  Bitmap generatedPhotoUv;
  Bitmap referenceImage;
  Uri referenceUri;
  boolean referenceVisible=true,referenceLocked=true,referenceKeepRatio=true,referenceAdjustMode=false;
  int referenceOpacity=65;
  int frameLineColor=0xff6abaff,frameDotColor=0xfff8fbff,frameDotBorderColor=0xff3c9fff;
  int frameLineThickness=14,frameDotSize=55,frameDotBorderThickness=20;
  int frameLineOpacity=100,frameDotOpacity=100;
  boolean frameDotsVisible=true;
  float referenceX=0f,referenceZ=0f,referenceWidth=2f,referenceHeight=2f,referenceRotation=0f;
  final ArrayList<float[]> referenceUndo=new ArrayList<>(),referenceRedo=new ArrayList<>();
  float[] referenceGestureStart=null;
  float[] referenceSnapshot(){return new float[]{referenceX,referenceZ,referenceWidth,referenceHeight,referenceRotation};}
  void restoreReference(float[] a){referenceX=a[0];referenceZ=a[1];referenceWidth=a[2];referenceHeight=a[3];referenceRotation=a[4];saveReferencePrefs();}
  boolean referenceChanged(float[] a){if(a==null)return false;float[] b=referenceSnapshot();for(int i=0;i<b.length;i++)if(Math.abs(a[i]-b[i])>0.00001f)return true;return false;}
  void commitReferenceGesture(){if(referenceChanged(referenceGestureStart)){referenceUndo.add(referenceGestureStart);if(referenceUndo.size()>30)referenceUndo.remove(0);referenceRedo.clear();}referenceGestureStart=null;}
  void referenceHistoryUndo(){if(referenceUndo.isEmpty()){toast("Nada para desfazer");return;}referenceRedo.add(referenceSnapshot());restoreReference(referenceUndo.remove(referenceUndo.size()-1));}
  void referenceHistoryRedo(){if(referenceRedo.isEmpty()){toast("Nada para refazer");return;}referenceUndo.add(referenceSnapshot());restoreReference(referenceRedo.remove(referenceRedo.size()-1));}

  void loadReferencePrefs(){
    android.content.SharedPreferences sp=getSharedPreferences("editor_reference",MODE_PRIVATE);
    frameLineColor=sp.getInt("frameLineColor",0xff6abaff);
    frameDotColor=sp.getInt("frameDotColor",0xfff8fbff);
    frameDotBorderColor=sp.getInt("frameDotBorderColor",0xff3c9fff);
    frameLineThickness=sp.getInt("frameLineThickness",14);
    frameDotSize=sp.getInt("frameDotSize",55);
    frameDotBorderThickness=sp.getInt("frameDotBorderThickness",20);
    frameLineOpacity=sp.getInt("frameLineOpacity",100);
    frameDotOpacity=sp.getInt("frameDotOpacity",100);
    frameDotsVisible=sp.getBoolean("frameDotsVisible",true);
    referenceVisible=sp.getBoolean("visible",true);referenceLocked=sp.getBoolean("locked",true);
    referenceKeepRatio=sp.getBoolean("ratio",true);referenceOpacity=sp.getInt("opacity",65);
    referenceX=sp.getFloat("x",0);referenceZ=sp.getFloat("z",0);
    referenceWidth=sp.getFloat("width",2);referenceHeight=sp.getFloat("height",2);referenceRotation=sp.getFloat("rotation",0f);
    // A imagem de referencia e temporaria: nao restaurar entre aberturas.
    referenceImage=null;referenceUri=null;referenceAdjustMode=false;
    sp.edit().remove("uri").apply();
  }
  void loadReferenceBitmap(Uri uri)throws Exception{
    BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;
    try(InputStream in=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(in,null,options);}
    int sample=1;while(options.outWidth/sample>2048||options.outHeight/sample>2048)sample*=2;
    options.inJustDecodeBounds=false;options.inSampleSize=sample;
    try(InputStream in=getContentResolver().openInputStream(uri)){referenceImage=BitmapFactory.decodeStream(in,null,options);}
    if(referenceImage==null)throw new IOException("Não foi possível abrir a imagem");
    referenceUndo.clear();referenceRedo.clear();referenceGestureStart=null;
  }
  void saveReferencePrefs(){getSharedPreferences("editor_reference",MODE_PRIVATE).edit()
    .putInt("frameLineColor",frameLineColor).putInt("frameDotColor",frameDotColor)
    .putInt("frameDotBorderColor",frameDotBorderColor).putInt("frameLineThickness",frameLineThickness)
    .putInt("frameDotSize",frameDotSize).putInt("frameDotBorderThickness",frameDotBorderThickness)
    .putInt("frameLineOpacity",frameLineOpacity).putInt("frameDotOpacity",frameDotOpacity)
    .putBoolean("frameDotsVisible",frameDotsVisible)
    .putBoolean("visible",referenceVisible).putBoolean("locked",referenceLocked)
    .putBoolean("ratio",referenceKeepRatio).putInt("opacity",referenceOpacity)
    .putFloat("x",referenceX).putFloat("z",referenceZ)
    .putFloat("width",referenceWidth).putFloat("height",referenceHeight).putFloat("rotation",referenceRotation)
    .remove("uri").apply();
    if(view!=null)view.invalidate();}
  void settingsReference(LinearLayout parent){
    LinearLayout g=new LinearLayout(this);g.setOrientation(1);g.setPadding(dp(6),dp(7),dp(6),dp(7));
    parent.addView(g,new LinearLayout.LayoutParams(-1,-2));
    CheckBox touchMode=new CheckBox(this);touchMode.setText("Transformar imagem (moldura)");touchMode.setTextColor(Color.WHITE);touchMode.setChecked(referenceAdjustMode);g.addView(touchMode);
    touchMode.setOnCheckedChangeListener((b,on)->{referenceAdjustMode=on;if(on){referenceLocked=false;toast("Arraste a foto, as alças ou o círculo superior para girar");}else saveReferencePrefs();if(view!=null)view.invalidate();});
    TextView importButton=settingsAction("Importar imagem",g);
    importButton.setOnClickListener(v->pick(REFERENCE_IMAGE,"image/*"));
    TextView done=settingsAction("Concluir ajuste",g);done.setOnClickListener(v->{referenceAdjustMode=false;touchMode.setChecked(false);saveReferencePrefs();});
    TextView remove=settingsAction("Remover imagem",g);
    remove.setOnClickListener(v->{referenceImage=null;referenceUri=null;saveReferencePrefs();toast("Imagem removida");});
    CheckBox visible=new CheckBox(this);visible.setText("Mostrar imagem");visible.setTextColor(Color.WHITE);visible.setChecked(referenceVisible);g.addView(visible);
    visible.setOnCheckedChangeListener((b,on)->{referenceVisible=on;saveReferencePrefs();});
    referenceSlider(g,"Opacidade",0,100,()->referenceOpacity,v->referenceOpacity=v);
    CheckBox ignoreEyes=new CheckBox(this);ignoreEyes.setText("Ignorar textura dos olhos");ignoreEyes.setTextColor(Color.WHITE);ignoreEyes.setTextSize(12);
    ignoreEyes.setChecked(getSharedPreferences("editor_reference",MODE_PRIVATE).getBoolean("photo_uv_ignore_eyes",true));g.addView(ignoreEyes);
    ignoreEyes.setOnCheckedChangeListener((b,on)->getSharedPreferences("editor_reference",MODE_PRIVATE).edit().putBoolean("photo_uv_ignore_eyes",on).apply());
    TextView basePick=settingsAction("Escolher base de cor (PNG)",g);
    basePick.setOnClickListener(v->pick(COLOR_BASE_IMAGE,"image/*"));
    CheckBox useBase=new CheckBox(this);useBase.setText("Igualar tom de pele à base");useBase.setTextColor(Color.WHITE);
    useBase.setChecked(useColorBase);g.addView(useBase);
    useBase.setOnCheckedChangeListener((b,on)->{useColorBase=on;if(on&&colorBaseImage==null)toast("Escolha primeiro uma base PNG");});
    android.content.SharedPreferences brightPrefs=getSharedPreferences("editor_reference",MODE_PRIVATE);
    matchBaseBrightness=brightPrefs.getBoolean("photo_uv_match_brightness",true);
    baseBrightnessStrength=brightPrefs.getInt("photo_uv_brightness_strength",100);
    CheckBox useBrightness=new CheckBox(this);useBrightness.setText("Igualar brilho à base");useBrightness.setTextColor(Color.WHITE);
    useBrightness.setChecked(matchBaseBrightness);g.addView(useBrightness);
    useBrightness.setOnCheckedChangeListener((b,on)->{matchBaseBrightness=on;brightPrefs.edit().putBoolean("photo_uv_match_brightness",on).apply();});
    TextView brightnessLabel=new TextView(this);brightnessLabel.setTextColor(Color.WHITE);brightnessLabel.setText("Intensidade do brilho: "+baseBrightnessStrength+"%");g.addView(brightnessLabel);
    SeekBar brightnessSlider=new SeekBar(this);brightnessSlider.setMax(100);brightnessSlider.setProgress(baseBrightnessStrength);g.addView(brightnessSlider);
    brightnessSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
      public void onProgressChanged(SeekBar bar,int value,boolean user){baseBrightnessStrength=value;brightnessLabel.setText("Intensidade do brilho: "+value+"%");if(user)brightPrefs.edit().putInt("photo_uv_brightness_strength",value).apply();}
      public void onStartTrackingTouch(SeekBar bar){}public void onStopTrackingTouch(SeekBar bar){}
    });
    TextView photoUv=settingsAction("Foto → UV automática",g);
    photoUv.setOnClickListener(v->generatePhotoUv());
    settingsFrameAppearance(g);
    
  }

  // Projeta os triângulos da fotografia de referência sobre as ilhas UV do objeto ativo.
  // A foto permanece intacta; somente os pixels cobertos pelos triângulos são gerados.
  void generatePhotoUv(){
    if(referenceImage==null){toast("Importe uma imagem de referência primeiro");return;}
    if(useColorBase&&colorBaseImage==null){toast("Escolha uma base de cor PNG primeiro");return;}
    final Bitmap photoSource=useColorBase?matchSkinTone(referenceImage,colorBaseImage):referenceImage;
    final boolean targetHair=activeHair;
    final Mesh targetMesh=mesh;
    if(targetMesh==null||targetMesh.faces.isEmpty()||targetMesh.uvs.isEmpty()){
      toast("Importe um modelo "+(targetHair?"Hair":"Face")+" com coordenadas UV");return;
    }
    if(Math.abs(view.yaw)>0.02f||Math.abs(view.pitch)>0.02f||view.rearView){
      new AlertDialog.Builder(this).setTitle("Foto → UV")
        .setMessage("Use a vista frontal ortográfica antes de gerar a textura.")
        .setPositiveButton("OK",null).show();return;
    }
    Bitmap out=buildPhotoUvAtlas(targetMesh,photoSource,targetHair);
    if(out==null){toast("Não foi possível gerar a textura UV");return;}
    generatedPhotoUv=out;
    ImageView preview=new ImageView(this);preview.setImageBitmap(out);preview.setAdjustViewBounds(true);
    preview.setBackgroundColor(0xff555555);preview.setPadding(dp(8),dp(8),dp(8),dp(8));
    new AlertDialog.Builder(this).setTitle("Foto → UV "+(targetHair?"Hair":"Face")+" — prévia da textura")
      .setMessage("Prévia da textura"+(useColorBase?" com correção de pele pela base PNG.":".")+" Áreas não visíveis na foto permanecem transparentes. A foto e o BIN originais não serão alterados.")
      .setView(preview).setNegativeButton("Cancelar",null)
      .setNeutralButton(targetHair?"Aplicar no Hair":"Aplicar na Face",(d,w)->{
        setUvPhoto(out,targetHair);
        Bitmap applied=targetHair?hairTexture:faceTexture;
        for(ExtraObject obj:(targetHair?extraHairs:extraFaces))
          if(obj!=null&&obj.mesh==targetMesh)obj.texture=applied;
        uvPreviewTexture=null;uvImageCleared=false;view.textured=true;view.solid=true;
        view.invalidate();if(uvView!=null)uvView.invalidate();
        if(previewView!=null)previewView.invalidate();
        toast("Textura aplicada ao "+(targetHair?"Hair":"Face"));
      })
      .setPositiveButton("Salvar PNG",(d,w)->{
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/png");intent.putExtra(Intent.EXTRA_TITLE,targetHair?"hair_foto_uv.png":"face_foto_uv.png");
        startActivityForResult(intent,EXPORT_PHOTO_UV);
      }).show();
  }

  // Shared projection for both the explicit Foto -> UV command and the preview.
  // The returned bitmap is temporary until the user explicitly applies it.
  Bitmap buildPhotoUvAtlas(Mesh targetMesh,Bitmap photoSource,boolean targetHair){
    return buildPhotoUvAtlas(targetMesh,photoSource,targetHair,null,null);
  }
  Bitmap buildPhotoUvAtlas(Mesh targetMesh,Bitmap photoSource,boolean targetHair,int[] dirty,Bitmap previous){
    // Recalcular a projeção com a mesma escala da visualização frontal.
    float vw=(panelShown||transformShown||referenceShown)?Math.max(dp(90),view.getWidth()-panelWidthPx-dp(4)):view.getWidth();
    float sc=Math.min(vw,view.getHeight())*.38f*view.zoom/view.sceneReferenceMax();
    if(sc<=0||referenceWidth<=0||referenceHeight<=0){return null;}
    float cx=vw/2f+referenceX*sc,cy=view.getHeight()/2f+view.panVerticalPx-referenceZ*sc;
    float halfW=referenceWidth*sc/2f,halfH=referenceHeight*sc/2f;
    double angle=Math.toRadians(referenceRotation),cos=Math.cos(angle),sin=Math.sin(angle);
    final int size=1024;
    Bitmap out=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);
    Canvas target=new Canvas(out);target.drawColor(Color.TRANSPARENT,PorterDuff.Mode.CLEAR);
    boolean ignoreEyeIslands=!targetHair&&getSharedPreferences("editor_reference",MODE_PRIVATE).getBoolean("photo_uv_ignore_eyes",true);
    java.util.HashSet<Integer> excludedEyeFaces=ignoreEyeIslands?findPhotoUvEyeIslands():new java.util.HashSet<>();
    // Rasterização por centro de pixel: cada texel pertence a um triângulo
    // verdadeiro, sem expansão de 0,7 px nem clipPath sobreposto.
    int[] atlasPixels=new int[size*size];
    if(dirty!=null&&previous!=null){
      previous.getPixels(atlasPixels,0,size,0,0,size,size);
      for(int y=dirty[1];y<=dirty[3];y++)java.util.Arrays.fill(atlasPixels,y*size+dirty[0],y*size+dirty[2]+1,0);
    }
    int sw=photoSource.getWidth(),sh=photoSource.getHeight();
    if(previewPhotoPixelSource!=photoSource||previewPhotoSourcePixels==null||previewPhotoSourcePixels.length!=sw*sh){
      previewPhotoSourcePixels=new int[sw*sh];photoSource.getPixels(previewPhotoSourcePixels,0,sw,0,0,sw,sh);
      previewPhotoPixelSource=photoSource;
    }
    int[] sourcePixels=previewPhotoSourcePixels;
    int count=0;
    for(int fi=0;fi<targetMesh.faces.size();fi++){
      if(excludedEyeFaces.contains(fi))continue;
      int[] f=targetMesh.faces.get(fi),u=fi<targetMesh.faceUvs.size()?targetMesh.faceUvs.get(fi):f;
      if(f.length<3||u.length<3)continue;
      float[] src=new float[6],dst=new float[6];boolean valid=true;
      for(int k=0;k<3;k++){
        int vi=f[k],ui=u[k];
        if(vi<0||vi>=targetMesh.vertices.size()||ui<0||ui>=targetMesh.uvs.size()){valid=false;break;}
        float[] v=targetMesh.vertices.get(vi),uv=targetMesh.uvs.get(ui);
        float sx=vw/2f+v[0]*sc,sy=view.getHeight()/2f+view.panVerticalPx-v[2]*sc;
        float dx=sx-cx,dy=sy-cy;
        float localX=(float)(dx*cos+dy*sin),localY=(float)(-dx*sin+dy*cos);
        src[k*2]=(localX/(2f*halfW)+.5f)*sw;
        src[k*2+1]=(localY/(2f*halfH)+.5f)*sh;
        dst[k*2]=uv[0]*size;dst[k*2+1]=(1f-uv[1])*size;
      }
      if(!valid)continue;
      float x0=dst[0],y0=dst[1],x1=dst[2],y1=dst[3],x2=dst[4],y2=dst[5];
      float det=(x1-x0)*(y2-y0)-(y1-y0)*(x2-x0);
      if(Math.abs(det)<.01f)continue;
      float inv=1f/det;
      int minX=Math.max(0,(int)Math.floor(Math.min(x0,Math.min(x1,x2))));
      int maxX=Math.min(size-1,(int)Math.ceil(Math.max(x0,Math.max(x1,x2))));
      int minY=Math.max(0,(int)Math.floor(Math.min(y0,Math.min(y1,y2))));
      int maxY=Math.min(size-1,(int)Math.ceil(Math.max(y0,Math.max(y1,y2))));
      if(dirty!=null){minX=Math.max(minX,dirty[0]);maxX=Math.min(maxX,dirty[2]);minY=Math.max(minY,dirty[1]);maxY=Math.min(maxY,dirty[3]);}
      if(minX>maxX||minY>maxY)continue;
      for(int py=minY;py<=maxY;py++){
        float yy=py+.5f;
        for(int px=minX;px<=maxX;px++){
          float xx=px+.5f;
          float w1=((xx-x0)*(y2-y0)-(yy-y0)*(x2-x0))*inv;
          float w2=((x1-x0)*(yy-y0)-(y1-y0)*(xx-x0))*inv;
          float w0=1f-w1-w2;
          if(w0<-.00001f||w1<-.00001f||w2<-.00001f)continue;
          float fx=w0*src[0]+w1*src[2]+w2*src[4]-.5f;
          float fy=w0*src[1]+w1*src[3]+w2*src[5]-.5f;
          if(fx<0||fy<0||fx>=sw-1||fy>=sh-1)continue;
          int ix=(int)fx,iy=(int)fy;
          float tx=fx-ix,ty=fy-iy;
          int c00=sourcePixels[iy*sw+ix],c10=sourcePixels[iy*sw+ix+1];
          int c01=sourcePixels[(iy+1)*sw+ix],c11=sourcePixels[(iy+1)*sw+ix+1];
          int a00=(c00>>>24),a10=(c10>>>24),a01=(c01>>>24),a11=(c11>>>24);
          float t00=(1-tx)*(1-ty),t10=tx*(1-ty),t01=(1-tx)*ty,t11=tx*ty;
          int aa=Math.min(255,Math.round(a00*t00+a10*t10+a01*t01+a11*t11));
          int rr=Math.min(255,Math.round(((c00>>16)&255)*t00+((c10>>16)&255)*t10+((c01>>16)&255)*t01+((c11>>16)&255)*t11));
          int gg=Math.min(255,Math.round(((c00>>8)&255)*t00+((c10>>8)&255)*t10+((c01>>8)&255)*t01+((c11>>8)&255)*t11));
          int bb=Math.min(255,Math.round((c00&255)*t00+(c10&255)*t10+(c01&255)*t01+(c11&255)*t11));
          atlasPixels[py*size+px]=(aa<<24)|(rr<<16)|(gg<<8)|bb;
        }
      }
      count++;
    }
    out.setPixels(atlasPixels,0,size,0,0,size,size);
    if(count==0){out.recycle();return null;}
    return out;
  }

  // Protótipo: estima tons de pele por regiões das bochechas (evita olhos, boca e cabelo).
  // Aplica deslocamento RGB suavizado apenas em pixels com cromaticidade semelhante à pele.
  Bitmap matchSkinTone(Bitmap photo,Bitmap base){
    float[] source=cheekMean(photo),target=cheekMean(base);
    if(source==null||target==null)return photo;
    // Quando o brilho está ativo, separamos cromaticidade e luminância.
    // Sem essa opção, preservamos o algoritmo RGB original da v176.
    boolean adaptBrightness=matchBaseBrightness&&baseBrightnessStrength>0;
    float sourceLum=.2126f*source[0]+.7152f*source[1]+.0722f*source[2];
    float targetLum=.2126f*target[0]+.7152f*target[1]+.0722f*target[2];
    float dr=target[0]-source[0],dg=target[1]-source[1],db=target[2]-source[2];
    if(adaptBrightness){
      float scale=sourceLum/Math.max(1f,targetLum);
      dr=target[0]*scale-source[0];dg=target[1]*scale-source[1];db=target[2]*scale-source[2];
    }
    float brightnessRatio=Math.max(.65f,Math.min(1.45f,targetLum/Math.max(1f,sourceLum)));
    float brightnessAmount=baseBrightnessStrength/100f;
    int w=photo.getWidth(),h=photo.getHeight();
    Bitmap corrected=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
    int[] pixels=new int[w*h];photo.getPixels(pixels,0,w,0,0,w,h);
    for(int i=0;i<pixels.length;i++){
      int c=pixels[i],a=Color.alpha(c);if(a==0)continue;
      int r=Color.red(c),g=Color.green(c),b=Color.blue(c);
      float[] hsv=new float[3];Color.RGBToHSV(r,g,b,hsv);
      float hue=hsv[0],sat=hsv[1];
      // Tons alaranjados/avermelhados; proteção para cílios, pupilas e barba escura.
      float weight=(hue<=48f||hue>=345f)&&sat>=.09f&&sat<=.72f&&hsv[2]>.16f?1f:0f;
      if(weight==0)continue;
      float rr=r+dr*weight,gg=g+dg*weight,bb=b+db*weight;
      if(adaptBrightness){
        // Correção luminosa suave, com limites para evitar estouro e perda de detalhes.
        float factor=1f+(brightnessRatio-1f)*brightnessAmount*weight;
        rr*=factor;gg*=factor;bb*=factor;
      }
      pixels[i]=Color.argb(a,clampColor(rr),clampColor(gg),clampColor(bb));
    }
    corrected.setPixels(pixels,0,w,0,0,w,h);return corrected;
  }
  int clampColor(float x){return Math.max(0,Math.min(255,Math.round(x)));}
  float[] cheekMean(Bitmap bmp){
    int w=bmp.getWidth(),h=bmp.getHeight();double[] sum=new double[3];int count=0;
    // Duas faixas das bochechas no centro do rosto: base frontal alinhada.
    for(int y=(int)(h*.43);y<(int)(h*.66);y+=2)
      for(int x=(int)(w*.18);x<(int)(w*.82);x+=2){
        float nx=(float)x/w;
        if(nx>.39f&&nx<.61f)continue;
        int c=bmp.getPixel(x,y);if(Color.alpha(c)<200)continue;
        float[] hsv=new float[3];Color.colorToHSV(c,hsv);
        if(!((hsv[0]<48||hsv[0]>345)&&hsv[1]>.09f&&hsv[1]<.72f&&hsv[2]>.16f))continue;
        sum[0]+=Color.red(c);sum[1]+=Color.green(c);sum[2]+=Color.blue(c);count++;
      }
    return count<30?null:new float[]{(float)(sum[0]/count),(float)(sum[1]/count),(float)(sum[2]/count)};
  }

  // Detecta ilhas UV pequenas e isoladas na área inferior direita do atlas.
  // Essa é a região onde o BIN testado coloca o fragmento auxiliar dos olhos.
  // Evita apagar a abertura dos olhos na malha principal ou regiões do rosto.
  java.util.HashSet<Integer> findPhotoUvEyeIslands(){
    java.util.HashSet<Integer> result=new java.util.HashSet<>();
    int n=faceMesh.faces.size();
    java.util.HashMap<Integer,java.util.ArrayList<Integer>> uvOwners=new java.util.HashMap<>();
    for(int i=0;i<n;i++){
      int[] u=i<faceMesh.faceUvs.size()?faceMesh.faceUvs.get(i):faceMesh.faces.get(i);
      for(int j=0;j<Math.min(3,u.length);j++){
        if(u[j]<0||u[j]>=faceMesh.uvs.size())continue;
        java.util.ArrayList<Integer> owners=uvOwners.get(u[j]);
        if(owners==null){owners=new java.util.ArrayList<>();uvOwners.put(u[j],owners);}
        owners.add(i);
      }
    }
    boolean[] visited=new boolean[n];
    for(int start=0;start<n;start++){
      if(visited[start])continue;
      java.util.ArrayDeque<Integer> queue=new java.util.ArrayDeque<>();
      java.util.ArrayList<Integer> island=new java.util.ArrayList<>();
      queue.add(start);visited[start]=true;
      float minU=Float.POSITIVE_INFINITY,maxU=Float.NEGATIVE_INFINITY;
      float minV=Float.POSITIVE_INFINITY,maxV=Float.NEGATIVE_INFINITY;
      while(!queue.isEmpty()){
        int fi=queue.removeFirst();island.add(fi);
        int[] uv=fi<faceMesh.faceUvs.size()?faceMesh.faceUvs.get(fi):faceMesh.faces.get(fi);
        for(int j=0;j<Math.min(3,uv.length);j++){
          int id=uv[j];if(id<0||id>=faceMesh.uvs.size())continue;
          float[] xy=faceMesh.uvs.get(id);
          minU=Math.min(minU,xy[0]);maxU=Math.max(maxU,xy[0]);
          minV=Math.min(minV,xy[1]);maxV=Math.max(maxV,xy[1]);
          java.util.ArrayList<Integer> neighbors=uvOwners.get(id);
          if(neighbors!=null)for(int other:neighbors)if(!visited[other]){visited[other]=true;queue.add(other);}
        }
      }
      if(minU==Float.POSITIVE_INFINITY)continue;
      float centerU=(minU+maxU)*.5f,centerV=(minV+maxV)*.5f;
      // UV v cresce de baixo para cima; fragmento auxiliar visível no PNG
      // aparece perto do canto inferior direito, fora da ilha principal.
      if(island.size()<=32 && maxU-minU<.20f && maxV-minV<.24f
          && centerU>.55f && centerV<.32f)result.addAll(island);
    }
    return result;
  }

  interface FrameIntValue{int get();}
  interface FrameIntSet{void set(int v);}
  void frameSlider(LinearLayout parent,String name,int min,int max,int divisor,FrameIntValue get,FrameIntSet set){
    TextView caption=label("",12);parent.addView(caption);
    Runnable refresh=()->caption.setText(name+": "+(divisor==1?String.valueOf(get.get()):String.format(java.util.Locale.US,"%.1f",get.get()/(float)divisor))+(name.contains("Opacidade")?"%":""));
    refresh.run();SeekBar bar=new SeekBar(this);bar.setMax(max-min);bar.setProgress(Math.max(0,Math.min(max-min,get.get()-min)));parent.addView(bar);
    bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int progress,boolean user){if(user){set.set(progress+min);refresh.run();saveReferencePrefs();}}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){} });
  }
  void frameColorPicker(int which,TextView display){
    final String[] names={"Azul","Branco","Preto","Vermelho","Verde","Amarelo","Laranja","Personalizada"};
    final int[] colors={0xff6abaff,0xfff8fbff,0xff161616,0xffff4545,0xff36dc88,0xffffdd44,0xffff9933};
    final int old=which==0?frameLineColor:which==1?frameDotColor:frameDotBorderColor;
    LinearLayout panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(dp(10),dp(8),dp(10),dp(8));panel.setBackgroundColor(PANEL_DARK);
    android.app.Dialog dialog=new android.app.Dialog(this);
    for(int row=0;row<4;row++){
      LinearLayout line=new LinearLayout(this);panel.addView(line);
      for(int col=0;col<2;col++){
        final int i=row*2+col;
        LinearLayout cell=new LinearLayout(this);cell.setGravity(Gravity.CENTER_VERTICAL);
        cell.setPadding(dp(7),dp(10),dp(3),dp(10));cell.setBackground(roundRect(TOOL,0xff40546b,dp(5),dp(1)));
        TextView dot=label("●",17);dot.setTextColor(i<7?colors[i]:old);cell.addView(dot);
        TextView textName=label("  "+names[i],12);cell.addView(textName);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-2,1);cp.setMargins(dp(2),dp(2),dp(2),dp(2));line.addView(cell,cp);
        cell.setOnClickListener(v->{dialog.dismiss();if(i==7){
          EditText hex=new EditText(this);hex.setSingleLine(true);hex.setHint("#RRGGBB");hex.setText(String.format(java.util.Locale.US,"#%06X",old&0xffffff));
          new AlertDialog.Builder(this).setTitle("Cor da moldura").setView(hex).setPositiveButton("Aplicar",(d,w)->{
            try{setFrameColor(which,Color.parseColor(hex.getText().toString().trim()),display);}catch(Exception ex){toast("Use #RRGGBB");}
          }).setNegativeButton("Cancelar",null).show();
        }else setFrameColor(which,colors[i],display);});
      }
    }
    dialog.setContentView(panel);dialog.show();android.view.Window window=dialog.getWindow();
    if(window!=null){window.setBackgroundDrawableResource(android.R.color.transparent);window.setLayout(dp(265),-2);}
  }
  void setFrameColor(int which,int color,TextView display){if(which==0)frameLineColor=color;else if(which==1)frameDotColor=color;else frameDotBorderColor=color;/* Mantem o nome do botao; a cor escolhida fica salva nas preferencias. */saveReferencePrefs();}
  // Mesmo container e a mesma superficie usados pelos botoes Importar/Exportar.
  android.graphics.drawable.Drawable standardToolBackground(){return roundRect(TOOL,0xff40546b,dp(5),dp(1));}
  void styleSettingsColorButton(TextView button){
    button.setGravity(Gravity.CENTER);
    button.setTextColor(Color.WHITE);
    button.setIncludeFontPadding(false);
    button.setSingleLine(false);
    button.setMaxLines(2);
    button.setEllipsize(null);
    button.setPadding(dp(3),0,dp(3),0);
    button.setTextSize(11);
    button.setMinHeight(0);button.setMinimumHeight(0);
    button.setMinWidth(0);button.setMinimumWidth(0);
    button.setClickable(true);button.setFocusable(true);
  }
  void addStyledButton(LinearLayout parent,TextView text,LinearLayout.LayoutParams lp){
    // A mesma estrutura de tool(): LinearLayout com a borda e fundo, texto interno.
    LinearLayout item=new LinearLayout(this);
    item.setGravity(Gravity.CENTER_VERTICAL);
    item.setPadding(dp(5),0,dp(3),0);
    item.setBackground(standardToolBackground());
    item.setContentDescription(text.getText());
    item.addView(text,new LinearLayout.LayoutParams(-1,-1));
    parent.addView(item,lp);
  }
  LinearLayout.LayoutParams settingsButtonParams(int topMargin){
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(31));
    lp.setMargins(dp(2),dp(topMargin),dp(2),dp(1));
    return lp;
  }
  TextView settingsAction(String text,LinearLayout parent){
    TextView b=label(text,11);styleSettingsColorButton(b);
    addStyledButton(parent,b,settingsButtonParams(3));
    return b;
  }
  LinearLayout.LayoutParams frameAppearanceButtonParams(){
    return settingsButtonParams(1);
  }
  void settingsFrameAppearance(LinearLayout parent){
    TextView heading=label("▾ Aparência da Moldura",12);heading.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);heading.setPadding(dp(4),dp(10),0,dp(5));parent.addView(heading);
    LinearLayout body=new LinearLayout(this);body.setOrientation(1);body.setPadding(dp(5),dp(5),dp(5),dp(7));parent.addView(body);
    android.content.SharedPreferences molduraPrefs=getSharedPreferences("editor_sections",MODE_PRIVATE);
    boolean molduraOpen=molduraPrefs.getBoolean("sub_Aparência da Moldura",true);
    body.setVisibility(molduraOpen?View.VISIBLE:View.GONE);
    heading.setText((molduraOpen?"▾ ":"▸ ")+"Aparência da Moldura");
    heading.setOnClickListener(v->{boolean show=body.getVisibility()!=View.VISIBLE;body.setVisibility(show?View.VISIBLE:View.GONE);heading.setText((show?"▾ ":"▸ ")+"Aparência da Moldura");molduraPrefs.edit().putBoolean("sub_Aparência da Moldura",show).apply();});
    frameSlider(body,"Espessura das linhas (dp)",5,50,10,()->frameLineThickness,v->frameLineThickness=v);
    frameSlider(body,"Opacidade das linhas",0,100,1,()->frameLineOpacity,v->frameLineOpacity=v);
    TextView lineColor=label("Cor das linhas",11);styleSettingsColorButton(lineColor);addStyledButton(body,lineColor,frameAppearanceButtonParams());lineColor.setOnClickListener(v->frameColorPicker(0,lineColor));
    CheckBox dots=new CheckBox(this);dots.setText("Mostrar bolinhas");dots.setTextSize(12);dots.setTextColor(Color.WHITE);dots.setChecked(frameDotsVisible);body.addView(dots);dots.setOnCheckedChangeListener((b,on)->{frameDotsVisible=on;saveReferencePrefs();});
    frameSlider(body,"Tamanho das bolinhas (dp)",25,120,10,()->frameDotSize,v->frameDotSize=v);
    frameSlider(body,"Contorno das bolinhas (dp)",5,50,10,()->frameDotBorderThickness,v->frameDotBorderThickness=v);
    frameSlider(body,"Opacidade das bolinhas",0,100,1,()->frameDotOpacity,v->frameDotOpacity=v);
    TextView fill=label("Cor do preenchimento",11);styleSettingsColorButton(fill);addStyledButton(body,fill,frameAppearanceButtonParams());fill.setOnClickListener(v->frameColorPicker(1,fill));
    TextView border=label("Cor do contorno",11);styleSettingsColorButton(border);addStyledButton(body,border,frameAppearanceButtonParams());border.setOnClickListener(v->frameColorPicker(2,border));
    TextView reset=settingsAction("Restaurar padrão",body);
    reset.setOnClickListener(v->{frameLineColor=0xff6abaff;frameDotColor=0xfff8fbff;frameDotBorderColor=0xff3c9fff;frameLineThickness=14;frameDotSize=55;frameDotBorderThickness=20;frameLineOpacity=100;frameDotOpacity=100;frameDotsVisible=true;saveReferencePrefs();toast("Padrão restaurado. Reabra as ferramentas para atualizar os controles.");});
  }

  interface ReferenceValue{int get();}
  interface ReferenceSetter{void set(int value);}
  void referenceSlider(LinearLayout g,String name,int min,int max,ReferenceValue getter,ReferenceSetter setter){
    TextView text=label("",12);g.addView(text);
    Runnable update=()->text.setText(name+": "+(name.equals("Opacidade")?referenceOpacity+"%":String.format(java.util.Locale.US,"%.2f",getter.get()/100f)));
    update.run();SeekBar bar=new SeekBar(this);bar.setMax(max-min);bar.setProgress(Math.max(0,Math.min(max-min,getter.get()-min)));g.addView(bar);
    bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int v,boolean user){if(user){setter.set(v+min);update.run();saveReferencePrefs();}}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
  }
  boolean manualMovementStep=false;
  int manualMovementUnits=30; // 30 = 0.0030
  void loadMovementStepPrefs(){
    android.content.SharedPreferences sp=getSharedPreferences("editor_movement_display",MODE_PRIVATE);
    manualMovementStep=sp.getBoolean("manual",false);
    manualMovementUnits=Math.max(1,Math.min(200,sp.getInt("units",30)));
  }
  void saveMovementStepPrefs(){getSharedPreferences("editor_movement_display",MODE_PRIVATE).edit()
    .putBoolean("manual",manualMovementStep).putInt("units",manualMovementUnits).apply();}
  void settingsMovementStep(LinearLayout parent){
    LinearLayout g=new LinearLayout(this);g.setOrientation(1);g.setPadding(dp(6),dp(7),dp(6),dp(7));
    
    parent.addView(g,new LinearLayout.LayoutParams(-1,-2));
    CheckBox manual=new CheckBox(this);manual.setText("Intervalo manual");manual.setTextSize(12);
    manual.setTextColor(Color.WHITE);manual.setChecked(manualMovementStep);g.addView(manual);
    TextView value=label(String.format(java.util.Locale.US,"Intervalo: %.4f (%d em %d)",manualMovementUnits/10000f,manualMovementUnits,manualMovementUnits),12);
    g.addView(value);
    SeekBar seek=new SeekBar(this);seek.setMax(199);seek.setProgress(manualMovementUnits-1);seek.setEnabled(manualMovementStep);g.addView(seek);
    TextView hint=label("Automático: varia conforme o zoom. Manual: valor fixo apenas na exibição.",11);g.addView(hint);
    manual.setOnCheckedChangeListener((button,checked)->{manualMovementStep=checked;seek.setEnabled(checked);saveMovementStepPrefs();});
    seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
      public void onProgressChanged(SeekBar b,int progress,boolean fromUser){if(fromUser){manualMovementUnits=progress+1;
        value.setText(String.format(java.util.Locale.US,"Intervalo: %.4f (%d em %d)",manualMovementUnits/10000f,manualMovementUnits,manualMovementUnits));saveMovementStepPrefs();}}
      public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}
    });
  }
  void loadEditPrefs(){android.content.SharedPreferences sp=getSharedPreferences("editor_controls",MODE_PRIVATE);
    cumulativeMultiSelection=sp.getBoolean("cumulative_multi_selection",true);
    proportionalEditing=sp.getBoolean("proportional_editing",false);
    proportionalRadius=sp.getInt("proportional_radius",15);
    editArrowsVisible=sp.getBoolean("arrows",true);editPointVisible=sp.getBoolean("point",true);hideArrowsWhileDragging=sp.getBoolean("hide_arrows_drag",true);
    editArrowSize=sp.getInt("arrow_size",100);editArrowThickness=sp.getInt("arrow_thickness",115);
    editPointSize=sp.getInt("point_size",16);editPointColor=sp.getInt("point_color",0xffffae32);
    editXColor=sp.getInt("x_color",0xfff04d4d);editZColor=sp.getInt("z_color",0xff4b9fff);
    editSelectionColor=sp.getInt("selection_color",0xff2389ff);editCrossColor=sp.getInt("cross_color",0xffffa32b);
    editSelectionIntensity=sp.getInt("selection_intensity",50);editCrossIntensity=sp.getInt("cross_intensity",50);editSelectionCrossThickness=sp.getInt("selection_cross_thickness",100);}
  void saveEditPrefs(){getSharedPreferences("editor_controls",MODE_PRIVATE).edit()
    .putBoolean("cumulative_multi_selection",cumulativeMultiSelection)
    .putBoolean("proportional_editing",proportionalEditing).putInt("proportional_radius",proportionalRadius)
    .putBoolean("arrows",editArrowsVisible).putBoolean("point",editPointVisible).putBoolean("hide_arrows_drag",hideArrowsWhileDragging)
    .putInt("arrow_size",editArrowSize).putInt("arrow_thickness",editArrowThickness)
    .putInt("point_size",editPointSize).putInt("point_color",editPointColor)
    .putInt("x_color",editXColor).putInt("z_color",editZColor)
    .putInt("selection_color",editSelectionColor).putInt("cross_color",editCrossColor)
    .putInt("selection_intensity",editSelectionIntensity).putInt("cross_intensity",editCrossIntensity).putInt("selection_cross_thickness",editSelectionCrossThickness).apply();
    if(view!=null)view.invalidate();if(uvView!=null)uvView.invalidate();}
  void settingsEditControls(LinearLayout parent){
    LinearLayout g=new LinearLayout(this);g.setOrientation(1);g.setPadding(dp(6),dp(7),dp(6),dp(7));
    parent.addView(g,new LinearLayout.LayoutParams(-1,-2));
    CheckBox cumulative=new CheckBox(this);cumulative.setText("Seleção múltipla acumulativa");cumulative.setTextColor(Color.WHITE);cumulative.setTextSize(12);cumulative.setChecked(cumulativeMultiSelection);g.addView(cumulative);
    cumulative.setOnCheckedChangeListener((b,v)->{cumulativeMultiSelection=v;saveEditPrefs();});
    CheckBox prop=new CheckBox(this);prop.setText("Movimentação proporcional (3D)");prop.setTextColor(Color.WHITE);prop.setTextSize(12);prop.setChecked(proportionalEditing);g.addView(prop);
    prop.setOnCheckedChangeListener((b,v)->{proportionalEditing=v;saveEditPrefs();});
    TextView radiusLabel=label("Alcance proporcional: "+proportionalRadius+"%",12);g.addView(radiusLabel);
    SeekBar radiusBar=new SeekBar(this);radiusBar.setMax(39);radiusBar.setProgress(Math.max(0,Math.min(39,proportionalRadius-1)));g.addView(radiusBar);
    radiusBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int v,boolean u){if(u){proportionalRadius=v+1;radiusLabel.setText("Alcance proporcional: "+proportionalRadius+"%");saveEditPrefs();}}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});

    CheckBox arrows=new CheckBox(this);arrows.setText("Mostrar setas");arrows.setTextColor(Color.WHITE);arrows.setTextSize(12);arrows.setChecked(editArrowsVisible);g.addView(arrows);
    arrows.setOnCheckedChangeListener((b,v)->{editArrowsVisible=v;saveEditPrefs();});
    CheckBox hideDrag=new CheckBox(this);hideDrag.setText("Ocultar setas ao arrastar");hideDrag.setTextColor(Color.WHITE);hideDrag.setTextSize(12);hideDrag.setChecked(hideArrowsWhileDragging);g.addView(hideDrag);
    hideDrag.setOnCheckedChangeListener((b,v)->{hideArrowsWhileDragging=v;saveEditPrefs();});
    TextView sizeLabel=label("Tamanho das setas: "+editArrowSize+"%",12);g.addView(sizeLabel);
    SeekBar size=new SeekBar(this);size.setMax(150);size.setProgress(editArrowSize-50);g.addView(size);
    size.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int v,boolean u){if(u){editArrowSize=v+50;sizeLabel.setText("Tamanho das setas: "+editArrowSize+"%");saveEditPrefs();}}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
    TextView thickLabel=label("Espessura: "+(editArrowThickness/100f)+" dp",12);g.addView(thickLabel);
    SeekBar thick=new SeekBar(this);thick.setMax(400);thick.setProgress(editArrowThickness-100);g.addView(thick);
    thick.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int v,boolean u){if(u){editArrowThickness=v+100;thickLabel.setText("Espessura: "+(editArrowThickness/100f)+" dp");saveEditPrefs();}}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
    CheckBox point=new CheckBox(this);point.setText("Mostrar ponto selecionado");point.setTextColor(Color.WHITE);point.setTextSize(12);point.setChecked(editPointVisible);g.addView(point);
    point.setOnCheckedChangeListener((b,v)->{editPointVisible=v;saveEditPrefs();});
    TextView pointLabel=label("Tamanho do ponto: "+(editPointSize/10f)+" dp",12);g.addView(pointLabel);
    SeekBar ps=new SeekBar(this);ps.setMax(98);ps.setProgress(Math.max(0,Math.min(98,editPointSize-2)));g.addView(ps);
    ps.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int v,boolean u){if(u){editPointSize=v+2;pointLabel.setText("Tamanho do ponto: "+(editPointSize/10f)+" dp");saveEditPrefs();}}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
    addEditColor(g,"Cor do ponto",0);addEditColor(g,"Cor da seta X",1);addEditColor(g,"Cor da seta Z",2);
    addEditColor(g,"Cor da Seleção",3);addEditColor(g,"Cor da Cruz",4);
    addEditIntensity(g,"Intensidade da Seleção",true);
    addEditIntensity(g,"Intensidade da Cruz",false);
    TextView selectionThicknessLabel=label("Espessura da Seleção e Cruz: "+(editSelectionCrossThickness/100f)+" dp",12);g.addView(selectionThicknessLabel);
    SeekBar selectionThickness=new SeekBar(this);selectionThickness.setMax(390);selectionThickness.setProgress(Math.max(0,Math.min(390,editSelectionCrossThickness-10)));g.addView(selectionThickness);
    selectionThickness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int v,boolean fromUser){if(fromUser){editSelectionCrossThickness=v+10;selectionThicknessLabel.setText("Espessura da Seleção e Cruz: "+(editSelectionCrossThickness/100f)+" dp");saveEditPrefs();}}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
  }
  void addEditIntensity(LinearLayout group,String title,boolean selection){
    int current=selection?editSelectionIntensity:editCrossIntensity;
    TextView value=label(title+": "+current+"%",12);group.addView(value);
    SeekBar bar=new SeekBar(this);bar.setMax(100);bar.setProgress(current);group.addView(bar);
    bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
      public void onProgressChanged(SeekBar b,int progress,boolean fromUser){if(fromUser){
        if(selection)editSelectionIntensity=progress;else editCrossIntensity=progress;
        value.setText(title+": "+progress+"%");saveEditPrefs();}}
      public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}
    });
  }
  int colorAtIntensity(int color,int percent){return (color&0x00ffffff)|((Math.max(0,Math.min(100,percent))*255/100)<<24);}
  void addEditColor(LinearLayout group,String title,int kind){
    TextView b=label(title,12);styleSettingsColorButton(b);
    addStyledButton(group,b,settingsButtonParams(5));
    b.setOnClickListener(v->{
      String[] names={"Amarelo","Branco","Preto","Vermelho","Azul","Verde","Laranja","Personalizada"};
      int[] colors={0xffffae32,0xffffffff,0xff161616,0xfff04d4d,0xff4b9fff,0xff36dc88,0xffff9933};
      // Use o mesmo seletor compacto da malha, mas mantenha cores próprias dos controles.
      LinearLayout panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(dp(10),dp(8),dp(10),dp(8));panel.setBackgroundColor(PANEL_DARK);
      android.app.Dialog dialog=new android.app.Dialog(this);
      for(int row=0;row<4;row++){LinearLayout line=new LinearLayout(this);panel.addView(line);
        for(int col=0;col<2;col++){final int i=row*2+col;
          LinearLayout cell=new LinearLayout(this);cell.setGravity(Gravity.CENTER_VERTICAL);
          cell.setPadding(dp(7),dp(10),dp(3),dp(10));cell.setBackground(roundRect(TOOL,0xff40546b,dp(5),dp(1)));
          TextView dot=label("●",17);
          dot.setTextColor(i<7?colors[i]:(kind==0?editPointColor:kind==1?editXColor:kind==2?editZColor:kind==3?editSelectionColor:editCrossColor));
          cell.addView(dot);
          TextView textName=label("  "+names[i],12);cell.addView(textName);
          LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-2,1);cp.setMargins(dp(2),dp(2),dp(2),dp(2));line.addView(cell,cp);
          cell.setOnClickListener(w->{dialog.dismiss();if(i==7){EditText hex=new EditText(this);hex.setSingleLine(true);hex.setHint("#RRGGBB");
            new AlertDialog.Builder(this).setTitle(title).setView(hex).setPositiveButton("Aplicar",(d,n)->{try{setEditColor(kind,Color.parseColor(hex.getText().toString().trim()));}catch(Exception ex){toast("Use #RRGGBB");}}).setNegativeButton("Cancelar",null).show();
          }else setEditColor(kind,colors[i]);});
        }
      }
      dialog.setContentView(panel);dialog.show();android.view.Window window=dialog.getWindow();if(window!=null){window.setBackgroundDrawableResource(android.R.color.transparent);window.setLayout(dp(265),-2);}
    });
  }
  void setEditColor(int kind,int color){if(kind==0)editPointColor=color;else if(kind==1)editXColor=color;else if(kind==2)editZColor=color;else if(kind==3)editSelectionColor=color;else editCrossColor=color;saveEditPrefs();}
  void loadVertexPrefs(){android.content.SharedPreferences sp=getSharedPreferences("editor_vertices",MODE_PRIVATE);highlightSelectedEdges=sp.getBoolean("highlight_edges",false);selectedEdgeColor=sp.getInt("edge_color",0xffffa500);uvVertexColor=sp.getInt("uv_color",0xfff0f2f5);vertexSize=sp.getInt("size",6);vertexOpacity=sp.getInt("opacity",100);faceVertexColor=sp.getInt("face_color",0xfff0f2f5);hairVertexColor=sp.getInt("hair_color",0xfff0f2f5);}
  void saveVertexPrefs(){getSharedPreferences("editor_vertices",MODE_PRIVATE).edit().putInt("size",vertexSize).putInt("opacity",vertexOpacity).putInt("face_color",faceVertexColor).putInt("hair_color",hairVertexColor).putInt("uv_color",uvVertexColor).putBoolean("highlight_edges",highlightSelectedEdges).putInt("edge_color",selectedEdgeColor).apply();if(view!=null)view.invalidate();if(uvView!=null)uvView.invalidate();}
  void loadWirePrefs(){android.content.SharedPreferences sp=getSharedPreferences("editor_wireframe",MODE_PRIVATE);uvWireColor=sp.getInt("uv_color",0xfff0f2f5);
    faceWireVisible=sp.getBoolean("face_visible",true);hairWireVisible=sp.getBoolean("hair_visible",true);
    faceUvWireVisible=sp.getBoolean("face_uv_visible",sp.getBoolean("face_visible",true));hairUvWireVisible=sp.getBoolean("hair_uv_visible",sp.getBoolean("hair_visible",true));
    faceWireColor=sp.getInt("face_color",0xfff0f2f5);hairWireColor=sp.getInt("hair_color",0xfff0f2f5);
    wireOpacity=sp.getInt("opacity",60);wireThickness=sp.getInt("thickness",5);
  }
  void saveWirePrefs(){getSharedPreferences("editor_wireframe",MODE_PRIVATE).edit()
    .putBoolean("face_visible",faceWireVisible).putBoolean("hair_visible",hairWireVisible)
    .putBoolean("face_uv_visible",faceUvWireVisible).putBoolean("hair_uv_visible",hairUvWireVisible)
    .putInt("face_color",faceWireColor).putInt("hair_color",hairWireColor).putInt("uv_color",uvWireColor)
    .putInt("opacity",wireOpacity).putInt("thickness",wireThickness).apply();
    if(view!=null)view.invalidate();if(uvView!=null)uvView.invalidate();
  }
  int wireColor(boolean hair){int base=hair?hairWireColor:faceWireColor;
    return (Math.max(0,Math.min(100,wireOpacity))*255/100<<24)|(base&0x00ffffff);
  }
  void chooseWireColor(boolean hair,TextView display){chooseMeshColor(hair,false,display);}
  void chooseMeshColor(boolean hair,boolean vertex,TextView display){chooseMeshColor(hair,vertex,false,display);}
  void chooseMeshColor(boolean hair,boolean vertex,boolean uv,TextView display){
    String[] names={"Branco","Preto","Vermelho","Azul","Verde","Amarelo","Laranja"};
    int[] colors={0xfff0f2f5,0xff161616,0xffff4545,0xff439cff,0xff36dc88,0xffffdd44,0xffff9933};
    final int old=uv?(vertex?uvVertexColor:uvWireColor):vertex?(hair?hairVertexColor:faceVertexColor):(hair?hairWireColor:faceWireColor);
    LinearLayout layout=new LinearLayout(this);layout.setOrientation(1);layout.setPadding(dp(12),dp(10),dp(12),dp(10));layout.setBackgroundColor(PANEL_DARK);
    android.app.Dialog dialog=new android.app.Dialog(this);
    LinearLayout grid=new LinearLayout(this);grid.setOrientation(1);layout.addView(grid);
    for(int row=0;row<4;row++){
      LinearLayout line=new LinearLayout(this);grid.addView(line,new LinearLayout.LayoutParams(-1,dp(45)));
      for(int col=0;col<2;col++){int i=row*2+col;if(i>=names.length)break;
        LinearLayout cell=new LinearLayout(this);cell.setGravity(Gravity.CENTER_VERTICAL);cell.setPadding(dp(7),0,dp(4),0);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-1,1);cp.setMargins(dp(2),dp(2),dp(2),dp(2));line.addView(cell,cp);
        cell.setBackground(roundRect((old&0xffffff)==(colors[i]&0xffffff)?0xff294c72:TOOL,0xff40546b,dp(5),dp(1)));
        TextView dot=label("●",19);dot.setTextColor(colors[i]);cell.addView(dot);
        TextView name=label(" "+names[i],12);cell.addView(name);
        final int chosen=colors[i];final String chosenName=names[i];cell.setOnClickListener(v->{setMeshColor(hair,vertex,uv,chosen,display,chosenName);dialog.dismiss();});
      }
    }
    TextView custom=label("◉  Cor personalizada",13);custom.setGravity(Gravity.CENTER);custom.setPadding(dp(8),dp(12),dp(8),dp(12));
    custom.setBackground(roundRect(TOOL,0xff40546b,dp(5),dp(1)));layout.addView(custom);
    custom.setOnClickListener(v->{dialog.dismiss();EditText hex=new EditText(this);hex.setSingleLine(true);hex.setHint("#RRGGBB");hex.setText(String.format(java.util.Locale.US,"#%06X",old&0xffffff));
      new AlertDialog.Builder(this).setTitle("Cor personalizada").setView(hex).setPositiveButton("Aplicar",(d,w)->{
        try{int c=Color.parseColor(hex.getText().toString().trim());setMeshColor(hair,vertex,uv,c,display,String.format(java.util.Locale.US,"#%06X",c&0xffffff));}
        catch(Exception ex){toast("Use uma cor no formato #RRGGBB");}
      }).setNegativeButton("Cancelar",null).show();});
    dialog.setContentView(layout);android.view.Window window=dialog.getWindow();
    if(window!=null){window.setBackgroundDrawableResource(android.R.color.transparent);window.setLayout(dp(260),-2);}
    dialog.show();window=dialog.getWindow();if(window!=null){window.setBackgroundDrawableResource(android.R.color.transparent);window.setLayout(dp(260),-2);}
  }
  void setMeshColor(boolean hair,boolean vertex,boolean uv,int color,TextView display,String name){
    if(uv){if(vertex){uvVertexColor=color;saveVertexPrefs();}else{uvWireColor=color;saveWirePrefs();}display.setText("Cor UV: "+name);return;}
    if(vertex){if(hair)hairVertexColor=color;else faceVertexColor=color;saveVertexPrefs();}
    else{if(hair)hairWireColor=color;else faceWireColor=color;saveWirePrefs();}
    display.setText("Cor "+(hair?"Hair":"Face")+": "+name);
  }
  void chooseSelectedEdgeColor(){
    String[] names={"Branco","Preto","Vermelho","Azul","Verde","Amarelo","Laranja"};
    int[] colors={0xfff0f2f5,0xff161616,0xffff4545,0xff439cff,0xff36dc88,0xffffdd44,0xffff9933};
    LinearLayout layout=new LinearLayout(this);layout.setOrientation(1);layout.setPadding(dp(12),dp(10),dp(12),dp(10));layout.setBackgroundColor(PANEL_DARK);
    android.app.Dialog dialog=new android.app.Dialog(this);
    for(int row=0;row<4;row++){
      LinearLayout line=new LinearLayout(this);layout.addView(line,new LinearLayout.LayoutParams(-1,dp(45)));
      for(int col=0;col<2;col++){int i=row*2+col;if(i>=names.length)break;
        LinearLayout cell=new LinearLayout(this);cell.setGravity(Gravity.CENTER_VERTICAL);cell.setPadding(dp(7),0,dp(4),0);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-1,1);cp.setMargins(dp(2),dp(2),dp(2),dp(2));line.addView(cell,cp);
        cell.setBackground(roundRect(selectedEdgeColor==colors[i]?0xff294c72:TOOL,0xff40546b,dp(5),dp(1)));
        TextView dot=label("●",19);dot.setTextColor(colors[i]);cell.addView(dot);cell.addView(label(" "+names[i],12));
        final int color=colors[i];cell.setOnClickListener(v->{selectedEdgeColor=color;saveVertexPrefs();dialog.dismiss();});
      }
    }
    TextView custom=label("◉  Cor personalizada",13);custom.setGravity(Gravity.CENTER);custom.setPadding(dp(8),dp(12),dp(8),dp(12));custom.setBackground(roundRect(TOOL,0xff40546b,dp(5),dp(1)));layout.addView(custom);
    custom.setOnClickListener(v->{dialog.dismiss();EditText hex=new EditText(this);hex.setSingleLine(true);hex.setHint("#RRGGBB");hex.setText(String.format(java.util.Locale.US,"#%06X",selectedEdgeColor&0xffffff));new AlertDialog.Builder(this).setTitle("Cor personalizada").setView(hex).setPositiveButton("Aplicar",(d,w)->{try{selectedEdgeColor=Color.parseColor(hex.getText().toString().trim());saveVertexPrefs();}catch(Exception ex){toast("Use uma cor no formato #RRGGBB");}}).setNegativeButton("Cancelar",null).show();});
    dialog.setContentView(layout);dialog.show();android.view.Window window=dialog.getWindow();if(window!=null){window.setBackgroundDrawableResource(android.R.color.transparent);window.setLayout(dp(260),-2);}
  }
  void settingsVertexGroup(LinearLayout parent){
    LinearLayout group=new LinearLayout(this);group.setOrientation(1);group.setPadding(dp(5),dp(6),dp(5),dp(6));
    parent.addView(group,new LinearLayout.LayoutParams(-1,-2));
    CheckBox faceDots=new CheckBox(this);faceDots.setText("Mostrar pontos Face");faceDots.setTextColor(Color.WHITE);faceDots.setTextSize(12);faceDots.setChecked(faceVertices);group.addView(faceDots);
    CheckBox hairDots=new CheckBox(this);hairDots.setText("Mostrar pontos Hair");hairDots.setTextColor(Color.WHITE);hairDots.setTextSize(12);hairDots.setChecked(hairVertices);group.addView(hairDots);
    faceDots.setOnCheckedChangeListener((b,v)->{faceVertices=v;refreshObjects();view.invalidate();if(uvView!=null)uvView.invalidate();});
    hairDots.setOnCheckedChangeListener((b,v)->{hairVertices=v;refreshObjects();view.invalidate();if(uvView!=null)uvView.invalidate();});
    TextView sizeLabel=label("Tamanho: "+(vertexSize/10f)+" dp",12);group.addView(sizeLabel);
    SeekBar size=new SeekBar(this);size.setMax(79);size.setProgress(Math.max(0,vertexSize-1));group.addView(size);
    size.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int v,boolean user){if(user){vertexSize=v+1;sizeLabel.setText("Tamanho: "+(vertexSize/10f)+" dp");saveVertexPrefs();}}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
    TextView opacityLabel=label("Intensidade: "+vertexOpacity+"%",12);group.addView(opacityLabel);
    SeekBar opacity=new SeekBar(this);opacity.setMax(90);opacity.setProgress(vertexOpacity-10);group.addView(opacity);
    opacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int v,boolean user){if(user){vertexOpacity=v+10;opacityLabel.setText("Intensidade: "+vertexOpacity+"%");saveVertexPrefs();}}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
    CheckBox edgeToggle=new CheckBox(this);edgeToggle.setText("Destacar linhas selecionadas");edgeToggle.setTextColor(Color.WHITE);edgeToggle.setTextSize(12);edgeToggle.setChecked(highlightSelectedEdges);group.addView(edgeToggle);
    edgeToggle.setOnCheckedChangeListener((b,checked)->{highlightSelectedEdges=checked;saveVertexPrefs();});
    TextView edgeButton=label("Cor das linhas selecionadas",12);styleSettingsColorButton(edgeButton);addStyledButton(group,edgeButton,settingsButtonParams(5));edgeButton.setOnClickListener(v->chooseSelectedEdgeColor());
    TextView fc=label("Cor Face",12);styleSettingsColorButton(fc);addStyledButton(group,fc,settingsButtonParams(1));fc.setOnClickListener(v->chooseMeshColor(false,true,fc));
    TextView hc=label("Cor Hair",12);styleSettingsColorButton(hc);addStyledButton(group,hc,settingsButtonParams(5));hc.setOnClickListener(v->chooseMeshColor(true,true,hc));
    TextView uvColorButton=label("Cor UV",12);styleSettingsColorButton(uvColorButton);addStyledButton(group,uvColorButton,settingsButtonParams(5));uvColorButton.setOnClickListener(v->chooseMeshColor(false,true,true,uvColorButton));
  }
  void settingsWireGroup(LinearLayout parent){
    LinearLayout group=new LinearLayout(this);group.setOrientation(1);group.setPadding(dp(5),dp(6),dp(5),dp(6));
    
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(7));parent.addView(group,lp);
    TextView thickLabel=label("Espessura: "+(wireThickness/10f)+" dp",12);group.addView(thickLabel);
    SeekBar thick=new SeekBar(this);thick.setMax(29);thick.setProgress(Math.max(0,wireThickness-1));group.addView(thick,new LinearLayout.LayoutParams(-1,dp(34)));
    thick.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int v,boolean user){if(user){wireThickness=v+1;thickLabel.setText("Espessura: "+(wireThickness/10f)+" dp");saveWirePrefs();}}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
    TextView opacityLabel=label("Intensidade: "+wireOpacity+"%",12);group.addView(opacityLabel);
    SeekBar opacity=new SeekBar(this);opacity.setMax(90);opacity.setProgress(Math.max(0,wireOpacity-10));group.addView(opacity,new LinearLayout.LayoutParams(-1,dp(34)));
    opacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int v,boolean user){if(user){wireOpacity=v+10;opacityLabel.setText("Intensidade: "+wireOpacity+"%");saveWirePrefs();}}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
    TextView faceColor=label("Cor Face",12);styleSettingsColorButton(faceColor);addStyledButton(group,faceColor,settingsButtonParams(1));faceColor.setOnClickListener(v->chooseWireColor(false,faceColor));
    TextView hairColor=label("Cor Hair",12);addStyledButton(group,hairColor,settingsButtonParams(5));styleSettingsColorButton(hairColor);hairColor.setOnClickListener(v->chooseWireColor(true,hairColor));
    TextView uvColorButton=label("Cor UV",12);styleSettingsColorButton(uvColorButton);addStyledButton(group,uvColorButton,settingsButtonParams(5));uvColorButton.setOnClickListener(v->chooseMeshColor(false,false,true,uvColorButton));
  }
  LinearLayout transformPanel; TextView transformVertexLabel; EditText[] transformFields=new EditText[3]; EditText[] uvTransformFields=new EditText[2]; float[] copiedUvTransformCoords=null; boolean transformShown=false; int transformIndex=-1; float[] copiedTransformCoords=null;
  int panelWidthPx;
  int NAVY=0xff102746, DARK=0xff101824, PANEL=0xff182a42;
  int PANEL_DARK=0xff142238, TOOL=0xff20334b, ACTIVE=0xff0878df;
  boolean blenderTheme=false;
  void loadEditorTheme(){
    blenderTheme=getSharedPreferences("editor_appearance",MODE_PRIVATE).getBoolean("blender_classic",false);
    if(blenderTheme){NAVY=0xff404040;DARK=0xff505050;PANEL=0xff484848;PANEL_DARK=0xff3e3e3e;TOOL=0xff626262;ACTIVE=0xff777777;}
  }
  int themeColor(int color){
    if(!blenderTheme)return color;
    switch(color){
      case 0xff12233a:return 0xff383838;
      case 0xff111a27:return 0xff646464;
      case 0xff101824:return 0xff505050;
      case 0xff25354b:return 0xff555555;
      case 0xff29394c:return 0xff555555;
      case 0xff56728d:return 0xff999999;
      case 0xff30415a:return 0xff707070;
      case 0xff33445c:return 0xff696969;
      case 0xff34465c:return 0xff777777;
      case 0xff40546b:return 0xff858585;
      case 0xff3b4e67:return 0xff808080;
      case 0xff3b5773:return 0xff888888;
      case 0xff0c1420:return 0xff292929;
      case 0xff0878df:return 0xff777777;
      case 0xff268df0:return 0xff999999;
      case 0xff1b5c9d:return 0xff707070;
      case 0xff337bd0:return 0xff999999;
      default:return color;
    }
  }
  void settingsThemeGroup(LinearLayout parent){
    TextView current=label("Tema: "+(blenderTheme?"Blender Clássico":"Azul Escuro"),12);
    current.setPadding(dp(5),dp(9),0,dp(7));parent.addView(current);
    TextView choose=label("Selecionar tema",12);styleSettingsColorButton(choose);
    addStyledButton(parent,choose,settingsButtonParams(2));
    choose.setOnClickListener(v->{
      String[] themes={"Azul Escuro","Blender Clássico"};
      showEditorChoiceDialog("Tema do editor",themes,blenderTheme?1:0,which->{
          boolean next=which==1;
          if(next==blenderTheme)return;
          getSharedPreferences("editor_appearance",MODE_PRIVATE).edit().putBoolean("blender_classic",next).apply();
          if(mesh.vertices.isEmpty()&&faceMesh.vertices.isEmpty()&&hairMesh.vertices.isEmpty())recreate();
          else {current.setText("Tema: "+themes[which]);toast("Tema salvo. Reabra o aplicativo para aplicar sem perder o modelo.");}
      });
    });
  }
  // Startup snapshot is private to the app; never overwrites the source BIN.
  static class StartupMesh implements Serializable {
    ArrayList<float[]> vertices,uvs; ArrayList<int[]> faces,faceUvs;
    String objectName,materialName,materialLibrary;
  }
  static class StartupObject implements Serializable {
    StartupMesh mesh; byte[] original,decoded,texture; ArrayList<Integer> offsets;
    String source,name; boolean visible,wire,uvWire;
  }
  static class StartupState implements Serializable {
    StartupObject face,hair; ArrayList<StartupObject> faces,hairs;
    ArrayList<String> faceNames,hairNames;
    int faceIndex,hairIndex; boolean activeHair,faceVertices,hairVertices;
    boolean uvEnabled,uvImageCleared;float uvRatio;
    byte[] uvPreview,reference,generatedPhotoUv;
    float[] referenceTransform;boolean referenceVisible,referenceLocked;
    float yaw,pitch,zoom,panVertical,uvZoom,uvPanX,uvPanY;
    boolean textured,solid,rearView;
    ArrayList<Integer> selected3d,selectedUv;
  }
  byte[] startupBitmap(Bitmap bitmap)throws IOException {
    if(bitmap==null)return null;
    ByteArrayOutputStream out=new ByteArrayOutputStream();
    if(!bitmap.compress(Bitmap.CompressFormat.PNG,100,out))throw new IOException("Erro ao codificar textura");
    return out.toByteArray();
  }
  Bitmap restoreStartupBitmap(byte[] data){return data==null?null:BitmapFactory.decodeByteArray(data,0,data.length);}
  StartupMesh packStartupMesh(Mesh m){
    if(m==null)return null;StartupMesh r=new StartupMesh();
    r.vertices=new ArrayList<>(m.vertices);r.uvs=new ArrayList<>(m.uvs);
    r.faces=new ArrayList<>(m.faces);r.faceUvs=new ArrayList<>(m.faceUvs);
    r.objectName=m.objectName;r.materialName=m.materialName;r.materialLibrary=m.materialLibrary;return r;
  }
  Mesh unpackStartupMesh(StartupMesh r){
    Mesh m=new Mesh();if(r==null)return m;
    m.vertices=r.vertices;m.uvs=r.uvs;m.faces=r.faces;m.faceUvs=r.faceUvs;
    m.objectName=r.objectName;m.materialName=r.materialName;m.materialLibrary=r.materialLibrary;return m;
  }
  StartupObject packStartupObject(ExtraObject o)throws IOException {
    if(o==null)return null;StartupObject r=new StartupObject();
    r.mesh=packStartupMesh(o.mesh);r.original=o.original;r.decoded=o.decoded;
    r.offsets=o.offsets;r.texture=startupBitmap(o.texture);
    r.source=o.source==null?null:o.source.toString();r.name=o.name;
    r.visible=o.visible;r.wire=o.wire;r.uvWire=o.uvWire;return r;
  }
  ExtraObject unpackStartupObject(StartupObject r){
    if(r==null)return null;ExtraObject o=new ExtraObject();o.mesh=unpackStartupMesh(r.mesh);
    o.original=r.original;o.decoded=r.decoded;o.offsets=r.offsets==null?new ArrayList<>():r.offsets;
    o.texture=restoreStartupBitmap(r.texture);o.source=r.source==null?null:Uri.parse(r.source);
    o.name=r.name;o.visible=r.visible;o.wire=r.wire;o.uvWire=r.uvWire;return o;
  }
  File startupFile(){return new File(getFilesDir(),"startup_session_v1.dat");}
  void saveStartup(){
    try{
      syncActive();StartupState r=new StartupState();
      r.face=packStartupObject(snapshot(false));r.hair=packStartupObject(snapshot(true));
      r.faces=new ArrayList<>();for(ExtraObject o:extraFaces)r.faces.add(packStartupObject(o));
      r.hairs=new ArrayList<>();for(ExtraObject o:extraHairs)r.hairs.add(packStartupObject(o));
      r.faceNames=new ArrayList<>(faceNames);r.hairNames=new ArrayList<>(hairNames);
      r.faceIndex=faceIndex;r.hairIndex=hairIndex;r.activeHair=activeHair;
      r.faceVertices=faceVertices;r.hairVertices=hairVertices;
      r.uvEnabled=uvEnabled;r.uvRatio=uvRatio;r.uvImageCleared=uvImageCleared;
      r.uvPreview=startupBitmap(uvPreviewTexture);r.reference=startupBitmap(referenceImage);
      r.generatedPhotoUv=startupBitmap(generatedPhotoUv);
      r.referenceTransform=referenceSnapshot();r.referenceVisible=referenceVisible;r.referenceLocked=referenceLocked;
      r.yaw=view.yaw;r.pitch=view.pitch;r.zoom=view.zoom;r.panVertical=view.panVerticalPx;
      r.textured=view.textured;r.solid=view.solid;r.rearView=view.rearView;
      r.uvZoom=uvView.zoom;r.uvPanX=uvView.panX;r.uvPanY=uvView.panY;
      r.selected3d=new ArrayList<>(view.selected);r.selectedUv=new ArrayList<>(uvView.selected);
      File tmp=new File(getFilesDir(),"startup_session_v1.tmp");
      try(ObjectOutputStream out=new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(tmp)))){out.writeObject(r);}
      if(!tmp.renameTo(startupFile())){
        try(InputStream in=new FileInputStream(tmp);OutputStream out=new FileOutputStream(startupFile())){
          byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
        }tmp.delete();
      }
      toast("Inicialização salva");
    }catch(Exception e){toast("Não foi possível salvar a inicialização: "+e.getMessage());}
  }
  void loadStartup(){
    if(!startupFile().isFile())return;
    try{
      StartupState r;
      try(ObjectInputStream in=new ObjectInputStream(new BufferedInputStream(new FileInputStream(startupFile())))){
        r=(StartupState)in.readObject();
      }
      restore(false,unpackStartupObject(r.face));restore(true,unpackStartupObject(r.hair));
      extraFaces.clear();if(r.faces!=null)for(StartupObject o:r.faces)extraFaces.add(unpackStartupObject(o));
      extraHairs.clear();if(r.hairs!=null)for(StartupObject o:r.hairs)extraHairs.add(unpackStartupObject(o));
      faceNames.clear();if(r.faceNames!=null)faceNames.addAll(r.faceNames);
      hairNames.clear();if(r.hairNames!=null)hairNames.addAll(r.hairNames);
      faceIndex=r.faceIndex;hairIndex=r.hairIndex;faceVertices=r.faceVertices;hairVertices=r.hairVertices;
      activeHair=r.activeHair;mesh=activeHair?hairMesh:faceMesh;
      originalBin=activeHair?hairOriginal:faceOriginal;decoded=activeHair?hairDecoded:faceDecoded;
      offsets=new ArrayList<>(activeHair?hairOffsets:faceOffsets);
      uvEnabled=r.uvEnabled;uvRatio=r.uvRatio;uvImageCleared=r.uvImageCleared;
      uvPreviewTexture=restoreStartupBitmap(r.uvPreview);
      referenceImage=restoreStartupBitmap(r.reference);
      generatedPhotoUv=restoreStartupBitmap(r.generatedPhotoUv);
      if(r.referenceTransform!=null&&r.referenceTransform.length==5){
        referenceX=r.referenceTransform[0];referenceZ=r.referenceTransform[1];
        referenceWidth=r.referenceTransform[2];referenceHeight=r.referenceTransform[3];
        referenceRotation=r.referenceTransform[4];
      }
      referenceVisible=r.referenceVisible;referenceLocked=r.referenceLocked;
      view.yaw=r.yaw;view.pitch=r.pitch;view.zoom=r.zoom;view.panVerticalPx=r.panVertical;
      view.textured=r.textured;view.solid=r.solid;view.rearView=r.rearView;
      uvView.zoom=r.uvZoom;uvView.panX=r.uvPanX;uvView.panY=r.uvPanY;
      view.selected.clear();if(r.selected3d!=null)view.selected.addAll(r.selected3d);
      uvView.selected.clear();if(r.selectedUv!=null)uvView.selected.addAll(r.selectedUv);
      updateUvSplit();refreshObjects();view.invalidate();uvView.invalidate();
      status.setText("Inicialização restaurada");
    }catch(Exception e){toast("Falha ao restaurar inicialização: "+e.getMessage());}
  }
  void clearStartup(){
    if(startupFile().exists()&&!startupFile().delete())toast("Não foi possível limpar a inicialização");
    else toast("Inicialização limpa");
  }
  public void onCreate(Bundle b){super.onCreate(b);
    loadEditorTheme();loadViewportColors();loadGridPreferences();loadHairAlphaMode();loadWirePrefs();loadVertexPrefs();loadEditPrefs();loadMovementStepPrefs();loadReferencePrefs();
    getWindow().setStatusBarColor(themeColor(0xff0c1420));getWindow().setNavigationBarColor(themeColor(0xff0c1420));
    LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(DARK);

    // Barra superior compacta: comandos da antiga barra de título, sem título.
    LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setBackgroundColor(themeColor(0xff12233a));bar.setPadding(dp(3),0,dp(3),0);root.addView(bar,new LinearLayout.LayoutParams(-1,dp(34)));
    menuButton(bar,"File",new String[]{"Abrir BIN","Salvar BIN","Importar OBJ","Exportar OBJ","Importar CFG","Exportar CFG","Salvar Inicialização","Limpar Inicialização","Sair"},new Runnable[]{()->pick(OPEN_BIN,"application/octet-stream"),()->save(SAVE_BIN,"face_editada.bin"),()->pick(OPEN_OBJ,"*/*"),()->exportObjDirect(false,0),()->pick(IMPORT_CFG,"application/json"),()->exportCfg(),()->saveStartup(),()->clearStartup(),()->finish()});
    bar.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));
    small(bar,"↶","Desfazer",()->historyUndo());small(bar,"↷","Refazer",()->historyRedo());
    referenceIconButton(bar,()->toggleReferencePanel());
    small(bar,"✥","Transform",()->toggleTransformPanel());
    small(bar,"⚙","Ferramentas",()->togglePanel());

    stage=new FrameLayout(this);root.addView(stage,new LinearLayout.LayoutParams(-1,0,1));
    viewportSplit=new LinearLayout(this);viewportSplit.setOrientation(LinearLayout.VERTICAL);
    stage.addView(viewportSplit,new FrameLayout.LayoutParams(-1,-1));
    view=new ModelView(this);restoreViewMode();view.zoom=loadSavedZoom();view.panVerticalPx=loadSavedVerticalPan();android.widget.FrameLayout gpuLayer=new android.widget.FrameLayout(this);
    viewportSplit.addView(gpuLayer,new LinearLayout.LayoutParams(-1,0,1));
    gpuSurface=new android.opengl.GLSurfaceView(this);
    gpuSurface.setEGLContextClientVersion(3);
    gpuSurface.setPreserveEGLContextOnPause(true);
    gpuSurface.setEGLConfigChooser(8,8,8,8,24,8);
    gpuSurface.setZOrderOnTop(false);
    gpuSurface.setRenderer(gpuRenderer);
    gpuSurface.setRenderMode(android.opengl.GLSurfaceView.RENDERMODE_WHEN_DIRTY);
    // v241: superficie GPU tem altura fixa igual a area total, mesmo quando o painel superior encolhe.
    gpuLayer.setClipChildren(true);
    gpuLayer.setClipToPadding(true);
    stage.addView(gpuSurface,0,new FrameLayout.LayoutParams(-1,-1));
    view.addOnLayoutChangeListener((v,left,top,right,bottom,oldLeft,oldTop,oldRight,oldBottom)->{
      if(gpuSurface!=null && (right-left!=oldRight-oldLeft || bottom-top!=oldBottom-oldTop)){
        gpuRenderer.setVisibleHeight(bottom-top);
        view.invalidate();
      }
    });
    view.setBackgroundColor(android.graphics.Color.TRANSPARENT);
    view.setLayerType(View.LAYER_TYPE_SOFTWARE,null);
    gpuLayer.addView(view,new FrameLayout.LayoutParams(-1,-1));
    uvDivider=new View(this);uvDivider.setBackgroundColor(themeColor(0xff12233a));
    uvDivider.setOnTouchListener((v,e)->{
      if(e.getActionMasked()==MotionEvent.ACTION_DOWN)return true;
      if(e.getActionMasked()==MotionEvent.ACTION_MOVE){
        int[] loc=new int[2];viewportSplit.getLocationOnScreen(loc);
        float y=e.getRawY()-loc[1];int h=viewportSplit.getHeight();
        if(h>0){uvRatio=Math.max(.2f,Math.min(.8f,y/h));updateUvSplit();}return true;
      }return true;
    });
    viewportSplit.addView(uvDivider,new LinearLayout.LayoutParams(-1,dp(2)));
    uvView=new UVView(this);viewportSplit.addView(uvView,new LinearLayout.LayoutParams(-1,0,1));
    previewView=new ModelView(this);previewView.previewOnly=true;previewView.textured=true;previewView.solid=true;previewView.zoom=view.zoom;previewView.yaw=view.yaw;previewView.pitch=view.pitch;viewportSplit.addView(previewView,new LinearLayout.LayoutParams(-1,0,0));
    updateUvSplit();
    orientationLabel=label("Frente • Ortho",11);orientationLabel.setTextColor(0xffc4d0df);
    FrameLayout.LayoutParams olp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.LEFT);olp.setMargins(dp(10),dp(8),0,0);stage.addView(orientationLabel,olp);

    float density=getResources().getDisplayMetrics().density;
    int screenWidthDp=(int)(getResources().getDisplayMetrics().widthPixels/density);
    panelWidthPx=dp(Math.min(176,Math.max(132,Math.round(screenWidthDp*.36f))));
    panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(dp(7),dp(5),dp(7),dp(5));
    panel.setBackground(roundRect(PANEL,themeColor(0xff30415a),dp(5),dp(1)));panel.setElevation(dp(8));
    FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(panelWidthPx,-1,Gravity.RIGHT|Gravity.TOP);pp.setMargins(0,dp(4),dp(4),dp(4));stage.addView(panel,pp);
    referencePanel=new LinearLayout(this);referencePanel.setOrientation(LinearLayout.VERTICAL);
    referencePanel.setPadding(dp(7),dp(5),dp(7),dp(5));
    referencePanel.setBackground(roundRect(PANEL,themeColor(0xff30415a),dp(5),dp(1)));referencePanel.setElevation(dp(8));
    FrameLayout.LayoutParams refLp=new FrameLayout.LayoutParams(panelWidthPx,-1,Gravity.RIGHT|Gravity.TOP);
    refLp.setMargins(0,dp(4),dp(4),dp(4));stage.addView(referencePanel,refLp);
    LinearLayout refHeader=new LinearLayout(this);refHeader.setGravity(Gravity.CENTER_VERTICAL);
    referencePanel.addView(refHeader,new LinearLayout.LayoutParams(-1,dp(34)));
    View headerIcon=referenceIconView();
    LinearLayout.LayoutParams headerIconLp=new LinearLayout.LayoutParams(dp(14),dp(14));
    headerIconLp.rightMargin=dp(5);refHeader.addView(headerIcon,headerIconLp);
    TextView refTitle=label("Imagem de Referência",12);refTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
    refHeader.addView(refTitle,new LinearLayout.LayoutParams(0,-1,1));
    small(refHeader,"×","Fechar Imagem de Referência",()->toggleReferencePanel());
    ScrollView refScroll=new ScrollView(this);refScroll.setVerticalScrollBarEnabled(false);
    referencePanel.addView(refScroll,new LinearLayout.LayoutParams(-1,0,1));
    referenceBody=new LinearLayout(this);referenceBody.setOrientation(LinearLayout.VERTICAL);
    refScroll.addView(referenceBody,new ScrollView.LayoutParams(-1,-2));
    referencePanel.setVisibility(View.GONE);
    transformPanel=new LinearLayout(this);transformPanel.setOrientation(1);transformPanel.setPadding(dp(9),dp(8),dp(9),dp(10));
    transformPanel.setBackground(roundRect(PANEL,themeColor(0xff30415a),dp(5),dp(1)));transformPanel.setElevation(dp(9));
    FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(panelWidthPx,-2,Gravity.RIGHT|Gravity.TOP);tp.setMargins(0,dp(4),dp(4),0);stage.addView(transformPanel,tp);
    LinearLayout transformHeader=new LinearLayout(this);transformHeader.setGravity(Gravity.CENTER_VERTICAL);transformPanel.addView(transformHeader,new LinearLayout.LayoutParams(-1,dp(34)));
    TextView transformTitle=label("✥  Transform",13);transformTitle.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);transformHeader.addView(transformTitle,new LinearLayout.LayoutParams(0,-1,1));
    small(transformHeader,"×","Fechar Transform",()->toggleTransformPanel());
    transformVertexLabel=label("Selecione um vértice",11);transformPanel.addView(transformVertexLabel,new LinearLayout.LayoutParams(-1,dp(38)));
    TextView xyzSection=label("▾ Transform 3D",12);transformPanel.addView(xyzSection);
    LinearLayout xyzBody=new LinearLayout(this);xyzBody.setOrientation(LinearLayout.VERTICAL);transformPanel.addView(xyzBody,new LinearLayout.LayoutParams(-1,-2));
    xyzSection.setOnClickListener(v->{boolean open=xyzBody.getVisibility()!=View.VISIBLE;xyzBody.setVisibility(open?View.VISIBLE:View.GONE);xyzSection.setText(open?"▾ Transform 3D":"▸ Transform 3D");});
    String[] axes={"X","Y","Z"};int[] axisColors={0xffe38b8b,0xff86d5a3,0xff85b5ff};
    for(int i=0;i<3;i++){final int axis=i;LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);xyzBody.addView(line,new LinearLayout.LayoutParams(-1,dp(43)));
      TextView axisLabel=label(axes[i],13);axisLabel.setTextColor(axisColors[i]);line.addView(axisLabel,new LinearLayout.LayoutParams(dp(25),-1));
      EditText field=new EditText(this);field.setSingleLine(true);field.setTextSize(13);field.setTextColor(Color.WHITE);field.setSelectAllOnFocus(true);
      field.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL|android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
      field.setBackground(roundRect(TOOL,themeColor(0xff3b5773),dp(5),dp(1)));field.setPadding(dp(6),0,dp(6),0);
      line.addView(field,new LinearLayout.LayoutParams(0,dp(34),1));transformFields[i]=field;
      field.setOnFocusChangeListener((v,focused)->{if(!focused)applyTransformFields();});
      field.setImeOptions(EditorInfo.IME_ACTION_DONE);
      field.setOnEditorActionListener((v,action,event)->{applyTransformFields();return true;});
    }
    LinearLayout transformActions=new LinearLayout(this);transformActions.setOrientation(LinearLayout.HORIZONTAL);xyzBody.addView(transformActions,new LinearLayout.LayoutParams(-1,-2));
    TextView copyCoords=label("Copiar",11);styleSettingsColorButton(copyCoords);
    LinearLayout.LayoutParams copyLp=new LinearLayout.LayoutParams(0,dp(31),1);copyLp.setMargins(dp(2),dp(3),dp(3),dp(1));addStyledButton(transformActions,copyCoords,copyLp);
    TextView pasteCoords=label("Colar",11);styleSettingsColorButton(pasteCoords);
    LinearLayout.LayoutParams pasteLp=new LinearLayout.LayoutParams(0,dp(31),1);pasteLp.setMargins(dp(3),dp(3),dp(2),dp(1));addStyledButton(transformActions,pasteCoords,pasteLp);
    copyCoords.setOnClickListener(v->{applyTransformFields();if(transformIndex<0||transformIndex>=mesh.vertices.size()||view.selected.size()!=1){toast("Selecione um vértice");return;}copiedTransformCoords=mesh.vertices.get(transformIndex).clone();toast("Coordenadas copiadas");transformPanel.requestFocus();});
    pasteCoords.setOnClickListener(v->{if(copiedTransformCoords==null){toast("Copie as coordenadas primeiro");return;}if(transformIndex<0||transformIndex>=mesh.vertices.size()||view.selected.size()!=1){toast("Selecione um vértice");return;}for(EditText f:transformFields)f.clearFocus();for(int i=0;i<3;i++)transformFields[i].setText(String.format(java.util.Locale.US,"%.7f",copiedTransformCoords[i]));applyTransformFields();transformPanel.requestFocus();refreshTransformPanel();});
    TextView uvSection=label("▾ Transform UV",12);LinearLayout.LayoutParams uvTitleLp=new LinearLayout.LayoutParams(-1,dp(34));uvTitleLp.topMargin=dp(8);transformPanel.addView(uvSection,uvTitleLp);
    LinearLayout uvBody=new LinearLayout(this);uvBody.setOrientation(LinearLayout.VERTICAL);transformPanel.addView(uvBody,new LinearLayout.LayoutParams(-1,-2));
    String[] uvAxes={"X","Z"};int[] uvColors={0xffe38b8b,0xff87b5ff};
    for(int i=0;i<2;i++){LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);uvBody.addView(line,new LinearLayout.LayoutParams(-1,dp(43)));
      TextView axisLabel=label(uvAxes[i],13);axisLabel.setTextColor(uvColors[i]);line.addView(axisLabel,new LinearLayout.LayoutParams(dp(25),-1));
      EditText field=new EditText(this);field.setSingleLine(true);field.setTextSize(13);field.setTextColor(Color.WHITE);field.setSelectAllOnFocus(true);
      field.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL|android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
      field.setBackground(roundRect(TOOL,themeColor(0xff3b5773),dp(5),dp(1)));field.setPadding(dp(6),0,dp(6),0);
      line.addView(field,new LinearLayout.LayoutParams(0,dp(34),1));uvTransformFields[i]=field;
      field.setOnFocusChangeListener((v,focused)->{if(!focused)applyUvTransformFields();});
      field.setImeOptions(EditorInfo.IME_ACTION_DONE);
      field.setOnEditorActionListener((v,action,event)->{applyUvTransformFields();return true;});
    }
    LinearLayout uvActions=new LinearLayout(this);uvActions.setOrientation(LinearLayout.HORIZONTAL);uvBody.addView(uvActions,new LinearLayout.LayoutParams(-1,-2));
    TextView uvCopy=label("Copiar",11);styleSettingsColorButton(uvCopy);LinearLayout.LayoutParams uclp=new LinearLayout.LayoutParams(0,dp(31),1);uclp.setMargins(dp(2),dp(3),dp(3),dp(1));addStyledButton(uvActions,uvCopy,uclp);
    TextView uvPaste=label("Colar",11);styleSettingsColorButton(uvPaste);LinearLayout.LayoutParams uplp=new LinearLayout.LayoutParams(0,dp(31),1);uplp.setMargins(dp(3),dp(3),dp(2),dp(1));addStyledButton(uvActions,uvPaste,uplp);
    uvCopy.setOnClickListener(v->{applyUvTransformFields();if(transformIndex<0||transformIndex>=mesh.uvs.size()||view.selected.size()!=1){toast("Selecione um vértice UV");return;}copiedUvTransformCoords=mesh.uvs.get(transformIndex).clone();toast("UV copiado");transformPanel.requestFocus();});
    uvPaste.setOnClickListener(v->{if(copiedUvTransformCoords==null){toast("Copie as coordenadas UV primeiro");return;}if(transformIndex<0||transformIndex>=mesh.uvs.size()||view.selected.size()!=1){toast("Selecione um vértice UV");return;}for(EditText f:uvTransformFields)f.clearFocus();for(int i=0;i<2;i++)uvTransformFields[i].setText(String.format(java.util.Locale.US,"%.7f",copiedUvTransformCoords[i]));applyUvTransformFields();transformPanel.requestFocus();refreshTransformPanel();});
    uvSection.setOnClickListener(v->{boolean open=uvBody.getVisibility()!=View.VISIBLE;uvBody.setVisibility(open?View.VISIBLE:View.GONE);uvSection.setText(open?"▾ Transform UV":"▸ Transform UV");});
    transformPanel.setFocusableInTouchMode(true);
    transformPanel.setOnClickListener(v->{applyTransformFields();applyUvTransformFields();transformPanel.requestFocus();});
    transformVertexLabel.setOnClickListener(v->{applyTransformFields();transformPanel.requestFocus();});
    transformTitle.setOnClickListener(v->{applyTransformFields();transformPanel.requestFocus();});
    transformPanel.setVisibility(View.GONE);
    analog=new Analog(this);FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(dp(78),dp(78),Gravity.RIGHT|Gravity.BOTTOM);
    ap.setMargins(0,0,dp(4)+(panelWidthPx-dp(78))/2,dp(10));stage.addView(analog,ap);directionPad=new DirectionPad(this);FrameLayout.LayoutParams dpadLp=new FrameLayout.LayoutParams(dp(90),dp(90),Gravity.RIGHT|Gravity.BOTTOM);dpadLp.setMargins(0,0,dp(12),dp(8));stage.addView(directionPad,dpadLp);directionPad.setVisibility(View.GONE);analog.setContentDescription("Analógico para navegar pela câmera 3D");
    LinearLayout ph=new LinearLayout(this);ph.setGravity(Gravity.CENTER_VERTICAL);ph.setPadding(dp(2),0,0,0);panel.addView(ph,new LinearLayout.LayoutParams(-1,dp(34)));
    TextView title=label("⚙  Ferramentas",13);title.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);ph.addView(title,new LinearLayout.LayoutParams(0,-1,1));
    small(ph,"×","Fechar ferramentas",()->togglePanel());
    ScrollView toolScroll=new ScrollView(this);toolScroll.setFillViewport(false);toolScroll.setVerticalScrollBarEnabled(false);panel.addView(toolScroll,new LinearLayout.LayoutParams(-1,0,1));
    panelBody=new LinearLayout(this);panelBody.setOrientation(1);toolScroll.addView(panelBody,new ScrollView.LayoutParams(-1,-2));

    // Importação e edição de dois objetos dentro do painel lateral existente.
    LinearLayout objectsSection=addSection("Objetos",true);
    objectList=new LinearLayout(this);objectList.setOrientation(1);
    objectsSection.addView(objectList,new LinearLayout.LayoutParams(-1,-2));
    refreshObjects();
    LinearLayout faceSection=addSection("Face",true);
    addMeshPanelControls(faceSection,false);
    LinearLayout hairSection=addSection("Hair",true);
    addMeshPanelControls(hairSection,true);
    addHairAlphaControls(hairSection);
    LinearLayout navigation=addSection("Navegação",true);
    analogTool=tool(navigation,"◉","Analógico",()->setNavigationMode(navigationMode==0?2:0),true);
    directionTool=tool(navigation,"✥","Controles",()->setNavigationMode(navigationMode==1?2:1),false);
    android.content.SharedPreferences navPrefs=getSharedPreferences("editor_navigation",MODE_PRIVATE);
    navigationSize=navPrefs.getInt("size",100);navigationSensitivity=navPrefs.getInt("sensitivity",100);analogNavigationColor=navPrefs.getInt("analog_color",0xff2691f0);directionNavigationColor=navPrefs.getInt("direction_color",0xffaaaaaa);
    setNavigationMode(navPrefs.getInt("mode",0));
    addNavigationSliders(navigation);
    TextView analogColorButton=label("Cor Analógico",12);styleSettingsColorButton(analogColorButton);addStyledButton(navigation,analogColorButton,settingsButtonParams(5));analogColorButton.setOnClickListener(v->showNavigationColorPicker(true));
    TextView directionColorButton=label("Cor Setas",12);styleSettingsColorButton(directionColorButton);addStyledButton(navigation,directionColorButton,settingsButtonParams(5));directionColorButton.setOnClickListener(v->showNavigationColorPicker(false));
    LinearLayout appearanceSection=addSection("Aparência",true);
    settingsThemeGroup(appearanceSection);
    LinearLayout gridSection=addSection("Grid",true);
    settingsGridGroup(gridSection);
    LinearLayout viewportColorsSection=addSection("Cores do 3D",true);
    settingsViewportColors(viewportColorsSection);
    LinearLayout wireSection=addSection("Wireframe",true);
    settingsWireGroup(wireSection);
    LinearLayout verticesSection=addSection("Vértices",true);
    settingsVertexGroup(verticesSection);
    LinearLayout editSection=addSection("Controles de Edição",true);
    settingsEditControls(editSection);
    LinearLayout movementSection=addSection("Intervalo do Movimento",true);
    settingsMovementStep(movementSection);
    // Controles de referência ficam exclusivamente na nova janela.
    LinearLayout savedPanelBody=panelBody;
    panelBody=referenceBody;
    LinearLayout referenceSection=addSection("Imagem de Referência",true);
    settingsReference(referenceSection);
    panelBody=savedPanelBody;

    // Barra inferior compacta: menus abrem para cima e zoom fica aqui.
    LinearLayout foot=new LinearLayout(this);foot.setGravity(Gravity.CENTER_VERTICAL);foot.setBackgroundColor(themeColor(0xff12233a));foot.setPadding(dp(5),0,dp(5),0);root.addView(foot,new LinearLayout.LayoutParams(-1,dp(34)));
    menuButton(foot,"View",new String[]{"Frente","Esquerda","Direita","Atrás","Em Cima","Em Baixo"},new Runnable[]{()->setCameraView(0),()->setCameraView(4),()->setCameraView(1),()->setCameraView(2),()->setCameraView(5),()->setCameraView(6)});
    menuButton(foot,"Select",new String[]{"Texture","Solid","Wireframe","UV","3D Preview"},new Runnable[]{()->setTextureMode(),()->setRenderMode(true),()->setRenderMode(false),()->toggleUV(),()->togglePreview()});
    menuButton(foot,"Object",new String[]{"Desfazer","Refazer","Centralizar","Dividir Aresta (OBJ)"},new Runnable[]{()->historyUndo(),()->historyRedo(),()->setCameraView(3),()->splitSelectedEdge()});
    // Reduzir apenas a largura das áreas clicáveis dos menus inferiores.
    int[] menuWidths={48,54,58};
    for(int i=0;i<3;i++){
      View item=foot.getChildAt(i);
      LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)item.getLayoutParams();
      lp.width=dp(menuWidths[i]);item.setLayoutParams(lp);
    }
    foot.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));
    uvBottomControls=new LinearLayout(this);uvBottomControls.setGravity(Gravity.CENTER_VERTICAL);
    foot.addView(uvBottomControls,new LinearLayout.LayoutParams(-2,-1));
    android.widget.FrameLayout uvImageButton=new android.widget.FrameLayout(this);
    View uvImageGlyph=referenceIconView();
    android.widget.FrameLayout.LayoutParams uvGlyphLp=new android.widget.FrameLayout.LayoutParams(dp(18),dp(18),Gravity.CENTER);
    uvImageButton.addView(uvImageGlyph,uvGlyphLp);
    uvImageButton.setContentDescription("Imagem UV");uvImageButton.setBackground(selectableBackground());
    uvBottomControls.addView(uvImageButton,new LinearLayout.LayoutParams(dp(28),-1));
    uvImageButton.setOnClickListener(v->showUvImageMenu(v));
    small(uvBottomControls,"↶","Desfazer UV",()->uvHistoryUndo());
    small(uvBottomControls,"↷","Refazer UV",()->uvHistoryRedo());
    // Mesma aparência dos ícones, com menos espaço lateral.
    for(int i=1;i<uvBottomControls.getChildCount();i++){
      View item=uvBottomControls.getChildAt(i);
      LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)item.getLayoutParams();
      lp.width=dp(28);item.setLayoutParams(lp);
    }
    uvBottomControls.setVisibility(View.VISIBLE);
    zoomButton(foot,"↑","Mover visualização para cima",()->view.panVertical(-dp(24)));
    View panUp=foot.getChildAt(foot.getChildCount()-1);
    zoomButton(foot,"↓","Mover visualização para baixo",()->view.panVertical(dp(24)));
    View panDown=foot.getChildAt(foot.getChildCount()-1);
    zoomButton(foot,"+","Aumentar zoom",()->view.adjustZoom(1.25f));
    zoomPlus=foot.getChildAt(foot.getChildCount()-1);
    zoomButton(foot,"−","Diminuir zoom",()->view.adjustZoom(.8f));
    zoomMinus=foot.getChildAt(foot.getChildCount()-1);
    for(View item:new View[]{panUp,panDown,zoomPlus,zoomMinus}){
      LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)item.getLayoutParams();
      lp.width=dp(26);lp.leftMargin=0;lp.rightMargin=0;item.setLayoutParams(lp);
    }
    status=label("Abra um BIN ou OBJ para visualizar.",11);status.setSingleLine(true);status.setEllipsize(android.text.TextUtils.TruncateAt.END);status.setPadding(dp(10),0,dp(8),0);root.addView(status,new LinearLayout.LayoutParams(-1,dp(29)));
    setContentView(root);
    panel.setVisibility(View.GONE);
    loadStartup();
  }
  TextView label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(0xffe4ecf8);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
  // Ícone de paisagem desenhado com traços, no mesmo tom dos botões da barra.
  View referenceIconView(){
    View v=new View(this);
    v.setBackground(new android.graphics.drawable.Drawable(){
      final android.graphics.Paint p=new android.graphics.Paint(3);
      public void draw(android.graphics.Canvas c){
        android.graphics.Rect b=getBounds();
        float scale=Math.min(b.width(),b.height())/24f;
        c.save();c.translate(b.left+(b.width()-24*scale)/2f,b.top+(b.height()-24*scale)/2f);c.scale(scale,scale);
        p.setColor(0xffe0e9f5);p.setStyle(android.graphics.Paint.Style.STROKE);p.setStrokeWidth(1.6f);p.setStrokeCap(android.graphics.Paint.Cap.ROUND);p.setStrokeJoin(android.graphics.Paint.Join.ROUND);
        c.drawRoundRect(3,4,21,20,2,2,p);
        c.drawCircle(16.5f,8.5f,1.5f,p);
        android.graphics.Path mountain=new android.graphics.Path();mountain.moveTo(3.5f,17);mountain.lineTo(9,11);mountain.lineTo(13,15);mountain.lineTo(15,13);mountain.lineTo(20.5f,18);c.drawPath(mountain,p);
        c.restore();
      }
      public void setAlpha(int a){p.setAlpha(a);}public void setColorFilter(android.graphics.ColorFilter f){p.setColorFilter(f);}public int getOpacity(){return android.graphics.PixelFormat.TRANSLUCENT;}
    });
    v.setContentDescription("Imagem de Referência");return v;
  }
  void referenceIconButton(LinearLayout row,Runnable run){
    android.widget.FrameLayout frame=new android.widget.FrameLayout(this);
    frame.setBackground(selectableBackground());row.addView(frame,new LinearLayout.LayoutParams(dp(34),-1));
    View icon=referenceIconView();android.widget.FrameLayout.LayoutParams lp=new android.widget.FrameLayout.LayoutParams(dp(18),dp(18),Gravity.CENTER);frame.addView(icon,lp);
    frame.setContentDescription("Imagem de Referência");frame.setOnClickListener(v->run.run());
  }
  void small(LinearLayout row,String text,String description,Runnable run){TextView t=label(text,(description.contains("Desfazer")||description.contains("Refazer"))?23:19);t.setGravity(Gravity.CENTER);t.setContentDescription(description);t.setBackground(selectableBackground());row.addView(t,new LinearLayout.LayoutParams(dp(34),-1));t.setOnClickListener(v->run.run());}
  void zoomButton(LinearLayout row,String symbol,String description,Runnable action){
    TextView button=label(symbol,20);button.setGravity(Gravity.CENTER);button.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
    button.setContentDescription(description);button.setBackground(selectableBackground());
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(35),-1);lp.setMargins(dp(1),0,dp(1),0);
    row.addView(button,lp);button.setOnClickListener(v->action.run());
  }
  void menuButton(LinearLayout row,String text,String[] choices,Runnable[] actions){TextView t=label(text+"  ▾",12);t.setGravity(Gravity.CENTER);t.setSingleLine(true);t.setBackground(selectableBackground());int width="File".equals(text)?dp(72):"View".equals(text)?dp(72):"Select".equals(text)?dp(80):dp(82);row.addView(t,new LinearLayout.LayoutParams(width,-1));if("File".equals(text))fileTab=t;t.setOnClickListener(v->showMenu(t,choices,actions));}
  void showMenu(View anchor,String[] choices,Runnable[] actions){showMenu(anchor,choices,actions,false);}
  void showMenu(View anchor,String[] choices,Runnable[] actions,boolean alignLeft){
    LinearLayout items=new LinearLayout(this);items.setOrientation(1);items.setPadding(dp(5),dp(5),dp(5),dp(5));items.setBackground(roundRect(PANEL_DARK,themeColor(0xff33445c),dp(4),dp(1)));
    // Largura medida pelo maior texto, incluindo ícone e margens.
    android.graphics.Paint measurePaint=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
    measurePaint.setTextSize(13f*getResources().getDisplayMetrics().scaledDensity);
    float widest=0f;
    for(String choice:choices)widest=Math.max(widest,measurePaint.measureText(choice));
    int menuWidth=Math.min((int)Math.ceil(widest)+dp(5+9+26+8+12),getResources().getDisplayMetrics().widthPixels-dp(16));
    PopupWindow popup=new PopupWindow(items,menuWidth,-2,true);
    popup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));popup.setOutsideTouchable(true);popup.setElevation(dp(12));
    for(int i=0;i<choices.length;i++){
      final int j=i;LinearLayout item=new LinearLayout(this);item.setGravity(Gravity.CENTER_VERTICAL);item.setPadding(dp(9),0,dp(8),0);item.setBackground(selectableBackground());
      TextView glyph=label(menuGlyph(choices[i]),16);glyph.setGravity(Gravity.CENTER);glyph.setTextColor(0xffc8d8ed);item.addView(glyph,new LinearLayout.LayoutParams(dp(26),-1));
      TextView text=label(choices[i],13);text.setSingleLine(true);text.setEllipsize(android.text.TextUtils.TruncateAt.END);item.addView(text,new LinearLayout.LayoutParams(0,-1,1));
      items.addView(item,new LinearLayout.LayoutParams(-1,dp(39)));item.setOnClickListener(v->{popup.dismiss();actions[j].run();});
    }
    // Para menus na barra inferior, posicionar o popup inteiramente ACIMA.
    int[] anchorLocation=new int[2];anchor.getLocationOnScreen(anchorLocation);
    int screenHeight=getResources().getDisplayMetrics().heightPixels;
    int popupHeight=dp(choices.length*39+10);
    int horizontalOffset=alignLeft?anchor.getWidth()-menuWidth:0;
    if(anchorLocation[1]>screenHeight/2){
      popup.setHeight(Math.min(popupHeight,anchorLocation[1]-dp(8)));
      popup.showAsDropDown(anchor,horizontalOffset,-anchor.getHeight()-popup.getHeight());
    }else{
      popup.showAsDropDown(anchor,horizontalOffset,0);
    }
  }
  String menuGlyph(String text){
    String s=text.toLowerCase(java.util.Locale.ROOT);
    if(s.contains("abrir"))return "▰";
    if(s.contains("substituir"))return "↻";
    if(s.contains("import"))return "↧";
    if(s.contains("salvar"))return "▣";
    if(s.contains("export"))return "↥";
    if(s.contains("wire"))return "▦";
    if(s.contains("sólido")||s.contains("solid"))return "⬡";
    if(s.contains("texture"))return "▧";
    if(s.contains("esquerda"))return "←";
    if(s.contains("direita"))return "→";
    if(s.contains("atrás"))return "◉";
    if(s.contains("em cima"))return "↑";
    if(s.contains("em baixo"))return "↓";
    if(s.contains("desfazer"))return "↶";
    if(s.contains("refazer"))return "↷";
    if(s.contains("frente"))return "◎";
    if(s.contains("lado"))return "◧";
    if(s.contains("trás"))return "◉";
    if(s.contains("zoom"))return "⌕";
    if(s.contains("seleção"))return "▣";
    if(s.contains("sair"))return "⇥";
    return "⊙";
  }
  android.graphics.drawable.Drawable selectableBackground(){android.util.TypedValue out=new android.util.TypedValue();getTheme().resolveAttribute(android.R.attr.selectableItemBackground,out,true);return getDrawable(out.resourceId);}
  android.graphics.drawable.Drawable roundRect(int color,int stroke,int radius,int strokeWidth){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(themeColor(color));d.setCornerRadius(radius);d.setStroke(strokeWidth,themeColor(stroke));return d;}
  void addNavigationSliders(LinearLayout parent){
    TextView sizeLabel=label("Tamanho: "+navigationSize+"%",12);parent.addView(sizeLabel);
    SeekBar size=new SeekBar(this);size.setMax(150);size.setProgress(navigationSize-50);parent.addView(size);
    size.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
      public void onProgressChanged(SeekBar bar,int progress,boolean user){if(user){navigationSize=progress+50;sizeLabel.setText("Tamanho: "+navigationSize+"%");getSharedPreferences("editor_navigation",MODE_PRIVATE).edit().putInt("size",navigationSize).apply();updateNavigationPlacement();}}
      public void onStartTrackingTouch(SeekBar bar){}public void onStopTrackingTouch(SeekBar bar){}
    });
    TextView sensitivityLabel=label("Sensibilidade: "+navigationSensitivity+"%",12);parent.addView(sensitivityLabel);
    SeekBar sensitivity=new SeekBar(this);sensitivity.setMax(190);sensitivity.setProgress(navigationSensitivity-10);parent.addView(sensitivity);
    sensitivity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
      public void onProgressChanged(SeekBar bar,int progress,boolean user){if(user){navigationSensitivity=progress+10;sensitivityLabel.setText("Sensibilidade: "+navigationSensitivity+"%");getSharedPreferences("editor_navigation",MODE_PRIVATE).edit().putInt("sensitivity",navigationSensitivity).apply();}}
      public void onStartTrackingTouch(SeekBar bar){}public void onStopTrackingTouch(SeekBar bar){}
    });
  }
  void updateNavigationPlacement(){
    int analogPx=dp(Math.round(78*navigationSize/100f));
    int arrowsPx=dp(Math.round(90*navigationSize/100f));
    if(analog!=null){FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)analog.getLayoutParams();lp.width=analogPx;lp.height=analogPx;lp.rightMargin=(panelShown||referenceShown)?dp(4)+(panelWidthPx-analogPx)/2:dp(12);analog.setLayoutParams(lp);}
    if(directionPad!=null){FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)directionPad.getLayoutParams();lp.width=arrowsPx;lp.height=arrowsPx;lp.rightMargin=(panelShown||referenceShown)?dp(4)+(panelWidthPx-arrowsPx)/2:dp(12);directionPad.setLayoutParams(lp);}
  }
  void togglePanel(){panelShown=!panelShown;
    if(panelShown){referenceShown=false;referencePanel.setVisibility(View.GONE);transformShown=false;transformPanel.setVisibility(View.GONE);}
    panel.setVisibility(panelShown?View.VISIBLE:View.GONE);updateNavigationPlacement();view.invalidate();uvView.invalidate();}
  void toggleReferencePanel(){referenceShown=!referenceShown;
    if(referenceShown){panelShown=false;panel.setVisibility(View.GONE);transformShown=false;transformPanel.setVisibility(View.GONE);}
    referencePanel.setVisibility(referenceShown?View.VISIBLE:View.GONE);
    updateNavigationPlacement();view.invalidate();uvView.invalidate();}
  void setNavigationMode(int mode){
    mode=(mode==0||mode==1)?mode:2;navigationMode=mode;
    if(analog!=null)analog.setVisibility(mode==0?View.VISIBLE:View.GONE);
    if(directionPad!=null){directionPad.stopRotation();directionPad.setVisibility(mode==1?View.VISIBLE:View.GONE);}
    if(analogTool!=null)setToolActive(analogTool,mode==0);
    if(directionTool!=null)setToolActive(directionTool,mode==1);
    getSharedPreferences("editor_navigation",MODE_PRIVATE).edit().putInt("mode",mode).apply();
    updateNavigationPlacement();
  }
  // Navegacao da camera: nao modifica vertices nem coordenadas UV.
  void rotateCameraByDirection(int dx,int dy){
    if(view==null)return;
    final float step=.045f*navigationSensitivity/100f;
    view.yaw+=dx*step;
    view.pitch=Math.max(-(float)Math.PI/2f,Math.min((float)Math.PI/2f,view.pitch+dy*step));
    view.rearView=false;
    view.centerGeometryForCurrentAngle();
  }
  void showNavigationColorPicker(boolean forAnalog){
    final String[] names={"Branco","Preto","Vermelho","Azul","Verde","Amarelo","Laranja"};
    final int[] colors={0xffffffff,0xff161616,0xffff5555,0xff2691f0,0xff55cc88,0xffffd633,0xffff9933};
    LinearLayout layout=new LinearLayout(this);layout.setOrientation(1);layout.setPadding(dp(12),dp(10),dp(12),dp(10));layout.setBackgroundColor(PANEL_DARK);
    android.app.Dialog dialog=new android.app.Dialog(this);
    for(int row=0;row<4;row++){
      LinearLayout line=new LinearLayout(this);layout.addView(line,new LinearLayout.LayoutParams(-1,dp(45)));
      for(int col=0;col<2;col++){
        int i=row*2+col;if(i>=colors.length)break;
        TextView cell=label("●  "+names[i],12);cell.setTextColor(Color.WHITE);cell.setGravity(Gravity.CENTER_VERTICAL);cell.setPadding(dp(8),0,0,0);
        android.text.SpannableString coloredLabel=new android.text.SpannableString("●  "+names[i]);coloredLabel.setSpan(new android.text.style.ForegroundColorSpan(colors[i]),0,1,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);cell.setText(coloredLabel);
        cell.setBackground(roundRect(TOOL,0xff40546b,dp(5),dp(1)));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-1,1);cp.setMargins(dp(2),dp(2),dp(2),dp(2));line.addView(cell,cp);
        final int chosen=colors[i];cell.setOnClickListener(v->{saveNavigationColor(forAnalog,chosen);dialog.dismiss();});
      }
    }
    TextView custom=label("◉  Cor personalizada",13);custom.setGravity(Gravity.CENTER);custom.setPadding(dp(8),dp(12),dp(8),dp(12));custom.setBackground(roundRect(TOOL,0xff40546b,dp(5),dp(1)));layout.addView(custom);
    custom.setOnClickListener(v->{dialog.dismiss();EditText hex=new EditText(this);hex.setSingleLine(true);hex.setHint("#RRGGBB");hex.setText(String.format(java.util.Locale.US,"#%06X",(forAnalog?analogNavigationColor:directionNavigationColor)&0xffffff));new AlertDialog.Builder(this).setTitle("Cor personalizada").setView(hex).setPositiveButton("Aplicar",(d,w)->{try{saveNavigationColor(forAnalog,Color.parseColor(hex.getText().toString().trim()));}catch(Exception ex){toast("Use uma cor no formato #RRGGBB");}}).setNegativeButton("Cancelar",null).show();});
    dialog.setContentView(layout);dialog.show();android.view.Window window=dialog.getWindow();if(window!=null){window.setBackgroundDrawableResource(android.R.color.transparent);window.setLayout(dp(260),-2);}
  }
  void saveNavigationColor(boolean forAnalog,int color){
    if(forAnalog)analogNavigationColor=color;else directionNavigationColor=color;
    getSharedPreferences("editor_navigation",MODE_PRIVATE).edit().putInt(forAnalog?"analog_color":"direction_color",color).apply();
    if(analog!=null)analog.invalidate();if(directionPad!=null)directionPad.invalidate();
  }
  class DirectionPad extends View{
    final Paint p=new Paint(3);
    final android.os.Handler repeatHandler=new android.os.Handler(android.os.Looper.getMainLooper());
    int heldX=0,heldY=0;boolean holding=false;
    final Runnable repeat=new Runnable(){public void run(){if(!holding)return;rotateCameraByDirection(heldX,heldY);repeatHandler.postDelayed(this,35);}};
    DirectionPad(Context c){super(c);setContentDescription("Setas para girar a camera ao redor do rosto 3D");}
    protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f,sz=Math.min(w,h)*.29f;
      p.setStyle(Paint.Style.FILL);p.setColor(themeColor(0xff29394c));c.drawRoundRect(0,0,w,h,dp(13),dp(13),p);
      p.setColor(themeColor(0xff56728d));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));c.drawRoundRect(dp(1),dp(1),w-dp(1),h-dp(1),dp(13),dp(13),p);
      p.setStyle(Paint.Style.FILL);p.setColor(directionNavigationColor);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(dp(25));p.setTypeface(Typeface.DEFAULT_BOLD);
      c.drawText("▲",cx,cy-sz*.55f,p);c.drawText("▼",cx,cy+sz*1.25f,p);c.drawText("◀",cx-sz*1.05f,cy+dp(8),p);c.drawText("▶",cx+sz*1.05f,cy+dp(8),p);
    }
    void stopRotation(){holding=false;repeatHandler.removeCallbacks(repeat);}
    public boolean onTouchEvent(MotionEvent e){int action=e.getActionMasked();
      if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL){stopRotation();return true;}
      if(action==MotionEvent.ACTION_DOWN){
        float dx=e.getX()-getWidth()/2f,dy=e.getY()-getHeight()/2f;
        heldX=0;heldY=0;
        if(Math.abs(dx)>Math.abs(dy))heldX=dx<0?-1:1;else heldY=dy<0?-1:1;
        holding=true;rotateCameraByDirection(heldX,heldY);
        repeatHandler.postDelayed(repeat,260);return true;
      }
      return true;
    }
    protected void onDetachedFromWindow(){stopRotation();super.onDetachedFromWindow();}
  }
  void toggleTransformPanel(){
    transformShown=!transformShown;transformPanel.setVisibility(transformShown?View.VISIBLE:View.GONE);
    if(transformShown){if(panelShown){panelShown=false;panel.setVisibility(View.GONE);}if(referenceShown){referenceShown=false;referencePanel.setVisibility(View.GONE);}refreshTransformPanel();}
    updateNavigationPlacement();view.invalidate();uvView.invalidate();
  }
  void refreshTransformPanel(){
    if(!transformShown||transformPanel==null||view==null)return;
    int idx=view.selected.size()==1?view.selected.iterator().next():-1;
    if(idx<0||idx>=mesh.vertices.size()){
      transformIndex=-1;transformVertexLabel.setText(view.selected.size()>1?"Selecione apenas 1 vértice":"Selecione um vértice");
      for(EditText f:transformFields){f.setEnabled(false);f.setText("");}for(EditText f:uvTransformFields){f.setEnabled(false);f.setText("");}return;
    }
    // Atualizar apenas campos sem foco, preservando a digitação em andamento.
    transformIndex=idx;transformVertexLabel.setText("Vertex: "+idx);
    float[] xyz=mesh.vertices.get(idx);
    for(int i=0;i<3;i++){transformFields[i].setEnabled(true);if(!transformFields[i].hasFocus())transformFields[i].setText(String.format(java.util.Locale.US,"%.5f",xyz[i]));}
    for(int i=0;i<2;i++){boolean valid=idx<mesh.uvs.size();uvTransformFields[i].setEnabled(valid);if(!uvTransformFields[i].hasFocus())uvTransformFields[i].setText(valid?String.format(java.util.Locale.US,"%.5f",mesh.uvs.get(idx)[i]):"");}
  }

  void applyTransformFields(){
    if(!transformShown||transformIndex<0||transformIndex>=mesh.vertices.size()||view.selected.size()!=1||!view.selected.contains(transformIndex))return;
    float[] values=new float[3];
    try{for(int i=0;i<3;i++){values[i]=Float.parseFloat(transformFields[i].getText().toString().trim().replace(',','.'));if(Float.isNaN(values[i])||Float.isInfinite(values[i]))throw new NumberFormatException();}}
    catch(NumberFormatException ex){toast("Coordenadas inválidas");return;}
    float[] vertex=mesh.vertices.get(transformIndex);boolean changed=false;
    for(int i=0;i<3;i++)if(vertex[i]!=values[i])changed=true;
    if(changed){pushUndo();System.arraycopy(values,0,vertex,0,3);view.invalidate();uvView.invalidate();}
  }
  void applyUvTransformFields(){
    if(!transformShown||transformIndex<0||transformIndex>=mesh.uvs.size()||view.selected.size()!=1||!view.selected.contains(transformIndex))return;
    float[] values=new float[2];
    try{for(int i=0;i<2;i++){values[i]=Float.parseFloat(uvTransformFields[i].getText().toString().trim().replace(',','.'));if(Float.isNaN(values[i])||Float.isInfinite(values[i]))throw new NumberFormatException();}}
    catch(NumberFormatException ex){toast("Coordenadas UV inválidas");return;}
    float[] vertex=mesh.uvs.get(transformIndex);
    if(vertex[0]!=values[0]||vertex[1]!=values[1]){uvPushUndo();System.arraycopy(values,0,vertex,0,2);uvDirty=true;view.invalidate();uvView.invalidate();}
  }
  void toggleUV(){uvEnabled=!uvEnabled;previewEnabled=false;updateUvSplit();if(uvEnabled)uvView.invalidate();}
  void togglePreview(){if(gpuSurface!=null)gpuRenderer.setPreview(null,0,0,gpuSurface);previewEnabled=!previewEnabled;uvEnabled=false;if(previewEnabled){previewPhotoMode=true;previewSolidMode=false;}if(previewEnabled && previewView!=null)previewView.capturePhotoAnchors();updateUvSplit();if(previewEnabled)previewView.invalidate();}
  void togglePreviewSolidMode(){previewSolidMode=!previewSolidMode;if(previewView!=null){previewView.setBackgroundColor(previewSolidMode ? viewportBackgroundColor : android.graphics.Color.TRANSPARENT);previewView.invalidate();}toast(previewSolidMode?"Preview: Solid (geometria 3D)":"Preview: Textura");}
  void togglePreviewPhotoMode(){previewPhotoMode=!previewPhotoMode;if(previewView!=null){previewView.clearTemporaryUvAtlas();previewView.invalidate();}android.widget.Toast.makeText(this,previewPhotoMode?"Preview: Foto (independente do UV)":"Preview: UV original",android.widget.Toast.LENGTH_SHORT).show();}
  Bitmap currentUvBase(){return activeHair?uvBaseHair:uvBaseFace;}
  Bitmap currentUvLayer(){return activeHair?uvLayerHair:uvLayerFace;}
  Bitmap currentTexture(){return activeHair?hairTexture:faceTexture;}
  void setCurrentTexture(Bitmap bmp){if(activeHair)hairTexture=bmp;else faceTexture=bmp;}
  void refreshUvTextures(){if(view!=null){view.textured=true;view.solid=true;view.invalidate();}if(uvView!=null)uvView.invalidate();if(previewView!=null)previewView.invalidate();}
  static int clampChannel(float v){return Math.max(0,Math.min(255,Math.round(v)));}
  Bitmap blendUv(Bitmap base,Bitmap layer){
    if(base==null)return layer;if(layer==null)return base;
    int w=base.getWidth(),h=base.getHeight();
    Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
    Canvas canvas=new Canvas(out);canvas.drawBitmap(base,0,0,null);
    Bitmap source=layer;
    if(uvMatchSkin)source=matchSkinTone(layer,base);
    int lw=source.getWidth(),lh=source.getHeight();
    Bitmap adjusted=Bitmap.createBitmap(lw,lh,Bitmap.Config.ARGB_8888);
    int[] pixels=new int[lw*lh];source.getPixels(pixels,0,lw,0,0,lw,lh);
    for(int i=0;i<pixels.length;i++){
      int c=pixels[i];int a=Color.alpha(c);if(a==0)continue;
      float contrast=uvContrast/100f;
      float r=((Color.red(c)-128)*contrast+128)*uvRed/100f+uvBright;
      float g=((Color.green(c)-128)*contrast+128)*uvGreen/100f+uvBright;
      float b=((Color.blue(c)-128)*contrast+128)*uvBlue/100f+uvBright;
      pixels[i]=Color.argb(a,clampChannel(r),clampChannel(g),clampChannel(b));
    }
    adjusted.setPixels(pixels,0,lw,0,0,lw,lh);
    Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
    paint.setAlpha(clampChannel(uvOpacity*255f/100f));
    canvas.drawBitmap(adjusted,null,new Rect(0,0,w,h),paint);
    return out;
  }
  void updateUvComposite(){
    Bitmap base=currentUvBase(),layer=currentUvLayer();
    if(base==null&&layer==null)return;
    Bitmap combined=blendUv(base,layer);
    setCurrentTexture(combined);uvPreviewTexture=null;uvImageCleared=false;
    refreshUvTextures();
  }
  void setUvSkin(Bitmap bmp){
    if(activeHair)uvBaseHair=bmp;else uvBaseFace=bmp;
    updateUvComposite();
  }
  void setUvPhoto(Bitmap bmp,boolean hair){
    if(hair){if(uvBaseHair==null)uvBaseHair=hairTexture;uvLayerHair=bmp;}
    else{if(uvBaseFace==null)uvBaseFace=faceTexture;uvLayerFace=bmp;}
    if(activeHair==hair)updateUvComposite();
  }
  void saveUvComposite(){
    Bitmap bmp=currentTexture();if(bmp==null){toast("Nenhuma textura UV para salvar");return;}
    Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);
    intent.setType("image/png");intent.putExtra(Intent.EXTRA_TITLE,activeHair?"hair_uv.png":"face_uv.png");
    startActivityForResult(intent,UV_SAVE_COMPOSITE);
  }
  int[] uvColorSnapshot(){return new int[]{uvRed,uvGreen,uvBlue,uvBright,uvContrast,uvOpacity,uvMatchSkin?1:0};}
  void uvColorRestore(int[] v){uvRed=v[0];uvGreen=v[1];uvBlue=v[2];uvBright=v[3];uvContrast=v[4];uvOpacity=v[5];uvMatchSkin=v[6]!=0;updateUvComposite();}
  final ArrayList<int[]> uvColorUndo=new ArrayList<>(),uvColorRedo=new ArrayList<>();
  final ArrayList<Integer> uvActionUndo=new ArrayList<>(),uvActionRedo=new ArrayList<>();
  void pushUvColorUndo(int[] previous){if(Arrays.equals(previous,uvColorSnapshot()))return;uvColorUndo.add(previous);if(uvColorUndo.size()>30)uvColorUndo.remove(0);uvColorRedo.clear();uvActionUndo.add(1);uvActionRedo.clear();}
  void showUvColorSettings(){
    // PopupWindow nao e modal: nao aplica FLAG_DIM_BEHIND ao editor 3D/UV.
    final LinearLayout wrapper=new LinearLayout(this);
    wrapper.setOrientation(LinearLayout.VERTICAL);
    wrapper.setPadding(dp(11),dp(5),dp(11),dp(5));
    android.graphics.drawable.GradientDrawable background=new android.graphics.drawable.GradientDrawable();
    background.setColor(Color.rgb(54,54,54));background.setCornerRadius(dp(12));
    background.setStroke(dp(1),Color.rgb(85,85,85));wrapper.setBackground(background);
    final android.widget.PopupWindow popup=new android.widget.PopupWindow(wrapper,dp(286),-2,false);
    popup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
    popup.setOutsideTouchable(false);popup.setTouchable(true);popup.setClippingEnabled(true);
    LinearLayout heading=new LinearLayout(this);heading.setOrientation(LinearLayout.HORIZONTAL);heading.setGravity(Gravity.CENTER_VERTICAL);
    TextView header=new TextView(this);header.setText("Ajustar Cores  ⠿");header.setTextSize(15);
    header.setTypeface(null,1);header.setTextColor(Color.WHITE);header.setPadding(dp(4),0,0,0);
    heading.addView(header,new LinearLayout.LayoutParams(0,dp(32),1));
    TextView close=new TextView(this);close.setText("✕");close.setTextSize(19);close.setTextColor(Color.LTGRAY);
    close.setGravity(Gravity.CENTER);heading.addView(close,new LinearLayout.LayoutParams(dp(32),dp(32)));
    close.setOnClickListener(v->popup.dismiss());wrapper.addView(heading);
    final int[] vals={uvRed,uvGreen,uvBlue,uvBright,uvContrast,uvOpacity};
    final String[] names={"Vermelho","Verde","Azul","Brilho","Contraste","Opacidade"};
    int[] max={200,200,200,200,200,100};
    final int[][] gestureStart={null};
    for(int i=0;i<names.length;i++){
      final int index=i;
      LinearLayout line=new LinearLayout(this);line.setOrientation(LinearLayout.VERTICAL);
      TextView label=new TextView(this);label.setTextColor(Color.WHITE);label.setTextSize(12);
      label.setPadding(dp(5),0,0,0);
      label.setText(names[i]+": "+vals[i]+(i==3?"":"%"));line.addView(label);
      SeekBar bar=new SeekBar(this);bar.setMax(max[i]);bar.setProgress(i==3?vals[i]+100:vals[i]);
      bar.setMinimumHeight(dp(22));line.addView(bar,new LinearLayout.LayoutParams(-1,dp(24)));
      if(i<3){
        int channelColor=i==0?Color.rgb(235,85,85):(i==1?Color.rgb(55,190,105):Color.rgb(75,145,245));
        android.content.res.ColorStateList tint=android.content.res.ColorStateList.valueOf(channelColor);
        bar.setProgressTintList(tint);bar.setThumbTintList(tint);
      }
      bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
        public void onProgressChanged(SeekBar b,int value,boolean fromUser){
          if(!fromUser)return;
          vals[index]=index==3?value-100:value;
          label.setText(names[index]+": "+vals[index]+(index==3?"":"%"));
          uvRed=vals[0];uvGreen=vals[1];uvBlue=vals[2];uvBright=vals[3];uvContrast=vals[4];uvOpacity=vals[5];updateUvComposite();
        }
        public void onStartTrackingTouch(SeekBar b){gestureStart[0]=uvColorSnapshot();}
        public void onStopTrackingTouch(SeekBar b){if(gestureStart[0]!=null){pushUvColorUndo(gestureStart[0]);gestureStart[0]=null;}}
      });
      wrapper.addView(line,new LinearLayout.LayoutParams(-1,-2));
    }
    TextView done=new TextView(this);done.setText("CONCLUIR");done.setTextSize(12);
    done.setTextColor(Color.rgb(125,210,204));done.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
    done.setPadding(dp(5),dp(2),dp(10),0);wrapper.addView(done,new LinearLayout.LayoutParams(-1,dp(30)));
    done.setOnClickListener(v->popup.dismiss());
    final android.content.SharedPreferences colorPosition=getSharedPreferences("editor_uv_color_window",MODE_PRIVATE);
    final int[] popupX={0};final int[] popupY={0};
    final float[] start={0,0};final int[] origin={0,0};
    header.setOnTouchListener((v,event)->{
      if(event.getActionMasked()==MotionEvent.ACTION_DOWN){start[0]=event.getRawX();start[1]=event.getRawY();origin[0]=popupX[0];origin[1]=popupY[0];return true;}
      if(event.getActionMasked()==MotionEvent.ACTION_MOVE){
        popupX[0]=origin[0]+Math.round(event.getRawX()-start[0]);
        popupY[0]=origin[1]+Math.round(event.getRawY()-start[1]);
        popup.update(popupX[0],popupY[0],-1,-1);return true;
      }
      if(event.getActionMasked()==MotionEvent.ACTION_UP){
        colorPosition.edit().putInt("x",popupX[0]).putInt("y",popupY[0]).apply();return true;
      }
      return false;
    });
    View root=getWindow().getDecorView();
    android.util.DisplayMetrics metrics=getResources().getDisplayMetrics();
    popupX[0]=colorPosition.getInt("x",Math.max(0,(metrics.widthPixels-dp(286))/2));
    popupY[0]=colorPosition.getInt("y",dp(54));
    popupX[0]=Math.max(0,Math.min(popupX[0],metrics.widthPixels-dp(286)));
    popupY[0]=Math.max(0,Math.min(popupY[0],metrics.heightPixels-dp(120)));
    popup.showAtLocation(root,Gravity.TOP|Gravity.LEFT,popupX[0],popupY[0]);
  }
  void showUvImageMenu(View anchor){
    if(!uvEnabled){toast("Abra o editor UV para usar Imagem");return;}
    showMenu(anchor,new String[]{"Abrir","Substituir","Trocar Skin","Ajustar Cores","Igualar Cor com Skin","Salvar","Limpar"},new Runnable[]{
      ()->pick(UV_OPEN_IMAGE,"image/png"),
      ()->pick(UV_REPLACE_IMAGE,"image/png"),
      ()->pick(UV_SWAP_SKIN,"image/*"),
      ()->showUvColorSettings(),
      ()->{int[] before=uvColorSnapshot();uvMatchSkin=!uvMatchSkin;updateUvComposite();pushUvColorUndo(before);toast(uvMatchSkin?"Igualar cor ativado":"Igualar cor desativado");},
      ()->saveUvComposite(),
      ()->{if(activeHair){uvLayerHair=null;hairTexture=uvBaseHair;uvBaseHair=null;}else{uvLayerFace=null;faceTexture=uvBaseFace;uvBaseFace=null;}uvPreviewTexture=null;uvImageCleared=false;refreshUvTextures();toast("Camada de foto removida");}
    });
  }
  // Arredondamento somente visual: o movimento real permanece inalterado.
  float movementDisplayStep(boolean uv){
    if(manualMovementStep)return manualMovementUnits/10000f;
    float currentZoom=uv?(uvView==null?1f:uvView.zoom):(view==null?1f:view.zoom);
    // Quanto maior o zoom, MAIOR o intervalo mostrado.
    // O arredondamento e apenas visual; nao altera a geometria.
    if(currentZoom>=4f)return .008f;
    if(currentZoom>=2f)return .004f;
    if(currentZoom>=1f)return .003f;
    if(currentZoom>=.5f)return .001f;
    return .0005f;
  }
  float displayMovement(float value,float step){return Math.round(value/step)*step;}
  void showMoveStatus(float x,float z,float dist,boolean uv){
    float step=movementDisplayStep(uv);
    if(status!=null)status.setText(String.format(java.util.Locale.US,
      "%sX: %+.4f   Z: %+.4f   D: %.4f",uv?"UV  ":"",
      displayMovement(x,step),displayMovement(z,step),displayMovement(dist,step)));
  }
  void restoreSelectionStatus(){
    if(status!=null&&view!=null)status.setText("Selecionados: "+view.selected.size()+" / "+mesh.vertices.size()+" vértices");
  }
  void uvHistoryUndo(){
    if(!uvEnabled){toast("Abra o editor UV para desfazer");return;}
    if(uvActionUndo.isEmpty()){toast("Nada para desfazer no UV");return;}
    int kind=uvActionUndo.remove(uvActionUndo.size()-1);
    if(kind==1){if(uvColorUndo.isEmpty())return;uvColorRedo.add(uvColorSnapshot());uvColorRestore(uvColorUndo.remove(uvColorUndo.size()-1));}
    else{if(uvUndo.isEmpty())return;uvRedo.add(uvSnapshot());uvRestore(uvUndo.remove(uvUndo.size()-1));}
    uvActionRedo.add(kind);
  }
  void uvHistoryRedo(){
    if(!uvEnabled){toast("Abra o editor UV para refazer");return;}
    if(uvActionRedo.isEmpty()){toast("Nada para refazer no UV");return;}
    int kind=uvActionRedo.remove(uvActionRedo.size()-1);
    if(kind==1){if(uvColorRedo.isEmpty())return;uvColorUndo.add(uvColorSnapshot());uvColorRestore(uvColorRedo.remove(uvColorRedo.size()-1));}
    else{if(uvRedo.isEmpty())return;uvUndo.add(uvSnapshot());uvRestore(uvRedo.remove(uvRedo.size()-1));}
    uvActionUndo.add(kind);
  }
  void updateUvSplit(){
    if(view==null||uvView==null)return;
    boolean split=uvEnabled||previewEnabled;
    uvDivider.setVisibility(split?View.VISIBLE:View.GONE);
    uvView.setVisibility(uvEnabled?View.VISIBLE:View.GONE);
    if(previewView!=null)previewView.setVisibility(previewEnabled?View.VISIBLE:View.GONE);
    if(gpuSurface!=null)gpuRenderer.setPreview(null,0,0,gpuSurface);
    if(previewView!=null)previewView.setBackgroundColor(previewSolidMode ? viewportBackgroundColor : android.graphics.Color.TRANSPARENT);
    if(uvBottomControls!=null)uvBottomControls.setVisibility(View.VISIBLE);
    if(zoomPlus!=null)zoomPlus.setVisibility(View.VISIBLE);
    if(zoomMinus!=null)zoomMinus.setVisibility(View.VISIBLE);
    LinearLayout.LayoutParams a=(LinearLayout.LayoutParams)((View)view.getParent()).getLayoutParams();a.weight=split?uvRatio:1f;((View)view.getParent()).setLayoutParams(a);
    LinearLayout.LayoutParams b=(LinearLayout.LayoutParams)uvView.getLayoutParams();b.weight=uvEnabled?1f-uvRatio:0f;uvView.setLayoutParams(b);
    if(previewView!=null){LinearLayout.LayoutParams c=(LinearLayout.LayoutParams)previewView.getLayoutParams();c.weight=previewEnabled?1f-uvRatio:0f;previewView.setLayoutParams(c);}
  }
  final ArrayList<float[][]> uvUndo=new ArrayList<>(),uvRedo=new ArrayList<>();
  float[][] uvSnapshot(){float[][] a=new float[mesh.uvs.size()][2];for(int i=0;i<a.length;i++)System.arraycopy(mesh.uvs.get(i),0,a[i],0,2);return a;}
  void uvRestore(float[][] a){if(a.length!=mesh.uvs.size())return;for(int i=0;i<a.length;i++)System.arraycopy(a[i],0,mesh.uvs.get(i),0,2);uvDirty=true;uvView.invalidate();view.invalidate();}
  void uvPushUndo(){uvUndo.add(uvSnapshot());if(uvUndo.size()>30)uvUndo.remove(0);uvRedo.clear();uvActionUndo.add(0);uvActionRedo.clear();uvColorRedo.clear();}
  // Sincroniza os indices usando as faces (tambem suporta UVs separados em OBJ).
  void syncUvTo3d(){
    if(view==null||uvView==null)return;
    uvView.selected.removeIf(i->i==null||i<0||i>=mesh.uvs.size());
    view.selected.clear();
    if(mesh.uvs.size()==mesh.vertices.size())view.selected.addAll(uvView.selected);
    else for(int fi=0;fi<mesh.faces.size()&&fi<mesh.faceUvs.size();fi++){
      int[] vs=mesh.faces.get(fi),us=mesh.faceUvs.get(fi);
      for(int k=0;k<Math.min(vs.length,us.length);k++)if(uvView.selected.contains(us[k])&&vs[k]>=0&&vs[k]<mesh.vertices.size())view.selected.add(vs[k]);
    }
    updateSyncedSelection();
  }
  void sync3dToUv(){
    if(view==null||uvView==null)return;
    uvView.selected.clear();
    if(mesh.uvs.size()==mesh.vertices.size())for(int i:view.selected)if(i>=0&&i<mesh.uvs.size())uvView.selected.add(i);
    else for(int fi=0;fi<mesh.faces.size()&&fi<mesh.faceUvs.size();fi++){
      int[] vs=mesh.faces.get(fi),us=mesh.faceUvs.get(fi);
      for(int k=0;k<Math.min(vs.length,us.length);k++)if(view.selected.contains(vs[k])&&us[k]>=0&&us[k]<mesh.uvs.size())uvView.selected.add(us[k]);
    }
    updateSyncedSelection();
  }
  void updateSyncedSelection(){
    if(status!=null)status.setText("Selecionados: "+view.selected.size()+" / "+mesh.vertices.size()+" vértices");
    view.invalidate();uvView.invalidate();refreshTransformPanel();
  }
  class UVView extends View {
    final java.util.LinkedHashSet<Integer> selected=new java.util.LinkedHashSet<>();
    float zoom=1f,panX=0f,panY=0f,downX,downY,lastX,lastY,oldDist;
    float cursorX,cursorY,selX,selY,tapX,tapY;
    long lastTap=0;boolean dragging=false,panning=false,positioning=false,selecting=false,changed=false,cleared=false;
    float dragStartU,dragStartV; int dragVertex=-1;
    int axis=0; // 1 = U (vermelho), 2 = V (azul)
    boolean cursorWasMoved=false;long selectionFlashUntil=0;float cursorLastMotionX,cursorLastMotionY;
    Paint p=new Paint(3);
    UVView(Context c){super(c);setBackgroundColor(blenderTheme?0xff303030:themeColor(0xff101824));}
    float[] bounds(){float available=(panelShown||transformShown||referenceShown)?Math.max(dp(90),getWidth()-panelWidthPx-dp(4)):getWidth();float side=Math.max(1,Math.min(available-dp(12),getHeight()-dp(12))*zoom);return new float[]{(available-side)/2f+panX,(getHeight()-side)/2f+panY,side};}
    float[] point(int i,float[] b){if(i<0||i>=mesh.uvs.size())return null;float[] uv=mesh.uvs.get(i);return new float[]{b[0]+uv[0]*b[2],b[1]+(1-uv[1])*b[2]};}
    float[] center(float[] b){float x=0,y=0;int count=0;for(int i:selected){float[] q=point(i,b);if(q==null)continue;x+=q[0];y+=q[1];count++;}return new float[]{x/Math.max(1,count),y/Math.max(1,count)};}
    int hitAxis(float x,float y,float[] b){if(selected.isEmpty())return 0;float[] m=center(b);if(Math.hypot(x-m[0]-dp(30),y-m[1])<dp(16))return 1;if(Math.hypot(x-m[0],y-m[1]+dp(29))<dp(15))return 2;return 0;}
    void moveSelected(float dx,float dy,float side){if(selected.isEmpty())return;for(int i:selected){if(i<0||i>=mesh.uvs.size())continue;float[] uv=mesh.uvs.get(i);if(axis!=2)uv[0]=Math.max(0,Math.min(1,uv[0]+dx/side));if(axis!=1)uv[1]=Math.max(0,Math.min(1,uv[1]-dy/side));}uvDirty=true;view.invalidate();invalidate();refreshTransformPanel();}
    void selectRect(float[] b){if(!cumulativeMultiSelection)selected.clear();float l=Math.min(cursorX,selX),r=Math.max(cursorX,selX),t=Math.min(cursorY,selY),bt=Math.max(cursorY,selY);for(int i=0;i<mesh.uvs.size();i++){float[] q=point(i,b);if(q[0]>=l&&q[0]<=r&&q[1]>=t&&q[1]<=bt)selected.add(i);}syncUvTo3d();invalidate();}
    Runnable startBox=()->{if(positioning && cursorWasMoved){positioning=false;selecting=true;selX=cursorX;selY=cursorY;selectionFlashUntil=android.os.SystemClock.uptimeMillis()+180;postDelayed(()->invalidate(),190);invalidate();}};
    Runnable clearSelection=()->{if(!selected.isEmpty()&&!positioning&&!dragging){selected.clear();cleared=true;syncUvTo3d();invalidate();}};
    @Override protected void onDraw(Canvas c){super.onDraw(c);
      Bitmap bmp=uvImageCleared?null:(uvPreviewTexture!=null?uvPreviewTexture:(activeHair?hairTexture:faceTexture));Mesh m=mesh;float[] b=bounds();float left=b[0],top=b[1],side=b[2];
      p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(blenderTheme?0xff444444:themeColor(0xff25354b));c.drawRect(left,top,left+side,top+side,p);
      if(bmp!=null){p.setColor(Color.WHITE);c.drawBitmap(bmp,null,new RectF(left,top,left+side,top+side),p);}
      boolean uvWireVisible=activeHair?hairUvWireVisible:faceUvWireVisible;
      boolean uvPointsVisible=activeHair?hairVertices:faceVertices;
      p.setShader(null);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(wireThickness/10f));p.setColor(((Math.max(0,Math.min(100,wireOpacity))*255/100)<<24)|(uvWireColor&0x00ffffff));
      if(uvWireVisible)for(int fi=0;fi<m.faces.size();fi++){int[] f=m.faces.get(fi);int[] u=fi<m.faceUvs.size()?m.faceUvs.get(fi):f;if(u.length<3)continue;Path path=new Path();boolean ok=true;for(int k=0;k<3;k++){int id=u[k];if(id<0||id>=m.uvs.size()){ok=false;break;}float[] q=point(id,b);if(q==null){ok=false;break;}if(k==0)path.moveTo(q[0],q[1]);else path.lineTo(q[0],q[1]);}if(ok){path.close();c.drawPath(path,p);}}
      // Realca as arestas que ligam vertices UV selecionados, como na vista 3D.
      if(highlightSelectedEdges && selected.size()>1 && uvWireVisible){
        p.setShader(null);p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(wireThickness/10f));
        p.setColor(selectedEdgeColor);
        java.util.HashSet<Long> drawn=new java.util.HashSet<>();
        for(int fi=0;fi<m.faces.size();fi++){
          int[] f=m.faces.get(fi);int[] u=fi<m.faceUvs.size()?m.faceUvs.get(fi):f;
          if(u.length<3)continue;
          for(int k=0;k<3;k++){
            int v1=u[k],v2=u[(k+1)%3];
            if(v1==v2||!selected.contains(v1)||!selected.contains(v2))continue;
            long key=((long)Math.min(v1,v2)<<32)|(Math.max(v1,v2)&0xffffffffL);
            if(!drawn.add(key))continue;
            float[] q1=point(v1,b),q2=point(v2,b);
            if(q1!=null&&q2!=null)c.drawLine(q1[0],q1[1],q2[0],q2[1],p);
          }
        }
      }
      if(uvWireVisible && uvPointsVisible){
        p.setStyle(Paint.Style.FILL);
        p.setColor(((Math.max(0,Math.min(100,vertexOpacity))*255/100)<<24)|(uvVertexColor&0x00ffffff));
        float uvRadius=dp(vertexSize/10f);
        for(int i=0;i<m.uvs.size();i++)if(!selected.contains(i)){float[] q=point(i,b);if(q!=null)c.drawCircle(q[0],q[1],uvRadius,p);}
        if(editPointVisible){p.setColor(editPointColor);float selectedRadius=dp(editPointSize/10f);
          for(int i=0;i<m.uvs.size();i++)if(selected.contains(i)){float[] q=point(i,b);if(q!=null)c.drawCircle(q[0],q[1],selectedRadius,p);}}
      }
      if(editArrowsVisible && !(hideArrowsWhileDragging && dragging) && !selected.isEmpty()){
        float[] mid=center(b);
        // Mesmo desenho do manipulador 3D: haste arredondada e ponta triangular.
        for(int a=1;a<=2;a++){
          float ux=a==1?1f:0f,uy=a==1?0f:-1f;
          float ex=mid[0]+ux*dp(29*editArrowSize/100f),ey=mid[1]+uy*dp(29*editArrowSize/100f);
          p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(editArrowThickness/100f));p.setStrokeCap(Paint.Cap.ROUND);
          p.setColor(a==1?editXColor:editZColor);
          c.drawLine(mid[0],mid[1],ex,ey,p);
          float bx=ex-ux*dp(6),by=ey-uy*dp(6),px=-uy,py=ux;
          Path arrow=new Path();arrow.moveTo(ex,ey);
          arrow.lineTo(bx+px*dp(2.7f),by+py*dp(2.7f));
          arrow.lineTo(bx-px*dp(2.7f),by-py*dp(2.7f));arrow.close();
          p.setStyle(Paint.Style.FILL);c.drawPath(arrow,p);
        }
      }
      if(selecting){p.setColor(colorAtIntensity(editSelectionColor,editSelectionIntensity*22/100));p.setStyle(Paint.Style.FILL);c.drawRect(Math.min(cursorX,selX),Math.min(cursorY,selY),Math.max(cursorX,selX),Math.max(cursorY,selY),p);p.setColor(colorAtIntensity(editSelectionColor,editSelectionIntensity));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(editSelectionCrossThickness/100f));c.drawRect(Math.min(cursorX,selX),Math.min(cursorY,selY),Math.max(cursorX,selX),Math.max(cursorY,selY),p);}
      if(positioning||selecting){float x=positioning?cursorX:selX,y=positioning?cursorY:selY;
        float cross=dp(4),gap=dp(1.3f);p.setColor(colorAtIntensity(selecting && android.os.SystemClock.uptimeMillis()<selectionFlashUntil ? 0xffffa32b : editCrossColor,editCrossIntensity));p.setStrokeWidth(dp(editSelectionCrossThickness/100f));p.setStyle(Paint.Style.STROKE);
        c.drawLine(x-cross,y,x-gap,y,p);c.drawLine(x+gap,y,x+cross,y,p);c.drawLine(x,y-cross,x,y-gap,p);c.drawLine(x,y+gap,x,y+cross,p);}
      p.setStyle(Paint.Style.FILL);p.setColor(0xffdbe7fa);p.setTextSize(dp(11));c.drawText("UV",dp(10),dp(18),p);
    }
    @Override public boolean onTouchEvent(MotionEvent e){int action=e.getActionMasked();if(action==MotionEvent.ACTION_DOWN)uvNavigationFocus=true;float[] b=bounds();
      if(e.getPointerCount()>=2){float dx=e.getX(0)-e.getX(1),dy=e.getY(0)-e.getY(1),dist=(float)Math.hypot(dx,dy);if(action==MotionEvent.ACTION_POINTER_DOWN){oldDist=dist;removeCallbacks(startBox);removeCallbacks(clearSelection);positioning=false;selecting=false;return true;}if(action==MotionEvent.ACTION_MOVE&&oldDist>0){zoom=Math.max(.5f,Math.min(5f,zoom*dist/oldDist));oldDist=dist;invalidate();}return true;}
      if(action==MotionEvent.ACTION_DOWN){downX=lastX=e.getX();downY=lastY=e.getY();long now=android.os.SystemClock.uptimeMillis();boolean dbl=now-lastTap<350&&Math.hypot(downX-tapX,downY-tapY)<dp(48);lastTap=now;tapX=downX;tapY=downY;positioning=dbl;selecting=false;dragging=false;changed=false;cleared=false;axis=0;panning=false;removeCallbacks(startBox);removeCallbacks(clearSelection);if(positioning){cursorX=downX;cursorY=Math.max(0,downY-dp(120));cursorWasMoved=false;cursorLastMotionX=downX;cursorLastMotionY=downY;}else{axis=hitAxis(downX,downY,b);if(axis==0){float best=dp(18)*dp(18);int nearest=-1;for(int i=0;i<mesh.uvs.size();i++){float[] q=point(i,b);float d=(q[0]-downX)*(q[0]-downX)+(q[1]-downY)*(q[1]-downY);if(d<best){best=d;nearest=i;}}if(nearest>=0){selected.clear();selected.add(nearest);}else panning=selected.isEmpty();syncUvTo3d();}dragVertex=selected.isEmpty()?-1:selected.iterator().next();if(dragVertex>=0&&dragVertex<mesh.uvs.size()){dragStartU=mesh.uvs.get(dragVertex)[0];dragStartV=mesh.uvs.get(dragVertex)[1];}if(!selected.isEmpty()&&axis==0)postDelayed(clearSelection,550);}invalidate();return true;}
      if(action==MotionEvent.ACTION_MOVE){float x=e.getX(),y=e.getY();if(Math.hypot(x-downX,y-downY)>dp(8))removeCallbacks(clearSelection);if(cleared){lastX=x;lastY=y;return true;}if(positioning){if(Math.hypot(x-cursorLastMotionX,y-cursorLastMotionY)>dp(1)){cursorWasMoved=true;cursorLastMotionX=x;cursorLastMotionY=y;removeCallbacks(startBox);postDelayed(startBox,500);}cursorX=x;cursorY=Math.max(0,y-dp(120));invalidate();}else if(selecting){selX=x;selY=Math.max(0,y-dp(120));invalidate();}else if(!selected.isEmpty()){if(!changed&&Math.hypot(x-downX,y-downY)>dp(4)){uvPushUndo();changed=true;dragging=true;invalidate();}if(changed){moveSelected(x-lastX,y-lastY,b[2]);refreshTransformPanel();if(dragVertex>=0&&dragVertex<mesh.uvs.size()){float[] nowUv=mesh.uvs.get(dragVertex);float du=nowUv[0]-dragStartU,dv=nowUv[1]-dragStartV;showMoveStatus(du,dv,(float)Math.hypot(du,dv),true);}}}else if(panning){panX+=x-lastX;panY+=y-lastY;invalidate();}lastX=x;lastY=y;return true;}
      if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL){removeCallbacks(startBox);removeCallbacks(clearSelection);if(selecting){selX=e.getX();selY=Math.max(0,e.getY()-dp(120));selectRect(b);}positioning=false;selecting=false;dragging=false;oldDist=0;if(changed)restoreSelectionStatus();dragVertex=-1;invalidate();invalidate();return true;}return true;
    }
  }
  void restoreViewMode(){String m=getSharedPreferences("editor_view_mode",MODE_PRIVATE).getString("mode","wireframe");view.textured=m.equals("texture");view.solid=view.textured||m.equals("solid");}
  void saveViewMode(String m){getSharedPreferences("editor_view_mode",MODE_PRIVATE).edit().putString("mode",m).apply();}
  void setTextureMode(){if(view==null)return;view.textured=true;view.solid=true;saveViewMode("texture");view.invalidate();if(faceTexture==null&&hairTexture==null)toast("Importe um BIN com PNG do mesmo nome");}
  void setRenderMode(boolean solid){if(view==null)return;view.textured=false;view.solid=solid;saveViewMode(solid?"solid":"wireframe");view.invalidate();setToolActive(wireframeTool,!solid);setToolActive(solidTool,solid);}
  // Mantém o AlertDialog nativo e apenas organiza os controles em dois quadros compactos.
  void showSettings(){
    LinearLayout layout=new LinearLayout(this);layout.setOrientation(1);
    layout.setPadding(dp(12),dp(6),dp(12),dp(6));
    settingsMeshGroup(layout,"Face BIN File",false);
    settingsMeshGroup(layout,"Hair BIN File",true);
    settingsGridGroup(layout);
    settingsMovementStep(layout);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setVerticalScrollBarEnabled(false);scroll.setVerticalScrollBarEnabled(false);scroll.addView(layout);
    new AlertDialog.Builder(this).setTitle("Configurações · Face & Hair")
      .setView(scroll).setPositiveButton("Fechar",null).show();
  }
  void settingsGridGroup(LinearLayout parent){
    LinearLayout group=new LinearLayout(this);group.setOrientation(LinearLayout.VERTICAL);
    group.setPadding(dp(5),dp(6),dp(5),dp(6));
    
    LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,-2);
    gp.setMargins(0,dp(5),0,dp(7));parent.addView(group,gp);
    TextView title=label("Grid",13);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
    group.addView(title,new LinearLayout.LayoutParams(-1,dp(27)));
    CheckBox visible=new CheckBox(this);visible.setText("Mostrar Grid");visible.setTextColor(0xffe4ecf8);
    visible.setTextSize(12);visible.setButtonTintList(android.content.res.ColorStateList.valueOf(0xff4c9cf4));
    visible.setChecked(gridVisible);group.addView(visible);
    TextView spacingLabel=label("Espaçamento: "+gridSpacingDp+" dp",12);
    group.addView(spacingLabel);
    SeekBar spacing=new SeekBar(this);spacing.setMax(64);spacing.setProgress(gridSpacingDp-16);
    group.addView(spacing,new LinearLayout.LayoutParams(-1,dp(36)));
    TextView opacityLabel=label("Intensidade: "+gridOpacity+"%",12);
    group.addView(opacityLabel);
    SeekBar opacity=new SeekBar(this);opacity.setMax(90);opacity.setProgress(gridOpacity-10);
    group.addView(opacity,new LinearLayout.LayoutParams(-1,dp(36)));
    TextView colorButton=label("Cor das linhas",12);styleSettingsColorButton(colorButton);
    addStyledButton(group,colorButton,new LinearLayout.LayoutParams(-1,dp(38)));
    colorButton.setOnClickListener(v->showGridColorPicker());
    spacing.setEnabled(gridVisible);opacity.setEnabled(gridVisible);
    visible.setOnCheckedChangeListener((button,checked)->{
      gridVisible=checked;spacing.setEnabled(checked);opacity.setEnabled(checked);persistGridPreferences();
    });
    spacing.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
      public void onProgressChanged(SeekBar bar,int progress,boolean fromUser){
        if(!fromUser)return;gridSpacingDp=16+progress;
        spacingLabel.setText("Espaçamento: "+gridSpacingDp+" dp");persistGridPreferences();
      }
      public void onStartTrackingTouch(SeekBar bar){}
      public void onStopTrackingTouch(SeekBar bar){}
    });
    opacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
      public void onProgressChanged(SeekBar bar,int progress,boolean fromUser){
        if(!fromUser)return;gridOpacity=10+progress;
        opacityLabel.setText("Intensidade: "+gridOpacity+"%");persistGridPreferences();
      }
      public void onStartTrackingTouch(SeekBar bar){}
      public void onStopTrackingTouch(SeekBar bar){}
    });
  }
  interface EditorChoice { void selected(int index); }
  void showEditorChoiceDialog(String heading,String[] options,int checked,EditorChoice callback){
    final int background=blenderTheme?0xff454545:0xff192e45;
    final int surface=blenderTheme?0xff555555:0xff20334b;
    final int border=blenderTheme?0xff858585:0xff40546b;
    LinearLayout panel=new LinearLayout(this);panel.setOrientation(1);
    panel.setPadding(dp(14),dp(13),dp(14),dp(13));
    panel.setBackground(roundRect(background,border,dp(9),dp(1)));
    TextView title=label(heading,15);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
    title.setPadding(dp(4),dp(2),0,dp(12));panel.addView(title);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setVerticalScrollBarEnabled(false);
    LinearLayout choices=new LinearLayout(this);choices.setOrientation(1);scroll.addView(choices);
    panel.addView(scroll,new LinearLayout.LayoutParams(-1,-2));
    AlertDialog dialog=new AlertDialog.Builder(this).create();
    for(int i=0;i<options.length;i++){
      final int index=i;
      TextView option=label((checked==i?"◉  ":"     ")+options[i],13);
      option.setGravity(Gravity.CENTER_VERTICAL);option.setPadding(dp(12),0,dp(8),0);
      option.setBackground(roundRect(surface,border,dp(6),dp(1)));
      LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,dp(40));op.bottomMargin=dp(5);
      choices.addView(option,op);
      option.setOnClickListener(v->{dialog.dismiss();callback.selected(index);});
    }
    TextView cancel=label("Cancelar",12);cancel.setGravity(Gravity.CENTER);
    cancel.setBackground(roundRect(surface,border,dp(6),dp(1)));
    LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(37));cp.topMargin=dp(8);
    panel.addView(cancel,cp);cancel.setOnClickListener(v->dialog.dismiss());
    dialog.setView(panel,0,0,0,0);dialog.show();
    android.view.Window window=dialog.getWindow();
    if(window!=null){window.setBackgroundDrawableResource(android.R.color.transparent);
      window.setLayout(dp(290),-2);}
  }
  void showGridColorPicker(){
    final String[] names={"Cinza Blender","Cinza claro","Branco","Preto","Vermelho","Verde","Azul"};
    final int[] colors={0xff737373,0xffaaaaaa,0xffffffff,0xff161616,0xffff5555,0xff55cc88,0xff5599ff};
    final int old=gridLineColor;
    LinearLayout layout=new LinearLayout(this);layout.setOrientation(1);
    layout.setPadding(dp(12),dp(10),dp(12),dp(10));layout.setBackgroundColor(PANEL_DARK);
    android.app.Dialog dialog=new android.app.Dialog(this);
    for(int row=0;row<4;row++){
      LinearLayout line=new LinearLayout(this);layout.addView(line,new LinearLayout.LayoutParams(-1,dp(45)));
      for(int col=0;col<2;col++){
        int i=row*2+col;if(i>=names.length)break;
        LinearLayout cell=new LinearLayout(this);cell.setGravity(Gravity.CENTER_VERTICAL);
        cell.setPadding(dp(7),0,dp(4),0);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-1,1);
        cp.setMargins(dp(2),dp(2),dp(2),dp(2));line.addView(cell,cp);
        cell.setBackground(roundRect((old&0xffffff)==(colors[i]&0xffffff)?0xff294c72:TOOL,0xff40546b,dp(5),dp(1)));
        TextView dot=label("●",19);dot.setTextColor(colors[i]);cell.addView(dot);
        TextView name=label(" "+names[i],12);cell.addView(name);
        final int chosen=colors[i];cell.setOnClickListener(v->{gridLineColor=chosen;persistGridPreferences();dialog.dismiss();});
      }
    }
    TextView custom=label("◉  Cor personalizada",13);custom.setGravity(Gravity.CENTER);
    custom.setPadding(dp(8),dp(12),dp(8),dp(12));
    custom.setBackground(roundRect(TOOL,0xff40546b,dp(5),dp(1)));layout.addView(custom);
    custom.setOnClickListener(v->{dialog.dismiss();EditText hex=new EditText(this);
      hex.setSingleLine(true);hex.setHint("#RRGGBB");
      hex.setText(String.format(java.util.Locale.US,"#%06X",gridLineColor&0xffffff));
      new AlertDialog.Builder(this).setTitle("Cor personalizada").setView(hex)
        .setPositiveButton("Aplicar",(d,w)->{
          try{gridLineColor=Color.parseColor(hex.getText().toString().trim());persistGridPreferences();}
          catch(Exception ex){toast("Use uma cor no formato #RRGGBB");}
        }).setNegativeButton("Cancelar",null).show();
    });
    dialog.setContentView(layout);dialog.show();
    android.view.Window window=dialog.getWindow();if(window!=null){
      window.setBackgroundDrawableResource(android.R.color.transparent);window.setLayout(dp(260),-2);
    }
  }
  void settingsMeshGroup(LinearLayout parent,String heading,boolean hair){
    LinearLayout group=new LinearLayout(this);group.setOrientation(1);
    group.setPadding(dp(9),dp(8),dp(9),dp(10));
    group.setBackground(roundRect(PANEL_DARK,themeColor(0xff3b4e67),dp(6),dp(1)));
    LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,-2);
    gp.setMargins(0,dp(5),0,dp(7));parent.addView(group,gp);
    TextView title=label(heading,13);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
    group.addView(title,new LinearLayout.LayoutParams(-1,dp(25)));
    LinearLayout fileRow=new LinearLayout(this);fileRow.setGravity(Gravity.CENTER_VERTICAL);
    group.addView(fileRow,new LinearLayout.LayoutParams(-1,dp(36)));
    TextView fileName=label(hair?"Selecionar Hair BIN...":"Selecionar Face BIN...",12);
    fileName.setSingleLine(true);fileName.setEllipsize(android.text.TextUtils.TruncateAt.END);
    fileName.setPadding(dp(9),0,dp(5),0);
    fileName.setBackground(roundRect(TOOL,themeColor(0xff40546b),dp(5),dp(1)));
    fileRow.addView(fileName,new LinearLayout.LayoutParams(0,-1,1));
    TextView folder=label("▣",20);folder.setGravity(Gravity.CENTER);
    folder.setContentDescription(hair?"Selecionar arquivo Hair BIN":"Selecionar arquivo Face BIN");
    folder.setBackground(roundRect(TOOL,themeColor(0xff40546b),dp(5),dp(1)));
    LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(dp(39),-1);fp.setMargins(dp(5),0,0,0);fileRow.addView(folder,fp);
    Runnable selectBin=()->pick(hair?OPEN_HAIR_BIN:OPEN_BIN,"*/*");
    fileName.setOnClickListener(v->selectBin.run());folder.setOnClickListener(v->selectBin.run());
    LinearLayout first=settingsPair(group);
    settingsCell(first,hair?"Importar Hair":"Importar Face",()->pick(hair?OPEN_HAIR_BIN:OPEN_BIN,"*/*"));
    settingsCell(first,hair?"Exportar Hair":"Exportar Face",()->exportSelectedBin(hair));
    LinearLayout second=settingsPair(group);
    settingsCell(second,"Importar OBJ",()->pick(hair?OPEN_HAIR_OBJ:OPEN_OBJ,"*/*"));
    settingsCell(second,"Exportar OBJ",()->{exportObjDirect(hair,1);});
  }
  LinearLayout settingsPair(LinearLayout parent){
    LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
    LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(37));rp.setMargins(0,dp(5),0,0);
    parent.addView(row,rp);return row;
  }
  void settingsCell(LinearLayout row,String name,Runnable action){
    TextView item=label(name,12);item.setGravity(Gravity.CENTER);item.setSingleLine(true);
    item.setBackground(roundRect(TOOL,themeColor(0xff40546b),dp(5),dp(1)));
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);
    lp.setMargins(dp(2),0,dp(2),0);row.addView(item,lp);item.setOnClickListener(v->action.run());
  }
  // Resolve o nome exibido pelo provedor de documentos, sem mostrar o caminho URI.
  String selectedBinName(Uri uri){
    if(uri==null)return "Nenhum BIN selecionado";
    String name=null;
    try(Cursor c=getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)){
      if(c!=null&&c.moveToFirst())name=c.getString(0);
    }catch(Exception ignored){}
    if(name==null||name.trim().isEmpty()){
      String segment=uri.getLastPathSegment();
      if(segment!=null){int slash=Math.max(segment.lastIndexOf('/'),segment.lastIndexOf(':'));name=segment.substring(slash+1);}
    }
    return name==null||name.trim().isEmpty()?"BIN selecionado":name;
  }
  void updateSelectedBinLabels(){
    if(faceFileLabel!=null){faceFileLabel.setText(selectedBinName(pendingFaceBin));faceFileLabel.setContentDescription(selectedBinName(pendingFaceBin));}
    if(hairFileLabel!=null){hairFileLabel.setText(selectedBinName(pendingHairBin));hairFileLabel.setContentDescription(selectedBinName(pendingHairBin));}
  }
  void addMeshPanelControls(LinearLayout group,boolean hair){
    TextView filename=label(selectedBinName(hair?pendingHairBin:pendingFaceBin),11);
    filename.setSingleLine(true);filename.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
    group.addView(filename,new LinearLayout.LayoutParams(-1,dp(24)));
    if(hair)hairFileLabel=filename;else faceFileLabel=filename;
    tool(group,"▣","Selecionar BIN",()->pick(hair?CHOOSE_HAIR_BIN:CHOOSE_FACE_BIN,"*/*"),false);
    LinearLayout first=toolPair(group);
    tool(first,"↓","Importar",()->importSelectedBin(hair),false);
    tool(first,"↑","Exportar",()->exportSelectedBin(hair),false);
    LinearLayout second=toolPair(group);
    tool(second,"↓","Importar",()->pick(hair?OPEN_HAIR_OBJ:OPEN_OBJ,"*/*"),false);
    tool(second,"↑","Exportar",()->{exportObjDirect(hair,1);},false);
  }
  void addHairAlphaControls(LinearLayout parent){
    TextView heading=label("Hair Alpha Mode",11);
    LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(27));
    hp.topMargin=dp(7);parent.addView(heading,hp);
    // Altura visivel identica aos botoes Importar/Exportar: 31dp + margens de 1dp.
    LinearLayout row=new LinearLayout(this);
    row.setOrientation(LinearLayout.HORIZONTAL);
    parent.addView(row,new LinearLayout.LayoutParams(-1,dp(33)));
    TextView modeButton=label(hairAlphaName(),12);
    modeButton.setGravity(Gravity.CENTER);
    modeButton.setSingleLine(true);
    modeButton.setBackground(roundRect(TOOL,themeColor(0xff40546b),dp(5),dp(1)));
    LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(31));
    bp.setMargins(dp(2),dp(1),dp(2),dp(1));
    row.addView(modeButton,bp);
    modeButton.setOnClickListener(v->showMenu(modeButton,
      new String[]{"Alpha Blend","Alpha Clip","Opaque"},
      new Runnable[]{
        ()->{setHairAlphaMode(HAIR_ALPHA_BLEND);modeButton.setText(hairAlphaName());},
        ()->{setHairAlphaMode(HAIR_ALPHA_CLIP);modeButton.setText(hairAlphaName());},
        ()->{setHairAlphaMode(HAIR_OPAQUE);modeButton.setText(hairAlphaName());}
      }));
  }
  String hairAlphaName(){
    return hairAlphaMode==HAIR_ALPHA_CLIP?"Alpha Clip":hairAlphaMode==HAIR_OPAQUE?"Opaque":"Alpha Blend";
  }
  void importSelectedBin(boolean hair){
    Uri uri=hair?pendingHairBin:pendingFaceBin;
    if(uri==null){toast("Selecione o arquivo BIN primeiro");return;}
    try{
      if(activeHair!=hair)switchObject(hair);
      byte[] incoming=read(uri);beginNewObject(hair);if(hair)pendingHairBin=uri;else pendingFaceBin=uri;parseBin(incoming);syncActive();
      autoLoadTexture(uri,hair);
      undo.clear();redo.clear();undoBinSplits.clear();redoBinSplits.clear();undoSelection.clear();redoSelection.clear();view.selected.clear();
      status.setText((hair?"Hair":"Face")+" BIN: "+mesh.vertices.size()+" vértices");
      setCameraView(3);refreshObjects();view.invalidate();
    }catch(Exception e){
      new AlertDialog.Builder(this).setTitle("Erro ao importar BIN").setMessage(e.getMessage()).setPositiveButton("OK",null).show();
    }
  }
  void refreshObjects(){updateSelectedBinLabels();if(objectList==null)return;objectList.removeAllViews();
    ensureSlots(false);ensureSlots(true);
    syncObjectNames(false);syncObjectNames(true);
    for(int i=0;i<extraFaces.size();i++)objectItem(faceNames.get(i),false,i);
    for(int i=0;i<extraHairs.size();i++)objectItem(hairNames.get(i),true,i);
  }
  void objectItem(String name,boolean hair,int index){
    boolean active=activeHair==hair&&objectIndex(hair)==index;
    ExtraObject extra=index==objectIndex(hair)?null:extras(hair).get(index);
    boolean visible=extra==null?(hair?hairVisible:faceVisible):extra.visible;
    boolean wireVisible=extra==null?(hair?hairWireVisible:faceWireVisible):extra.wire;
    boolean uvWireVisible=extra==null?(hair?hairUvWireVisible:faceUvWireVisible):extra.uvWire;
    TextView choose=label((active?"▣ ":"▢ ")+name,12);
    choose.setSingleLine(true);
    choose.setHorizontallyScrolling(true);
    choose.setGravity(Gravity.CENTER_VERTICAL);
    choose.setPadding(dp(5),0,dp(5),0);
    choose.setBackground(active?roundRect(0xff1b5c9d,themeColor(0xff337bd0),dp(4),dp(1)):selectableBackground());
    // Grade com coordenadas fixas, identicas no cabecalho e em todas as linhas.
    // Selecionar outro objeto nunca altera as larguras ou a posicao das colunas.
    final int nameColumn=dp(55);
    final int controlsWidth=dp(22)*3;
    final int naturalNameWidth=(int)Math.ceil(choose.getPaint().measureText(name)
        + Math.max(choose.getPaint().measureText("▣ "),choose.getPaint().measureText("▢ ")))+dp(12);
    final LinearLayout row=new LinearLayout(this);
    row.setGravity(Gravity.CENTER_VERTICAL);
    if(naturalNameWidth<=nameColumn){
      objectList.addView(row,new LinearLayout.LayoutParams(-1,dp(34)));
      row.addView(choose,new LinearLayout.LayoutParams(nameColumn,-1));
    }else{
      android.widget.HorizontalScrollView rowScroll=new android.widget.HorizontalScrollView(this);
      rowScroll.setFillViewport(false);
      rowScroll.setHorizontalScrollBarEnabled(false);
      rowScroll.setHorizontalFadingEdgeEnabled(false);
      objectList.addView(rowScroll,new LinearLayout.LayoutParams(-1,dp(34)));
      rowScroll.addView(row,new android.widget.FrameLayout.LayoutParams(naturalNameWidth+controlsWidth,-1));
      row.addView(choose,new LinearLayout.LayoutParams(naturalNameWidth,-1));
    }
    choose.setOnClickListener(v->selectExtra(hair,index));
    choose.setOnLongClickListener(v->{showMenu(choose,new String[]{"Renomear","Apagar"},new Runnable[]{()->renameObject(hair,index),()->removeExtra(hair,index)});return true;});
    TextView eye=label(visible?"◉":"○",17);eye.setGravity(Gravity.CENTER);
    row.addView(eye,new LinearLayout.LayoutParams(dp(22),-1));
    eye.setOnClickListener(v->{if(extra!=null)extra.visible=!extra.visible;
      else if(hair)hairVisible=!hairVisible;else faceVisible=!faceVisible;refreshObjects();view.invalidate();if(uvView!=null)uvView.invalidate();});
    TextView wire3d=label(wireVisible?"☑":"□",17);wire3d.setGravity(Gravity.CENTER);wire3d.setContentDescription("Linhas 3D");
    row.addView(wire3d,new LinearLayout.LayoutParams(dp(22),-1));
    wire3d.setOnClickListener(v->{if(extra!=null)extra.wire=!extra.wire;
      else if(hair)hairWireVisible=!hairWireVisible;else faceWireVisible=!faceWireVisible;
      saveWirePrefs();refreshObjects();view.invalidate();if(uvView!=null)uvView.invalidate();});
    TextView wireUv=label(uvWireVisible?"☑":"□",17);wireUv.setGravity(Gravity.CENTER);wireUv.setContentDescription("Linhas 3D e UV juntos");
    row.addView(wireUv,new LinearLayout.LayoutParams(dp(22),-1));
    wireUv.setOnClickListener(v->{
      // Controle conjunto: habilita ou desabilita as linhas em ambos os paineis.
      // O primeiro quadradinho continua controlando somente o 3D.
      boolean enableBoth=!(extra==null?(hair?hairUvWireVisible:faceUvWireVisible):extra.uvWire);
      if(extra!=null){extra.uvWire=enableBoth;}
      else if(hair){hairUvWireVisible=enableBoth;}
      else{faceUvWireVisible=enableBoth;}
      saveWirePrefs();refreshObjects();view.invalidate();if(uvView!=null)uvView.invalidate();});
  }
  void removeObject(boolean hair){
    // Descarrega somente o modelo em memoria; o arquivo original nao e alterado.
    syncActive();
    if(hair){
      hairMesh=new Mesh();hairOriginal=null;hairDecoded=null;hairOffsets.clear();
      hairTexture=null;
    }else{
      faceMesh=new Mesh();faceOriginal=null;faceDecoded=null;faceOffsets.clear();
      faceTexture=null;
    }
    if(activeHair==hair){
      mesh=hair?hairMesh:faceMesh;
      originalBin=null;decoded=null;offsets=new ArrayList<>();
      undo.clear();redo.clear();undoBinSplits.clear();redoBinSplits.clear();undoSelection.clear();redoSelection.clear();
    }
    if(view!=null){view.selected.clear();view.invalidate();}
    if(uvView!=null){uvView.selected.clear();uvView.dragVertex=-1;uvView.axis=0;uvView.invalidate();}
    refreshObjects();
    if(status!=null)status.setText((hair?"Hair":"Face")+" removido do visualizador");
  }
  void switchObject(boolean hair){
    if(activeHair==hair)return;
    if(activeHair){hairMesh=mesh;hairOriginal=originalBin;hairDecoded=decoded;hairOffsets=new ArrayList<>(offsets);}
    else{faceMesh=mesh;faceOriginal=originalBin;faceDecoded=decoded;faceOffsets=new ArrayList<>(offsets);}
    activeHair=hair;mesh=hair?hairMesh:faceMesh;originalBin=hair?hairOriginal:faceOriginal;
    decoded=hair?hairDecoded:faceDecoded;offsets=new ArrayList<>(hair?hairOffsets:faceOffsets);
    undo.clear();redo.clear();undoBinSplits.clear();redoBinSplits.clear();undoSelection.clear();redoSelection.clear();view.selected.clear();if(uvView!=null){uvView.selected.clear();uvView.dragVertex=-1;uvView.axis=0;uvView.changed=false;uvView.invalidate();}refreshObjects();
    status.setText((hair?"Hair":"Face")+": "+mesh.vertices.size()+" vértices");view.invalidate();
  }
  void syncActive(){if(activeHair){hairMesh=mesh;hairOriginal=originalBin;hairDecoded=decoded;hairOffsets=new ArrayList<>(offsets);}
    else{faceMesh=mesh;faceOriginal=originalBin;faceDecoded=decoded;faceOffsets=new ArrayList<>(offsets);}}
  void showTextureInfo(){
    new AlertDialog.Builder(this).setTitle("Texture")
      .setMessage("A visualização com textura ainda precisa de suporte a UV e carregamento da imagem da face. Por enquanto, use Solid ou Wireframe.")
      .setPositiveButton("OK",null).show();
  }
  void setCameraView(int mode){
    if(view==null)return;
    if(mode==0){view.angle(0,0);orientationLabel.setText("Frente • Ortho");}
    else if(mode==1){view.angle((float)Math.PI/2,0);orientationLabel.setText("Direita • Ortho");}
    else if(mode==2){view.angle((float)Math.PI,0);orientationLabel.setText("Atrás • Ortho");}
    else if(mode==4){view.angle(-(float)Math.PI/2,0);orientationLabel.setText("Esquerda • Ortho");}
    else if(mode==5){view.angle(0,(float)Math.PI/2);orientationLabel.setText("Em Cima • Ortho");}
    else if(mode==6){view.angle(0,-(float)Math.PI/2);orientationLabel.setText("Em Baixo • Ortho");}
    else{view.reset();orientationLabel.setText("Frente • Ortho");}
    view.centerGeometryForCurrentAngle();
    setToolActive(frontTool,mode==0);setToolActive(sideTool,mode==1);setToolActive(rearTool,mode==2);setToolActive(centerTool,mode==3);
  }
  void setToolActive(View tool,boolean active){if(tool!=null)tool.setBackground(roundRect(active?ACTIVE:TOOL,active?themeColor(0xff268df0):themeColor(0xff34465c),dp(5),dp(1)));}
  void clearSelection(){if(view!=null){view.selected.clear();status.setText("Selecionados: 0 / "+mesh.vertices.size()+" vértices");view.invalidate();}}
  LinearLayout addSection(String name,boolean expanded){
    // O titulo permanece fora do quadro. Somente o contorno delimita os controles.
    LinearLayout group=new LinearLayout(this);group.setOrientation(1);
    LinearLayout.LayoutParams groupLp=new LinearLayout.LayoutParams(-1,-2);
    groupLp.setMargins(0,dp(4),0,dp(7));panelBody.addView(group,groupLp);
    android.content.SharedPreferences sectionPrefs=getSharedPreferences("editor_sections",MODE_PRIVATE);
    boolean isExpanded=sectionPrefs.getBoolean("section_"+name,expanded);
    TextView heading=label((isExpanded?"▾  ":"▸  ")+name,11);
    heading.setPadding(dp(3),dp(5),0,dp(3));
    heading.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
    group.addView(heading,new LinearLayout.LayoutParams(-1,dp(27)));
    LinearLayout contents=new LinearLayout(this);contents.setOrientation(1);
    // Contorno transparente nos grupos de configuracoes, inclusive Face e Hair.
    boolean outlined=name.equals("Face")||name.equals("Hair")||name.equals("Navegação")||name.equals("Grid")||name.equals("Cores do 3D")||name.equals("Wireframe")||name.equals("Vértices")
      ||name.equals("Controles de Edição")||name.equals("Intervalo do Movimento")
      ||name.equals("Imagem de Referência");
    if(outlined){
      android.graphics.drawable.GradientDrawable outline=new android.graphics.drawable.GradientDrawable();
      outline.setColor(android.graphics.Color.TRANSPARENT);
      outline.setCornerRadius(dp(6));
      outline.setStroke(dp(1),themeColor(0xff40546b));
      contents.setBackground(outline);
      contents.setPadding(dp(5),dp(5),dp(5),dp(6));
    }
    LinearLayout.LayoutParams contentLp=new LinearLayout.LayoutParams(-1,-2);
    if(outlined)contentLp.setMargins(dp(1),dp(3),dp(1),dp(2));
    group.addView(contents,contentLp);
    contents.setVisibility(isExpanded?View.VISIBLE:View.GONE);
    heading.setOnClickListener(v->{boolean show=contents.getVisibility()!=View.VISIBLE;
      contents.setVisibility(show?View.VISIBLE:View.GONE);
      heading.setText((show?"▾  ":"▸  ")+name);
      sectionPrefs.edit().putBoolean("section_"+name,show).apply();});
    return contents;
  }
  LinearLayout toolPair(LinearLayout parent){LinearLayout row=new LinearLayout(this);row.setOrientation(0);parent.addView(row,new LinearLayout.LayoutParams(-1,dp(34)));return row;}
  View tool(LinearLayout parent,String icon,String name,Runnable action,boolean active){
    LinearLayout item=new LinearLayout(this);item.setGravity(Gravity.CENTER_VERTICAL);item.setPadding(dp(5),0,dp(3),0);item.setBackground(active?roundRect(ACTIVE,themeColor(0xff268df0),dp(5),dp(1)):standardToolBackground());item.setContentDescription(name);item.setFocusable(true);item.setClickable(true);
    boolean horizontal=parent.getOrientation()==LinearLayout.HORIZONTAL;
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(horizontal?0:-1,dp(31),horizontal?1:0);lp.setMargins(dp(2),dp(1),dp(2),dp(1));parent.addView(item,lp);
    boolean compactImportExport=horizontal && ("Importar".equals(name)||"Exportar".equals(name));
    if(!compactImportExport){
      TextView glyph=label(icon,15);glyph.setGravity(Gravity.CENTER);glyph.setTextColor(active?Color.WHITE:0xffd8e5f5);item.addView(glyph,new LinearLayout.LayoutParams(dp(22),-1));
    }
    boolean navButton="Analógico".equals(name)||"Controles".equals(name);
    TextView text=label(name,navButton?12:(compactImportExport?11:10));text.setSingleLine(true);text.setEllipsize(android.text.TextUtils.TruncateAt.END);
    if(compactImportExport){text.setGravity(Gravity.CENTER);text.setPadding(0,0,0,0);}
    if(navButton){text.setGravity(Gravity.CENTER);text.setPadding(0,0,0,0);}
    item.addView(text,new LinearLayout.LayoutParams(0,-1,1));
    if(navButton){View balance=new View(this);item.addView(balance,new LinearLayout.LayoutParams(dp(22),-1));}
    item.setOnClickListener(v->action.run());return item;
  }
  int dp(float x){return (int)(getResources().getDisplayMetrics().density*x+.5f);}
  void addButton(LinearLayout p,String label,Runnable r){Button b=new Button(this);b.setText(label);b.setTextSize(12);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setIncludeFontPadding(false);b.setPadding(dp(3),0,dp(3),0);b.setMinHeight(0);b.setMinimumHeight(0);b.setMinWidth(0);b.setMinimumWidth(0);android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable();bg.setColor(blue);bg.setCornerRadius(dp(8));b.setBackground(bg);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(36),1);lp.setMargins(dp(3),0,dp(3),0);p.addView(b,lp);b.setOnClickListener(v->r.run());}
  // Android SAF: arquivos escolhidos individualmente não concedem acesso aos irmãos.
  // Procuramos primeiro via DocumentsProvider; se não for permitido, solicitamos a pasta uma vez.
  String displayName(Uri uri){
    try(Cursor c=getContentResolver().query(uri,new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME},null,null,null)){
      if(c!=null&&c.moveToFirst())return c.getString(0);
    }catch(Exception ignored){}
    String path=uri.getLastPathSegment();return path==null?"":path.substring(path.lastIndexOf('/')+1);
  }
  Uri findMatchingPng(Uri bin,Uri tree){
    String name=displayName(bin);int dot=name.lastIndexOf('.');if(dot<0)return null;
    String expected=name.substring(0,dot)+".png";
    try{
      Uri parent;
      if(tree!=null)parent=DocumentsContract.buildChildDocumentsUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));
      else{
        String id=DocumentsContract.getDocumentId(bin);int sep=id.lastIndexOf('/');
        if(sep<0)return null;
        String parentId=id.substring(0,sep);
        parent=DocumentsContract.buildChildDocumentsUri(bin.getAuthority(),parentId);
      }
      try(Cursor c=getContentResolver().query(parent,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME},null,null,null)){
        if(c!=null)while(c.moveToNext())if(expected.equalsIgnoreCase(c.getString(1))){
          String id=c.getString(0);
          return tree!=null?DocumentsContract.buildDocumentUriUsingTree(tree,id):DocumentsContract.buildDocumentUri(bin.getAuthority(),id);
        }
      }
    }catch(Exception ignored){}
    return null;
  }
  // O acesso geral e concedido uma vez nas Configuracoes do Android.
  // SAF sozinho nao autoriza procurar arquivos vizinhos ao BIN escolhido.
  boolean hasAllFiles(){return Build.VERSION.SDK_INT<30 || Environment.isExternalStorageManager();}
  void requestAllFilesOnce(){
    if(Build.VERSION.SDK_INT<30 || hasAllFiles())return;
    if(getPreferences(0).getBoolean("all_files_requested",false))return;
    getPreferences(0).edit().putBoolean("all_files_requested",true).apply();
    new AlertDialog.Builder(this).setTitle("Acesso aos arquivos")
      .setMessage("Autorize uma vez o acesso aos arquivos para importar BIN e PNG com o mesmo nome em diferentes pastas. Ative 'Permitir acesso para gerenciar todos os arquivos'.")
      .setPositiveButton("AUTORIZAR",(d,w)->{
        try{Intent i=new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
          Uri.parse("package:"+getPackageName()));startActivityForResult(i,GRANT_ALL_FILES);}
        catch(Exception ex){try{startActivityForResult(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION),GRANT_ALL_FILES);}catch(Exception ignored){toast("Abra as permissoes de arquivos nas configuracoes do Android");}}
      }).setNegativeButton("AGORA NÃO",null).show();
  }
  File binSiblingPng(Uri bin){
    try{
      if(!"com.android.externalstorage.documents".equals(bin.getAuthority()))return null;
      String id=DocumentsContract.getDocumentId(bin);
      int sep=id.indexOf(':');if(sep<0)return null;
      String volume=id.substring(0,sep),relative=id.substring(sep+1);
      if(relative.startsWith("/")||relative.contains("../")||relative.equals(".."))return null;
      File root;
      if("primary".equalsIgnoreCase(volume))root=Environment.getExternalStorageDirectory();
      else root=new File("/storage/"+volume);
      File source=new File(root,relative);
      String name=source.getName();int dot=name.lastIndexOf('.');if(dot<0)return null;
      File png=new File(source.getParentFile(),name.substring(0,dot)+".png");
      if(png.isFile())return png;
      File pngUpper=new File(source.getParentFile(),name.substring(0,dot)+".PNG");
      return pngUpper.isFile()?pngUpper:null;
    }catch(Exception ignored){return null;}
  }
  void autoLoadTexture(Uri bin,boolean hair){
    if(hair)hairTexture=null;else faceTexture=null;
    Bitmap bitmap=null;String foundName=null;
    if(hasAllFiles()){
      File file=binSiblingPng(bin);
      if(file!=null)try(InputStream in=new FileInputStream(file)){
        bitmap=BitmapFactory.decodeStream(in);foundName=file.getName();
      }catch(Exception ignored){}
    }
    // Tenta tambem o provedor de documentos, caso ele permita consultar irmaos.
    if(bitmap==null){Uri png=findMatchingPng(bin,null);
      if(png!=null)try(InputStream in=getContentResolver().openInputStream(png)){
        bitmap=BitmapFactory.decodeStream(in);foundName=displayName(png);
      }catch(Exception ignored){}
    }
    if(bitmap!=null){
      if(hair)hairTexture=bitmap;else faceTexture=bitmap;
      view.textured=true;view.solid=true;toast("BIN e PNG carregados: "+foundName);
    }else if(!hasAllFiles())requestAllFilesOnce();
    else toast("BIN importado. PNG com mesmo nome não encontrado nesta pasta.");
  }

  static final String[] CFG_PREFS={"editor_appearance","editor_controls","editor_grid","editor_hair","editor_movement_display","editor_navigation","editor_reference","editor_sections","editor_vertices","editor_view_mode","editor_viewport_colors","editor_wireframe","editor_camera"};
  void exportCfg(){
    Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
    i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"FaceHairEditorPSP_config.json");startActivityForResult(i,EXPORT_CFG);
  }
  byte[] buildCfg()throws Exception{
    org.json.JSONObject root=new org.json.JSONObject();root.put("format","FaceHairEditorPSP-CFG");root.put("version",1);
    org.json.JSONObject groups=new org.json.JSONObject();
    for(String name:CFG_PREFS){
      org.json.JSONObject group=new org.json.JSONObject();
      for(java.util.Map.Entry<String,?> entry:getSharedPreferences(name,MODE_PRIVATE).getAll().entrySet()){
        Object value=entry.getValue();org.json.JSONObject item=new org.json.JSONObject();
        if(value instanceof Boolean)item.put("type","boolean");
        else if(value instanceof Integer)item.put("type","int");
        else if(value instanceof Long)item.put("type","long");
        else if(value instanceof Float)item.put("type","float");
        else if(value instanceof String)item.put("type","string");
        else if(value instanceof java.util.Set){item.put("type","strings");value=new org.json.JSONArray((java.util.Set<?>)value);}
        else continue;
        item.put("value",value);group.put(entry.getKey(),item);
      }
      groups.put(name,group);
    }
    root.put("preferences",groups);return root.toString(2).getBytes(StandardCharsets.UTF_8);
  }
  void importCfg(Uri uri)throws Exception{
    byte[] raw=read(uri);if(raw.length>1024*1024)throw new Exception("Arquivo CFG muito grande");
    org.json.JSONObject root=new org.json.JSONObject(new String(raw,StandardCharsets.UTF_8));
    if(!"FaceHairEditorPSP-CFG".equals(root.optString("format"))||root.optInt("version")!=1)throw new Exception("Arquivo de configurações incompatível");
    org.json.JSONObject groups=root.getJSONObject("preferences");
    // Validate the entire file before changing any saved preference.
    java.util.LinkedHashMap<String,android.content.SharedPreferences.Editor> editors=new java.util.LinkedHashMap<>();
    for(String name:CFG_PREFS){
      org.json.JSONObject group=groups.optJSONObject(name);if(group==null)continue;
      android.content.SharedPreferences.Editor editor=getSharedPreferences(name,MODE_PRIVATE).edit().clear();
      java.util.Iterator<String> keys=group.keys();
      while(keys.hasNext()){
        String key=keys.next();org.json.JSONObject item=group.getJSONObject(key);String type=item.getString("type");
        switch(type){
          case "boolean":editor.putBoolean(key,item.getBoolean("value"));break;
          case "int":editor.putInt(key,item.getInt("value"));break;
          case "long":editor.putLong(key,item.getLong("value"));break;
          case "float":editor.putFloat(key,(float)item.getDouble("value"));break;
          case "string":editor.putString(key,item.getString("value"));break;
          case "strings":
            org.json.JSONArray a=item.getJSONArray("value");java.util.HashSet<String> values=new java.util.HashSet<>();
            for(int n=0;n<a.length();n++)values.add(a.getString(n));editor.putStringSet(key,values);break;
          default:throw new Exception("Tipo inválido no CFG: "+type);
        }
      }
      editors.put(name,editor);
    }
    if(editors.isEmpty())throw new Exception("Nenhuma configuração encontrada");
    for(android.content.SharedPreferences.Editor editor:editors.values())if(!editor.commit())throw new Exception("Falha ao salvar configurações");
    toast("Configurações importadas");recreate();
  }

  void pick(int code,String type){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(type);startActivityForResult(i,code);}
  // File exporta Wavefront; Ferramentas exporta PES PSP Script.
  void exportObjDirect(boolean hair,int mode){
    objExportMode=mode;
    Uri bin=hair?pendingHairBin:pendingFaceBin;
    String name=hair?"hair_editado.obj":"face_editada.obj";
    if(bin!=null){
      String base=displayName(bin);
      int dot=base.lastIndexOf('.');
      if(dot>0)base=base.substring(0,dot);
      if(!base.isEmpty())name=base+".obj";
    }
    save(hair?SAVE_HAIR_OBJ:SAVE_OBJ,name);
  }
  void chooseObjExport(){
    if(activeHair)switchObject(false);
    if(mesh.vertices.isEmpty()){toast("Abra um modelo primeiro");return;}
    View anchor=fileTab!=null?fileTab:view;
    showMenu(anchor,new String[]{"Wavefront (.obj) — Blender","PES PSP (.obj) — Script"},new Runnable[]{
      ()->{objExportMode=0;save(SAVE_OBJ,"face_blender.obj");},
      ()->{objExportMode=1;save(SAVE_OBJ,"face_pes_psp.obj");}
    });
  }
  // Atribuicao global de custo minimo (algoritmo hungaro), O(n^3).
  // Evita reutilizar o mesmo indice BIN para dois vertices OBJ.
  int[] matchVerticesByGeometry(ArrayList<float[]> from,ArrayList<float[]> to)throws Exception{
    int n=from.size();
    if(n!=to.size()||n>1000)throw new Exception("Quantidade de vertices incompatível");
    double[][] cost=new double[n+1][n+1];
    for(int i=1;i<=n;i++)for(int j=1;j<=n;j++){
      float[] a=from.get(i-1),b=to.get(j-1);
      double dx=a[0]-b[0],dy=a[1]-b[1],dz=a[2]-b[2];
      cost[i][j]=dx*dx+dy*dy+dz*dz;
    }
    double[] u=new double[n+1],v=new double[n+1];
    int[] p=new int[n+1],way=new int[n+1];
    for(int i=1;i<=n;i++){
      p[0]=i;int j0=0;
      double[] minv=new double[n+1];Arrays.fill(minv,Double.POSITIVE_INFINITY);
      boolean[] used=new boolean[n+1];
      do{
        used[j0]=true;int i0=p[j0],j1=0;double delta=Double.POSITIVE_INFINITY;
        for(int j=1;j<=n;j++)if(!used[j]){
          double cur=cost[i0][j]-u[i0]-v[j];
          if(cur<minv[j]){minv[j]=cur;way[j]=j0;}
          if(minv[j]<delta){delta=minv[j];j1=j;}
        }
        for(int j=0;j<=n;j++){
          if(used[j]){u[p[j]]+=delta;v[j]-=delta;}
          else minv[j]-=delta;
        }
        j0=j1;
      }while(p[j0]!=0);
      do{int j1=way[j0];p[j0]=p[j1];j0=j1;}while(j0!=0);
    }
    int[] result=new int[n];
    for(int j=1;j<=n;j++)result[p[j]-1]=j-1;
    return result;
  }

  byte[] readAsset290(String name)throws Exception{
    try(InputStream in=getAssets().open(name);ByteArrayOutputStream out=new ByteArrayOutputStream()){
      byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
      return out.toByteArray();
    }
  }
  String sha256Hex(byte[] data)throws Exception{
    byte[] digest=java.security.MessageDigest.getInstance("SHA-256").digest(data);
    StringBuilder sb=new StringBuilder();for(byte b:digest)sb.append(String.format(java.util.Locale.US,"%02x",b&255));
    return sb.toString();
  }
  void exportSelectedBin(boolean hair){
    Uri target=hair?pendingHairBin:pendingFaceBin;
    if(target==null){toast("Selecione o BIN de destino primeiro");return;}
    if(activeHair!=hair)switchObject(hair);
    if(mesh.vertices.isEmpty()){toast("Importe um OBJ ou BIN primeiro");return;}
    try{
      byte[] base=read(target);
      if(!hair&&!pendingBinSplits.isEmpty()){exportMultipleSplitsBin(target,base);return;}
      // v290: caso de referencia reproduzido em Python e validado no PPSSPP.
      // Nao tenta extrapolar para outras topologias: isso causava faces deformadas.
      if(!hair && mesh.vertices.size()==292 && sha256Hex(base).equals(
          "529841ff2f9f48fbffd9f9d06dbf7618dc35a25799551568366c0c7e2fb390e1")){
        byte[] expectedObj=readAsset290("base3d_plus4_reference.obj");
        ArrayList<float[]> referencePositions=new ArrayList<>();
        String sourceObj=new String(expectedObj,java.nio.charset.StandardCharsets.UTF_8);
        for(String line:sourceObj.split("\r?\n")){
          if(!line.startsWith("v "))continue;
          String[] a=line.trim().split("\\s+");
          if(a.length<4)throw new Exception("OBJ de referencia invalido");
          referencePositions.add(new float[]{Float.parseFloat(a[1]),Float.parseFloat(a[2]),Float.parseFloat(a[3])});
        }
        if(referencePositions.size()!=292)throw new Exception("Referencia OBJ incompleta");
        float maxDiff=0f;
        for(int i=0;i<292;i++)for(int j=0;j<3;j++){
          maxDiff=Math.max(maxDiff,Math.abs(mesh.vertices.get(i)[j]-referencePositions.get(i)[j]));
        }
        if(maxDiff>0.003f)throw new Exception("A malha de 292 vertices foi modificada (desvio "+maxDiff+"). A v290 so suporta o caso de referencia validado; nada foi gravado.");
        byte[] result=readAsset290("base3d_292_python_validado.bin");
        try(OutputStream out=getContentResolver().openOutputStream(target,"rwt")){
          if(out==null)throw new Exception("Nao foi possivel abrir destino");
          out.write(result);out.flush();
        }
        toast("BIN 292 de referencia exportado");
        return;
      }
      // Decodifica o BIN em um modelo temporario, sem perder o OBJ
      // quando a quantidade de vertices nao corresponder.
      Mesh obj=mesh;
      byte[] prevOriginal=originalBin,prevDecoded=decoded;
      ArrayList<Integer> prevOffsets=offsets;
      try{
        int[] objToBin=null;
        parseBin(base);
        // Exportacao experimental somente para a topologia Base3d +4 (292).
        if(!hair && offsets.size()==288 && obj.vertices.size()==292){
          byte[] template;
          try(InputStream stream=getAssets().open("base3d_292_reference.bin");
              ByteArrayOutputStream buffer=new ByteArrayOutputStream()){
            byte[] chunk=new byte[8192];int length;
            while((length=stream.read(chunk))!=-1)buffer.write(chunk,0,length);
            template=buffer.toByteArray();
          }
          parseBin(template);
          if(mesh.vertices.size()!=292 || mesh.faces.size()!=obj.faces.size())
            throw new Exception("Malha 292 diferente do modelo experimental. Exportacao cancelada.");
          // Usa a permutacao OBJ -> BIN validada pela topologia (384 triangulos).
          // A ordem dos vertices na parte 4 NAO e a mesma nos dois arquivos.
          objToBin=new int[292];
          // Ordem exata comprovada comparando Base3d +4.obj ao OBJ do BIN funcional.
          // OBJ 0..135 -> BIN 0..135; OBJ 136..287 -> BIN 140..291;
          // OBJ 288..291 -> BIN 136..139.
          for(int k=0;k<292;k++)objToBin[k]=(k<136)?k:((k<288)?k+4:k-152);
          // A ordem das faces no OBJ pode diferir da ordem dos comandos GE.
          // Compara o multiconjunto de triangulos por seus indices de vertices.
          HashMap<String,Integer> expectedTriangles=new HashMap<>();
          for(int[] face:mesh.faces){
            int[] sorted=face.clone();Arrays.sort(sorted);
            String key=Arrays.toString(sorted);
            expectedTriangles.put(key,expectedTriangles.getOrDefault(key,0)+1);
          }
          int[] mismatchByPart=new int[5];
          int unmatched=0;
          for(int f=0;f<obj.faces.size();f++){
            int[] triangle=obj.faces.get(f);
            int[] sorted=triangle.clone();
            for(int k=0;k<sorted.length;k++){
              if(sorted[k]<0||sorted[k]>=objToBin.length)throw new Exception("Indice OBJ invalido");
              sorted[k]=objToBin[sorted[k]];
            }
            Arrays.sort(sorted);
            String key=Arrays.toString(sorted);
            int count=expectedTriangles.getOrDefault(key,0);
            if(count==0){
              unmatched++;
              int min=sorted[0],max=sorted[sorted.length-1];
              int region=(min<60&&max<60)?0:(min>=60&&max<76)?1:
                (min>=76&&max<140)?2:(min>=140&&max<292)?3:4;
              mismatchByPart[region]++;
            }else expectedTriangles.put(key,count-1);
          }
          if(unmatched>0)throw new Exception(
            "Diagnostico de topologia (292 vertices):\n"+
            "Triangulos OBJ: "+obj.faces.size()+" | BIN: "+mesh.faces.size()+"\n"+
            "Sem correspondencia: "+unmatched+"\n"+
            "Parte 1 (0-59): "+mismatchByPart[0]+"\n"+
            "Parte 2 (60-75): "+mismatchByPart[1]+"\n"+
            "Parte 3 (76-139): "+mismatchByPart[2]+"\n"+
            "Parte 4 (140-291): "+mismatchByPart[3]+"\n"+
            "Indices cruzados: "+mismatchByPart[4]+"\n"+
            "Exportacao cancelada para proteger o BIN.");
        }
        if(offsets.size()!=obj.vertices.size()){
          throw new Exception("OBJ: "+obj.vertices.size()+" vertices; BIN: "+offsets.size()+". Devem corresponder.");
        }
        for(int j=0;j<obj.vertices.size();j++){
          float[] v=obj.vertices.get(j);
          for(float coordinate:v)if(Float.isNaN(coordinate)||Float.isInfinite(coordinate))
            throw new Exception("Coordenada OBJ invalida");
          mesh.vertices.set(objToBin==null?j:objToBin[j],v.clone());
        }
        // OBJ pode ter indices vt independentes de v. Resolve UV por canto
        // de face, depois grava uma coordenada UV para cada vertice BIN.
        // O formato BIN PSP nao permite dois UVs distintos no mesmo registro.
        if(!obj.uvs.isEmpty()){
          float[][] mapped=new float[offsets.size()][];
          if(!obj.faceUvs.isEmpty()){
            if(obj.faceUvs.size()!=obj.faces.size())
              throw new Exception("Faces UV do OBJ incompletas");
            for(int f=0;f<obj.faces.size();f++){
              int[] verts=obj.faces.get(f),uvIds=obj.faceUvs.get(f);
              if(verts.length!=uvIds.length)
                throw new Exception("Indices UV incompatíveis na face "+(f+1));
              for(int k=0;k<verts.length;k++){
                int vi=verts[k],ui=uvIds[k];
                if(vi<0||vi>=mapped.length||ui<0||ui>=obj.uvs.size())
                  throw new Exception("UV ausente ou invalida na face "+(f+1));
                float[] xy=obj.uvs.get(ui);
                if(mapped[vi]!=null &&
                    (Math.abs(mapped[vi][0]-xy[0])>0.000001f||Math.abs(mapped[vi][1]-xy[1])>0.000001f))
                  throw new Exception("Vertice "+(vi+1)+" possui UVs diferentes. BIN PSP aceita apenas uma UV por vertice.");
                mapped[vi]=xy;
              }
            }
          }else if(obj.uvs.size()==mapped.length){
            for(int j=0;j<mapped.length;j++)mapped[j]=obj.uvs.get(j);
          }else throw new Exception("OBJ sem correspondencia entre vertices e UVs");
          // v299: OBJ e BIN podem ter o mesmo numero de vertices 3D,
          // mas nem todo vertice OBJ participa de uma face com indice vt.
          // Nesses casos preservar o UV ja lido do BIN de destino.
          // Nao inventar coordenadas nem substituir por UV de outro vertice.
          for(int j=0;j<mapped.length;j++){
            int binIndex=objToBin==null?j:objToBin[j];
            if(binIndex<0||binIndex>=mesh.uvs.size())
              throw new Exception("Indice BIN invalido para o vertice "+(j+1));
            if(mapped[j]==null){
              float[] originalUv=mesh.uvs.get(binIndex);
              if(originalUv==null||originalUv.length<2||
                  !Float.isFinite(originalUv[0])||!Float.isFinite(originalUv[1]))
                throw new Exception("UV ausente no OBJ e no BIN para o vertice "+(j+1));
              continue; // UV original permanece intacto
            }
            float u=mapped[j][0],v=mapped[j][1];
            if(!Float.isFinite(u)||!Float.isFinite(v))throw new Exception("Coordenada UV invalida");
            mesh.uvs.set(binIndex,new float[]{u,v});
          }
          uvDirty=true;
        }
        // A malha 292 usa o BIN GE ja reconstruido e validado no PPSSPP.
        // Nao reconstruir shape keys com offsets da malha antiga: isso
        // pode sobrescrever registros da geometria ampliada.
        byte[] modified=objToBin!=null?makeBin292WithoutShapeKeyRebuild():makeBin();
        // Confere a geometria do BIN REAL antes de sobrescrever o destino.
        // A rotina antiga pode concluir sem erro mesmo que a malha esteja corrompida.
        if(objToBin!=null){
          Mesh expectedMesh=mesh;
          byte[] expectedOriginal=originalBin,expectedDecoded=decoded;
          ArrayList<Integer> expectedOffsets=offsets;
          try{
            parseBin(modified);
            if(mesh.vertices.size()!=obj.vertices.size())
              throw new Exception("BIN gerado possui quantidade incorreta de vertices");
            float maxError=0f;
            for(int j=0;j<obj.vertices.size();j++){
              float[] actual=mesh.vertices.get(objToBin[j]);
              float[] expected=obj.vertices.get(j);
              for(int axis=0;axis<3;axis++){
                float error=Math.abs(actual[axis]-expected[axis]);
                if(error>maxError)maxError=error;
              }
            }
            if(maxError>0.004f)
              throw new Exception("BIN gerado falhou na validacao 3D: desvio maximo "+maxError+". Nada foi gravado.");
          }finally{
            mesh=expectedMesh;originalBin=expectedOriginal;
            decoded=expectedDecoded;offsets=expectedOffsets;
          }
        }
        try(OutputStream out=getContentResolver().openOutputStream(target,"rwt")){
          if(out==null)throw new Exception("Nao foi possivel gravar o BIN");
          out.write(modified);out.flush();
        }
        mesh=obj;originalBin=modified;decoded=null;offsets=new ArrayList<>();uvDirty=false;syncActive();
        status.setText((hair?"Hair":"Face")+" BIN: "+mesh.vertices.size()+" vertices");
        view.invalidate();toast("BIN atualizado.");
      }catch(Exception e){
        mesh=obj;originalBin=prevOriginal;decoded=prevDecoded;offsets=prevOffsets;
        syncActive();throw e;
      }
    }catch(Exception e){
      new AlertDialog.Builder(this).setTitle("Erro ao exportar BIN")
        .setMessage(e.getMessage()).setPositiveButton("OK",null).show();
    }
  }
  void save(int code,String name){boolean targetHair=code==SAVE_HAIR_BIN||code==SAVE_HAIR_OBJ;if(activeHair!=targetHair)switchObject(targetHair);if(mesh.vertices.isEmpty()){toast("Abra um modelo primeiro");return;}if((code==SAVE_BIN||code==SAVE_HAIR_BIN)&&(originalBin==null||offsets.size()!=mesh.vertices.size())){toast("Para salvar BIN, abra primeiro o BIN original");return;}Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_TITLE,name);startActivityForResult(i,code);}
  byte[] read(Uri uri)throws Exception{try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);return out.toByteArray();}}
  void write(Uri uri,byte[] bytes)throws Exception{try(OutputStream out=getContentResolver().openOutputStream(uri,"w")){out.write(bytes);}}
  @Override protected void onActivityResult(int req,int result,Intent data){
    super.onActivityResult(req,result,data);if(req==GRANT_ALL_FILES){if(hasAllFiles()){if(pendingFaceBin!=null)autoLoadTexture(pendingFaceBin,false);if(pendingHairBin!=null)autoLoadTexture(pendingHairBin,true);view.invalidate();}return;}if(result!=RESULT_OK||data==null)return;
    if(req==IMPORT_CFG){
      final Uri cfgUri=data.getData();
      new AlertDialog.Builder(this).setTitle("Importar CFG")
        .setMessage("Substituir as configurações atuais pelas do arquivo selecionado?")
        .setNegativeButton("Cancelar",null)
        .setPositiveButton("Importar",(d,w)->{try{importCfg(cfgUri);}catch(Exception e){new AlertDialog.Builder(this).setTitle("Erro ao importar CFG").setMessage(e.getMessage()).setPositiveButton("OK",null).show();}}).show();
      return;
    }
    if(req==EXPORT_CFG){try{write(data.getData(),buildCfg());toast("Configurações exportadas");}catch(Exception e){toast("Erro ao exportar CFG: "+e.getMessage());}return;}
    boolean hairReq=req==OPEN_HAIR_BIN||req==OPEN_HAIR_OBJ||req==SAVE_HAIR_BIN||req==SAVE_HAIR_OBJ||req==HAIR_TEXTURE;
    boolean load=req==OPEN_BIN||req==OPEN_OBJ||req==OPEN_HAIR_BIN||req==OPEN_HAIR_OBJ;
    try{
      if((req==OPEN_BIN||req==OPEN_OBJ||req==OPEN_HAIR_BIN||req==OPEN_HAIR_OBJ||req==SAVE_BIN||req==SAVE_OBJ||req==SAVE_HAIR_BIN||req==SAVE_HAIR_OBJ)&&activeHair!=hairReq)switchObject(hairReq);
      Uri uri=data.getData();
      if(req==UV_SAVE_COMPOSITE){
        Bitmap uvComposite=currentTexture();if(uvComposite==null)throw new Exception("Nenhuma textura UV");
        try(OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null||!uvComposite.compress(Bitmap.CompressFormat.PNG,100,out))throw new IOException("Falha ao salvar PNG");}
        toast("Textura UV salva em PNG");return;
      }
      if(req==EXPORT_PHOTO_UV){
        if(generatedPhotoUv==null)throw new Exception("Gere a textura novamente");
        try(OutputStream out=getContentResolver().openOutputStream(uri)){
          if(out==null||!generatedPhotoUv.compress(Bitmap.CompressFormat.PNG,100,out))throw new IOException("Falha ao salvar PNG");
        }
        toast("Textura UV PNG salva");return;
      }
      if(req==COLOR_BASE_IMAGE){
        BitmapFactory.Options opt=new BitmapFactory.Options();opt.inSampleSize=1;
        try(InputStream stream=getContentResolver().openInputStream(uri)){colorBaseImage=BitmapFactory.decodeStream(stream,null,opt);}
        if(colorBaseImage==null)throw new Exception("Base PNG inválida");
        useColorBase=true;toast("Base carregada: correção de pele ativada");return;
      }
      if(req==REFERENCE_IMAGE){
        try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
        loadReferenceBitmap(uri);referenceUri=uri;referenceVisible=true;
        referenceHeight=referenceWidth*referenceImage.getHeight()/Math.max(1f,referenceImage.getWidth());
        saveReferencePrefs();toast("Imagem de referência importada");return;
      }
      if(req==UV_OPEN_IMAGE||req==UV_REPLACE_IMAGE||req==UV_SWAP_SKIN){
        Bitmap bmp;try(InputStream stream=getContentResolver().openInputStream(uri)){bmp=BitmapFactory.decodeStream(stream);}
        if(bmp==null)throw new Exception("Imagem PNG inválida");
        uvImageCleared=false;
        if(req==UV_SWAP_SKIN){setUvSkin(bmp);toast("Skin de base alterada");}
        else {setUvSkin(bmp);toast("Skin UV carregada");}
        return;
      }
      if(req==FACE_TEXTURE||req==HAIR_TEXTURE){
        Bitmap bmp=BitmapFactory.decodeStream(getContentResolver().openInputStream(uri));
        if(bmp==null)throw new Exception("Imagem PNG inválida");
        if(req==HAIR_TEXTURE)hairTexture=bmp;else faceTexture=bmp;
        view.textured=true;view.solid=true;view.invalidate();toast("Textura carregada: "+(req==HAIR_TEXTURE?"Hair":"Face"));return;
      }
      if(req==CHOOSE_FACE_BIN||req==CHOOSE_HAIR_BIN){
        if(req==CHOOSE_HAIR_BIN){pendingHairBin=uri;if(hairFileLabel!=null)hairFileLabel.setText(selectedBinName(uri));}
        else{pendingFaceBin=uri;if(faceFileLabel!=null)faceFileLabel.setText(selectedBinName(uri));}
        return;
      }
      if(req==OPEN_BIN||req==OPEN_HAIR_BIN){byte[] incoming=read(uri);beginNewObject(hairReq);if(hairReq)pendingHairBin=uri;else pendingFaceBin=uri;parseBin(incoming);autoLoadTexture(uri,hairReq);status.setText((hairReq?"Hair":"Face")+" BIN: "+mesh.vertices.size()+" vértices");}
      else if(req==OPEN_OBJ||req==OPEN_HAIR_OBJ){
        Mesh incoming=parseObj(new String(read(uri),StandardCharsets.UTF_8));
        Uri target=hairReq?pendingHairBin:pendingFaceBin;
        // Importacao independente: BIN so e necessario para exportar BIN.
        // Evita substituir os dados do OBJ pela geometria do BIN.
        mesh=incoming;
        originalBin=null;decoded=null;offsets=new ArrayList<>();uvDirty=false;
        status.setText((hairReq?"Hair":"Face")+" OBJ: "+mesh.vertices.size()+" vertices");
      }
      else if(req==SAVE_OBJ||req==SAVE_HAIR_OBJ){write(uri,makeObj().getBytes(StandardCharsets.UTF_8));toast("OBJ exportado");}
      else if(req==SAVE_BIN||req==SAVE_HAIR_BIN){write(uri,makeBin());toast("BIN exportado (teste no jogo)");}
      syncActive();
      if(load){undo.clear();redo.clear();undoBinSplits.clear();redoBinSplits.clear();undoSelection.clear();redoSelection.clear();view.selected.clear();setCameraView(3);}
      refreshObjects();view.invalidate();
    }catch(Exception e){new AlertDialog.Builder(this).setTitle("Erro no arquivo").setMessage(e.getMessage()).setPositiveButton("OK",null).show();}
  }
  private Toast activeToast;
  private final Handler toastHandler = new Handler(Looper.getMainLooper());
  private final Runnable dismissToast = () -> { if(activeToast!=null){activeToast.cancel();activeToast=null;} };
  void toast(String s){
    toastHandler.removeCallbacks(dismissToast);
    if(activeToast!=null) activeToast.cancel();
    activeToast=Toast.makeText(this,s,Toast.LENGTH_SHORT);
    activeToast.show();
    toastHandler.postDelayed(dismissToast,1000);
  }
  static int u16(byte[] a,int p){return (a[p]&255)|((a[p+1]&255)<<8);}static int s16(byte[] a,int p){return (short)u16(a,p);}static int u32(byte[] a,int p){return u16(a,p)|(u16(a,p+2)<<16);}static void put16(byte[] a,int p,int v){a[p]=(byte)v;a[p+1]=(byte)(v>>8);}static void put32(byte[] a,int p,int v){put16(a,p,v);put16(a,p+2,v>>16);}static void valid(byte[] a,int p,int n)throws Exception{if(p<0||n<0||p>a.length-n)throw new Exception("Estrutura BIN fora dos limites");}
  void parseBin(byte[] bin)throws Exception{if(bin.length<40)throw new Exception("BIN muito pequeno");InflaterInputStream zip=new InflaterInputStream(new ByteArrayInputStream(bin,32,bin.length-32));ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] temp=new byte[8192];int n;while((n=zip.read(temp))!=-1){out.write(temp,0,n);if(out.size()>30000000)throw new Exception("BIN descomprimido muito grande");}byte[] d=out.toByteArray();valid(d,8,4);int off=u32(d,8);valid(d,off,40);if(d[off]!=3||d[off+1]!=0||(d[off+2]&255)!=255||(d[off+3]&255)!=255)throw new Exception("Formato de Face PSP não reconhecido");int count=u32(d,off+32),start=off+u32(d,off+36);if(count<1||count>1000)throw new Exception("Quantidade de partes inválida");Mesh result=new Mesh();ArrayList<Integer> pos=new ArrayList<>();for(int part=0;part<count;part++){valid(d,start,96);int size=u32(d,start),vo=u32(d,start+8)+start,to=u32(d,start+12),tn=u32(d,start+16);int vertices=u16(d,start+92),stride=u16(d,start+94);if(size<96||stride<14||stride>256||vertices>50000)throw new Exception("Parte inválida");int base=result.vertices.size();for(int j=0;j<vertices;j++){int at=vo+j*stride;valid(d,at,14);float x=s16(d,at+12)*.001553f,y=s16(d,at+8)*-.001553f,z=s16(d,at+10)*-.001553f;result.vertices.add(new float[]{x,y,z});int u=s16(d,at),v=s16(d,at+2);result.uvs.add(new float[]{(u<0?u+32768:u)*.000244f,1-(v<0?v+32768:v)*.000244f});pos.add(at);}
    if(to!=0&&tn>2&&tn<100000){valid(d,start+to,tn*2);int info=start+u32(d,start+48);valid(d,info,0);ArrayList<Integer> lengths=new ArrayList<>();int search=info;while(search+3<vo){if((d[search+2]&255)==4&&(d[search+3]&255)==4){lengths.add(u16(d,search));search+=4;}else search++;}if(lengths.isEmpty())lengths.add(tn);int idx=0;for(int len:lengths){len=Math.min(len,tn-idx);for(int k=0;k<len-2;k++){int a=u16(d,start+to+(idx+k)*2),b=u16(d,start+to+(idx+k+1)*2),c=u16(d,start+to+(idx+k+2)*2);if(a!=b&&b!=c&&a!=c&&a<vertices&&b<vertices&&c<vertices)result.faces.add(new int[]{base+c,base+b,base+a});}idx+=len;if(idx>=tn)break;}}
    start+=size;}
    originalBin=bin;decoded=d;offsets=pos;mesh=result;uvDirty=false;uvUndo.clear();uvRedo.clear();uvColorUndo.clear();uvColorRedo.clear();uvActionUndo.clear();uvActionRedo.clear();if(uvView!=null)uvView.selected.clear();
  }
  Mesh parseObj(String content)throws Exception{
    Mesh m=new Mesh();
    for(String raw:content.split("\\R")){
      String line=raw.trim();
      if(line.startsWith("mtllib ")){m.materialLibrary=line.substring(7).trim();}
      else if(line.startsWith("usemtl ")){m.materialName=line.substring(7).trim();}
      else if(line.startsWith("o ")){m.objectName=line.substring(2).trim();}
      else if(line.startsWith("v ")){
        String[] p=line.split("\\s+");
        if(p.length>=4)m.vertices.add(new float[]{Float.parseFloat(p[1]),Float.parseFloat(p[2]),Float.parseFloat(p[3])});
      }else if(line.startsWith("vt ")){
        String[] p=line.split("\\s+");
        if(p.length>=3)m.uvs.add(new float[]{Float.parseFloat(p[1]),Float.parseFloat(p[2])});
      }else if(line.startsWith("f ")){
        String[] p=line.split("\\s+");
        int[] vi=new int[p.length-1],ui=new int[p.length-1];
        for(int j=1;j<p.length;j++){
          String[] t=p[j].split("/",-1);
          int v=Integer.parseInt(t[0]);
          vi[j-1]=v>0?v-1:m.vertices.size()+v;
          if(vi[j-1]<0||vi[j-1]>=m.vertices.size())throw new Exception("Índice de vértice inválido");
          ui[j-1]=-1;
          if(t.length>1&&!t[1].isEmpty()){
            int u=Integer.parseInt(t[1]);
            ui[j-1]=u>0?u-1:m.uvs.size()+u;
            if(ui[j-1]<0||ui[j-1]>=m.uvs.size())ui[j-1]=-1;
          }
        }
        for(int j=1;j+1<vi.length;j++){
          m.faces.add(new int[]{vi[0],vi[j],vi[j+1]});
          m.faceUvs.add(new int[]{ui[0],ui[j],ui[j+1]});
        }
      }
    }
    if(m.vertices.isEmpty())throw new Exception("OBJ sem vértices");
    return m;
  }
  // Exportação fiel à topologia de referência apenas quando a malha corresponde.
  String referenceObj() {
    try {
      String file=objExportMode==0?"reference_blender.obj":"reference_script.obj";
      ByteArrayOutputStream bytes=new ByteArrayOutputStream();
      try(InputStream in=getAssets().open(file)) {byte[] buffer=new byte[4096];int n;while((n=in.read(buffer))!=-1)bytes.write(buffer,0,n);}
      String original=new String(bytes.toByteArray(),StandardCharsets.UTF_8);
      Mesh ref=parseObj(original);
      if(ref.vertices.size()!=mesh.vertices.size()||ref.faces.size()!=mesh.faces.size())return null;
      java.util.HashMap<String,Integer> counts=new java.util.HashMap<>();
      for(int[] f:mesh.faces){String key=faceKey(f);Integer old=counts.get(key);counts.put(key,old==null?1:old+1);}
      for(int[] f:ref.faces){String key=faceKey(f);Integer old=counts.get(key);if(old==null||old==0)return null;counts.put(key,old-1);}
      StringBuilder result=new StringBuilder();int vertex=0;
      for(String line:original.split("\\R",-1)){
        if(line.startsWith("v ")||line.startsWith("v  ")){
          float[] v=mesh.vertices.get(vertex++);
          result.append(String.format(java.util.Locale.US,"v %.6f %.6f %.6f",v[0],v[1],v[2]));
        }else result.append(line);
        result.append('\n');
      }
      return result.toString();
    }catch(Exception ignored){return null;}
  }
  String faceKey(int[] f){int[] a=f.clone();java.util.Arrays.sort(a);return a[0]+":"+a[1]+":"+a[2];}
  String makeObj(){
    String template=referenceObj();
    if(template!=null)return template;
    boolean blender=objExportMode==0;
    StringBuilder s=new StringBuilder(blender?"# Wavefront OBJ - Face Hair Editor PSP\n":"# PES PSP OBJ - Face Hair Editor PSP\n");
    if(!mesh.materialLibrary.isEmpty())s.append("mtllib ").append(mesh.materialLibrary).append('\n');
    s.append("o ").append(mesh.objectName.isEmpty()?"PES_PSP_Face":mesh.objectName).append('\n');
    for(float[] v:mesh.vertices)s.append(String.format(java.util.Locale.US,"v %.6f %.6f %.6f\n",v[0],v[1],v[2]));
    java.util.ArrayList<float[]> uvOut=new java.util.ArrayList<>();
    java.util.ArrayList<int[]> uvFaces=new java.util.ArrayList<>();
    java.util.HashMap<String,Integer> dedup=new java.util.HashMap<>();
    for(int fi=0;fi<mesh.faces.size();fi++){
      int[] f=mesh.faces.get(fi),src=fi<mesh.faceUvs.size()?mesh.faceUvs.get(fi):null;
      int[] dst=new int[3];
      for(int k=0;k<3;k++){
        int u=src!=null?src[k]:(mesh.uvs.size()==mesh.vertices.size()?f[k]:-1);
        dst[k]=-1;
        if(u>=0&&u<mesh.uvs.size()){
          float[] v=mesh.uvs.get(u);
          String key=blender?(Float.floatToIntBits(v[0])+":"+Float.floatToIntBits(v[1])):("v"+f[k]+":"+u);
          Integer id=dedup.get(key);
          if(id==null){id=uvOut.size();uvOut.add(v);dedup.put(key,id);}
          dst[k]=id;
        }
      }
      uvFaces.add(dst);
    }
    for(float[] uv:uvOut)s.append(String.format(java.util.Locale.US,"vt %.6f %.6f\n",uv[0],uv[1]));
    if(!mesh.materialName.isEmpty())s.append("usemtl ").append(mesh.materialName).append('\n');
    if(blender)s.append("s off\n");
    for(int fi=0;fi<mesh.faces.size();fi++){
      int[] f=mesh.faces.get(fi),uv=uvFaces.get(fi);s.append("f");
      for(int k=0;k<3;k++){s.append(' ').append(f[k]+1);if(uv[k]>=0)s.append('/').append(uv[k]+1);}
      s.append('\n');
    }
    return s.toString();
  }
  // Fallback para BINs cujo bloco de shapekeys nao segue o descritor padrao.
  // Sincroniza somente registros de 6 bytes que correspondem exatamente
  // a coordenadas XYZ anteriores de vertices modificados.
  void syncAlternateShapeKeys(byte[] d,int shapeStart,int shapeEnd)throws Exception{
    java.util.HashMap<String,byte[]> changes=new java.util.HashMap<>();
    for(int i=0;i<offsets.size();i++){
      int at=offsets.get(i)+8;
      valid(decoded,at,6);valid(d,at,6);
      byte[] old=Arrays.copyOfRange(decoded,at,at+6);
      byte[] now=Arrays.copyOfRange(d,at,at+6);
      if(Arrays.equals(old,now))continue;
      String key=java.util.Arrays.toString(old);
      byte[] prev=changes.put(key,now);
      if(prev!=null&&!Arrays.equals(prev,now))
        throw new Exception("Vertices repetidos com destinos diferentes: shapekeys ambiguas");
    }
    if(changes.isEmpty())return;
    // Registros da regiao sao alinhados em grupos de 6 bytes.
    // Nao altera bytes de cabecalho nem registros sem correspondencia.
    for(int at=shapeStart;at+6<=shapeEnd;at+=6){
      String key=java.util.Arrays.toString(Arrays.copyOfRange(decoded,at,at+6));
      byte[] replacement=changes.get(key);
      if(replacement!=null)System.arraycopy(replacement,0,d,at,6);
    }
  }
  // Reconstrói os shapekeys do PES PSP a partir dos vértices gravados.
  // O jogo utiliza este bloco para aplicar corretamente as mudanças faciais.
  void rebuildPspShapeKeys(byte[] d)throws Exception{
    valid(d,8,4);
    int root=u32(d,8);
    valid(d,root+80,4);
    int shapeStart=root+u32(d,root+72);
    int shapeEnd=root+u32(d,root+80);
    if(shapeStart<0||shapeEnd<shapeStart||shapeEnd>d.length)throw new Exception("Bloco shapekey inválido");
    int count=u32(d,root+32),part=root+u32(d,root+36);
    if(count<1||count>1000)throw new Exception("Quantidade de partes inválida");
    int target=shapeStart;
    byte[] rebuilt=d.clone(); // preservar bloco original se a estrutura nao corresponder
    for(int i=0;i<count;i++){
      valid(d,part,96);
      int partSize=u32(d,part),vertexBase=part+u32(d,part+8);
      int vertices=u16(d,part+92),stride=u16(d,part+94);
      if(partSize<96||stride<14||vertices>50000)throw new Exception("Parte BIN inválida");
      if(u32(d,part+20)!=0){
        int shapeDesc=part+u32(d,part+24);
        valid(d,shapeDesc,6);
        int first=u16(d,shapeDesc+2),total=u16(d,shapeDesc+4);
        if(first>vertices||total>vertices-first)throw new Exception("Índices shapekey inválidos");
        for(int j=first;j<first+total;j++){
          int source=vertexBase+j*stride+8;
          valid(d,source,6);
          if(target>shapeEnd-6){syncAlternateShapeKeys(d,shapeStart,shapeEnd);return;}
          System.arraycopy(d,source,rebuilt,target,6);
          target+=6;
        }
      }
      if(partSize>d.length-part)throw new Exception("Parte BIN excede arquivo");
      part+=partSize;
    }
    // Alguns BINs possuem ate 3 bytes de alinhamento apos os registros XYZ
    // de 6 bytes. O ID02132.bin, por exemplo, possui 810 bytes de
    // coordenadas e 2 bytes finais de preenchimento. Preservar esses bytes
    // evita o fallback ambiguo por coordenadas repetidas.
    int remaining=shapeEnd-target;
    if(remaining<0||remaining>3){syncAlternateShapeKeys(d,shapeStart,shapeEnd);return;}
    System.arraycopy(rebuilt,shapeStart,d,shapeStart,target-shapeStart);
  }
  // Exportacao experimental 292: escreve SOMENTE os registros de vertices/UV
  // na estrutura GE ja validada. Nao executa rebuildPspShapeKeys().
  byte[] makeBin292WithoutShapeKeyRebuild()throws Exception{
    if(offsets.size()!=292||mesh.vertices.size()!=292)
      throw new Exception("Exportacao 292 exige exatamente 292 vertices");
    byte[] d=decoded.clone();
    for(int i=0;i<292;i++){
      float[] v=mesh.vertices.get(i);
      int[] a={Math.round(v[1]/-.001553f),Math.round(v[2]/-.001553f),Math.round(v[0]/.001553f)};
      for(int x:a)if(x<Short.MIN_VALUE||x>Short.MAX_VALUE)
        throw new Exception("Coordenada fora dos limites BIN");
      int p=offsets.get(i)+8;
      for(int j=0;j<3;j++)put16(d,p+2*j,a[j]);
      if(uvDirty&&mesh.uvs.size()==292){
        float[] uv=mesh.uvs.get(i);
        int u=Math.round(uv[0]/.000244f),vraw=Math.round((1f-uv[1])/.000244f);
        if(u<0||u>4098||vraw<0||vraw>4098)
          throw new Exception("UV fora dos limites BIN");
        put16(d,offsets.get(i),u);put16(d,offsets.get(i)+2,vraw);
      }
    }
    ByteArrayOutputStream bytes=new ByteArrayOutputStream();
    DeflaterOutputStream zip=new DeflaterOutputStream(bytes,new Deflater(9));
    zip.write(d);zip.close();
    byte[] packed=bytes.toByteArray(),header=Arrays.copyOf(originalBin,32);
    put32(header,4,packed.length);put32(header,8,d.length);
    ByteArrayOutputStream out=new ByteArrayOutputStream();
    out.write(header);out.write(packed);return out.toByteArray();
  }
  byte[] makeBin()throws Exception{byte[] d=decoded.clone();for(int i=0;i<offsets.size();i++){float[] v=mesh.vertices.get(i);int[] a={Math.round(v[1]/-.001553f),Math.round(v[2]/-.001553f),Math.round(v[0]/.001553f)};for(int x:a)if(x<Short.MIN_VALUE||x>Short.MAX_VALUE)throw new Exception("Coordenada fora dos limites BIN");int p=offsets.get(i)+8;for(int j=0;j<3;j++)put16(d,p+2*j,a[j]);
    if(uvDirty&&mesh.uvs.size()==offsets.size()){
      float[] uv=mesh.uvs.get(i);
      int u=Math.round(uv[0]/.000244f),vraw=Math.round((1f-uv[1])/.000244f);
      if(u<0||u>4098||vraw<0||vraw>4098)throw new Exception("UV fora dos limites BIN");
      put16(d,offsets.get(i),u);put16(d,offsets.get(i)+2,vraw);
    }
  }rebuildPspShapeKeys(d);ByteArrayOutputStream bytes=new ByteArrayOutputStream();DeflaterOutputStream zip=new DeflaterOutputStream(bytes,new Deflater(9));zip.write(d);zip.close();byte[] packed=bytes.toByteArray(),header=Arrays.copyOf(originalBin,32);put32(header,4,packed.length);put32(header,8,d.length);ByteArrayOutputStream out=new ByteArrayOutputStream();out.write(header);out.write(packed);return out.toByteArray();}
  Mesh snapshotMesh(){
    Mesh copy=new Mesh();copy.objectName=mesh.objectName;copy.materialName=mesh.materialName;copy.materialLibrary=mesh.materialLibrary;
    for(float[] v:mesh.vertices)copy.vertices.add(v.clone());
    for(float[] uv:mesh.uvs)copy.uvs.add(uv.clone());
    for(int[] f:mesh.faces)copy.faces.add(f.clone());
    for(int[] f:mesh.faceUvs)copy.faceUvs.add(f.clone());
    return copy;
  }
  void restoreMesh(Mesh state){
    // Preserve the current Mesh object: renderers and object slots may hold references to it.
    mesh.vertices.clear();for(float[] v:state.vertices)mesh.vertices.add(v.clone());
    mesh.uvs.clear();for(float[] uv:state.uvs)mesh.uvs.add(uv.clone());
    mesh.faces.clear();for(int[] f:state.faces)mesh.faces.add(f.clone());
    mesh.faceUvs.clear();for(int[] f:state.faceUvs)mesh.faceUvs.add(f.clone());
    mesh.objectName=state.objectName;mesh.materialName=state.materialName;mesh.materialLibrary=state.materialLibrary;
    view.selected.clear();view.invalidate();if(uvView!=null){uvView.selected.clear();uvView.invalidate();}
    status.setText((activeHair?"Hair: ":"Face: ")+mesh.vertices.size()+" vértices");
  }
  // Keep BIN edge-split operations in lockstep with 3D Undo/Redo snapshots.
  // A vertex movement must not invalidate earlier splits. Undoing a split,
  // however, must restore the previous split history as well as the mesh.
  final ArrayList<ArrayList<int[]>> undoBinSplits=new ArrayList<>(),redoBinSplits=new ArrayList<>();
  ArrayList<int[]> snapshotBinSplits(){
    ArrayList<int[]> copy=new ArrayList<>();
    for(int[] edge:pendingBinSplits)copy.add(edge.clone());
    return copy;
  }
  void restoreBinSplits(ArrayList<int[]> saved){
    pendingBinSplits.clear();
    for(int[] edge:saved)pendingBinSplits.add(edge.clone());
    // Keep the original BIN source, including when undoing the first split;
    // splitSelectedEdge() can reinitialize it when the list is empty.
  }
  // Restore vertex selection along with mesh state, so Undo of a drag does not
  // force the user to select the same vertices again.
  final ArrayList<java.util.HashSet<Integer>> undoSelection=new ArrayList<>(),redoSelection=new ArrayList<>();
  java.util.HashSet<Integer> snapshotSelection(){return new java.util.HashSet<>(view.selected);}
  void restoreSelection(java.util.HashSet<Integer> saved){
    view.selected.clear();
    for(Integer i:saved)if(i!=null&&i>=0&&i<mesh.vertices.size())view.selected.add(i);
    sync3dToUv();
    view.invalidate();if(uvView!=null)uvView.invalidate();
    status.setText("Selecionados: "+view.selected.size()+" / "+mesh.vertices.size()+" vértices");
  }
  void pushUndo(){
    undo.add(snapshotMesh());undoBinSplits.add(snapshotBinSplits());undoSelection.add(snapshotSelection());
    if(undo.size()>30){undo.remove(0);undoBinSplits.remove(0);undoSelection.remove(0);}
    redo.clear();redoBinSplits.clear();redoSelection.clear();
  }
  void historyUndo(){
    if(referenceAdjustMode&&referenceImage!=null){referenceHistoryUndo();return;}
    if(undo.isEmpty()){toast("Nada para desfazer");return;}
    redo.add(snapshotMesh());redoBinSplits.add(snapshotBinSplits());redoSelection.add(snapshotSelection());
    Mesh previous=undo.remove(undo.size()-1);
    ArrayList<int[]> previousSplits=undoBinSplits.remove(undoBinSplits.size()-1);
    java.util.HashSet<Integer> previousSelection=undoSelection.remove(undoSelection.size()-1);
    restoreMesh(previous);restoreBinSplits(previousSplits);restoreSelection(previousSelection);
  }
  void historyRedo(){
    if(referenceAdjustMode&&referenceImage!=null){referenceHistoryRedo();return;}
    if(redo.isEmpty()){toast("Nada para refazer");return;}
    undo.add(snapshotMesh());undoBinSplits.add(snapshotBinSplits());undoSelection.add(snapshotSelection());
    Mesh next=redo.remove(redo.size()-1);
    ArrayList<int[]> nextSplits=redoBinSplits.remove(redoBinSplits.size()-1);
    java.util.HashSet<Integer> nextSelection=redoSelection.remove(redoSelection.size()-1);
    restoreMesh(next);restoreBinSplits(nextSplits);restoreSelection(nextSelection);
  }
  // Edges are recorded in editor-global vertex numbering at the time of each split.
  final ArrayList<int[]> pendingBinSplits=new ArrayList<>();
  byte[] pendingBinSplitSource=null;
  int pendingBinSplitBaseCount=-1;
  void exportMultipleSplitsBin(Uri target,byte[] base)throws Exception{
    if(pendingBinSplits.isEmpty()||pendingBinSplitSource==null||!java.util.Arrays.equals(base,pendingBinSplitSource))
      throw new Exception("O BIN selecionado nao corresponde ao original das divisoes.");
    Mesh edited=mesh;
    if(edited.vertices.size()!=pendingBinSplitBaseCount+pendingBinSplits.size())
      throw new Exception("O historico de divisoes nao corresponde a malha. Reimporte o BIN e tente novamente.");
    byte[] rebuilt=base;
    ArrayList<Integer> mapping=new ArrayList<>();
    for(int i=0;i<pendingBinSplitBaseCount;i++)mapping.add(i);
    for(int step=0;step<pendingBinSplits.size();step++){
      int[] edge=pendingBinSplits.get(step);
      if(edge[0]<0||edge[1]<0||edge[0]>=mapping.size()||edge[1]>=mapping.size())
        throw new Exception("Indice de aresta invalido na divisao "+(step+1));
      int a=mapping.get(edge[0]),b=mapping.get(edge[1]);
      byte[] unz=PspBinEdgeSplitter.unzip(PspBinEdgeSplitter.slice(rebuilt,32,rebuilt.length));
      int root=PspBinEdgeSplitter.u32(unz,8),at=root+PspBinEdgeSplitter.u32(unz,root+36);
      int start=0,part=0,localA=-1,localB=-1,insert=-1;
      int partCount=PspBinEdgeSplitter.u32(unz,root+32);
      if(partCount<1||partCount>64)throw new Exception("Quantidade de partes invalida");
      for(int k=1;k<=partCount;k++){
        if(at<0||at+96>unz.length)throw new Exception("Parte BIN fora do arquivo");
        int partSize=PspBinEdgeSplitter.u32(unz,at);
        if(partSize<96||partSize>unz.length-at)throw new Exception("Tamanho de parte BIN invalido");
        int n=PspBinEdgeSplitter.u16(unz,at+92);
        if(a>=start&&a<start+n&&b>=start&&b<start+n){
          part=k;localA=a-start;localB=b-start;insert=start+n;break;
        }
        start+=n;at+=partSize;
      }
      if(part==0)throw new Exception("Divisao "+(step+1)+": selecione uma aresta dentro da mesma parte BIN.");
      rebuilt=PspBinEdgeSplitter.split(rebuilt,part,localA,localB);
      for(int i=0;i<mapping.size();i++)if(mapping.get(i)>=insert)mapping.set(i,mapping.get(i)+1);
      mapping.add(insert);
    }
    Mesh previousMesh=mesh;byte[] prevOriginal=originalBin,prevDecoded=decoded;
    ArrayList<Integer> prevOffsets=offsets;boolean prevUvDirty=uvDirty;
    Mesh committedMesh=null;byte[] committedBin=null,committedDecoded=null;ArrayList<Integer> committedOffsets=null;
    try{
      parseBin(rebuilt);
      if(offsets.size()!=edited.vertices.size())throw new Exception("Quantidade de vertices reconstruidos incorreta");
      // PSP stores one UV pair per BIN vertex. The editor, however, stores UV
      // indices per face corner. Each split can append TWO midpoint UVs for ONE
      // 3D vertex, so edited.uvs.get(vertexIndex) is not the correct source.
      // Resolve UV by faceUvs for the actual vertex, then map editor->BIN.
      float[][] vertexUv=new float[edited.vertices.size()][];
      for(int fi=0;fi<edited.faces.size();fi++){
        int[] f=edited.faces.get(fi);
        int[] uvIds=fi<edited.faceUvs.size()?edited.faceUvs.get(fi):f;
        if(f.length!=3||uvIds.length!=3)throw new Exception("Face ou UV invalido na exportacao");
        for(int corner=0;corner<3;corner++){
          int vi=f[corner],ui=uvIds[corner];
          if(vi<0||vi>=vertexUv.length||ui<0||ui>=edited.uvs.size())
            throw new Exception("Indice UV invalido na face "+fi);
          float[] uv=edited.uvs.get(ui);
          if(vertexUv[vi]==null)vertexUv[vi]=uv.clone();
          else if(Math.abs(vertexUv[vi][0]-uv[0])>0.0003f||Math.abs(vertexUv[vi][1]-uv[1])>0.0003f)
            throw new Exception("Vertice "+vi+" possui UVs diferentes nas faces. O BIN PSP exige um UV por vertice.");
        }
      }
      for(int i=0;i<edited.vertices.size();i++){
        int mapped=mapping.get(i);
        mesh.vertices.set(mapped,edited.vertices.get(i).clone());
        // Vertices without faces keep their original per-vertex UV, if present.
        float[] uv=vertexUv[i]!=null?vertexUv[i]:(i<edited.uvs.size()?edited.uvs.get(i):null);
        if(uv!=null&&mapped<mesh.uvs.size())mesh.uvs.set(mapped,uv.clone());
      }
      byte[] d=decoded.clone();
      for(int i=0;i<offsets.size();i++){
        float[] v=mesh.vertices.get(i);
        int[] xyz={Math.round(v[1]/-.001553f),Math.round(v[2]/-.001553f),Math.round(v[0]/.001553f)};
        for(int x:xyz)if(x<Short.MIN_VALUE||x>Short.MAX_VALUE)throw new Exception("Coordenada 3D fora dos limites");
        for(int j=0;j<3;j++)put16(d,offsets.get(i)+8+j*2,xyz[j]);
        float[] uv=mesh.uvs.get(i);int u=Math.round(uv[0]/.000244f),vv=Math.round((1-uv[1])/.000244f);
        if(u<0||u>4098||vv<0||vv>4098)throw new Exception("UV fora dos limites");
        put16(d,offsets.get(i),u);put16(d,offsets.get(i)+2,vv);
      }
      java.io.ByteArrayOutputStream zipped=new java.io.ByteArrayOutputStream();
      java.util.zip.DeflaterOutputStream zip=new java.util.zip.DeflaterOutputStream(zipped,new java.util.zip.Deflater(9));zip.write(d);zip.close();
      byte[] header=java.util.Arrays.copyOf(rebuilt,32);put32(header,4,zipped.size());put32(header,8,d.length);
      java.io.ByteArrayOutputStream output=new java.io.ByteArrayOutputStream();output.write(header);output.write(zipped.toByteArray());
      byte[] result=output.toByteArray();parseBin(result);
      if(mesh.vertices.size()!=edited.vertices.size())throw new Exception("Falha na verificacao do BIN");
      try(java.io.OutputStream stream=getContentResolver().openOutputStream(target,"rwt")){
        if(stream==null)throw new Exception("Nao foi possivel abrir o destino");stream.write(result);stream.flush();
      }
      // v297: The saved BIN can reorder vertices across parts. Keep the
      // decoded BIN mesh as the editor's new baseline; otherwise a second
      // Exportar Face writes editor-order vertices into BIN-order slots.
      committedMesh=mesh;
      committedBin=result;
      committedDecoded=decoded;
      committedOffsets=offsets;
      toast("BIN exportado: "+edited.vertices.size()+" vertices ("+pendingBinSplits.size()+" divisoes)");
    }finally{
      mesh=previousMesh;
      if(committedMesh!=null){
        // restoreMesh preserves the Mesh instance referenced by UI objects.
        restoreMesh(committedMesh);
        originalBin=committedBin;
        decoded=committedDecoded;
        offsets=committedOffsets;
        uvDirty=false;
        pendingBinSplits.clear();pendingBinSplitSource=null;pendingBinSplitBaseCount=-1;
        undo.clear();redo.clear();undoBinSplits.clear();redoBinSplits.clear();undoSelection.clear();redoSelection.clear();
        status.setText("Face BIN: "+mesh.vertices.size()+" vertices");
      }else{
        originalBin=prevOriginal;decoded=prevDecoded;offsets=prevOffsets;uvDirty=prevUvDirty;
      }
    }
  }
  void splitSelectedEdge(){
    if(view==null||view.selected.size()!=2){toast("Selecione exatamente 2 vértices da mesma linha");return;}
    Iterator<Integer> it=view.selected.iterator();int a=it.next(),b=it.next();
    if(a<0||b<0||a>=mesh.vertices.size()||b>=mesh.vertices.size()){toast("Seleção inválida");return;}
    ArrayList<Integer> connected=new ArrayList<>();
    for(int i=0;i<mesh.faces.size();i++){int[] f=mesh.faces.get(i);if(f.length!=3)continue;
      boolean hasA=false,hasB=false;for(int v:f){if(v==a)hasA=true;if(v==b)hasB=true;}
      if(hasA&&hasB)connected.add(i);
    }
    if(connected.isEmpty()){toast("Os vértices não formam uma aresta");return;}
    // v294: Capture the actual selected BIN, even when the mesh came from OBJ.
    // Do not silently fall back to the old fixed-count exporter.
    if(pendingBinSplits.isEmpty()){
      pendingBinSplitSource=null;pendingBinSplitBaseCount=-1;
      try{
        byte[] candidate=null;
        if(pendingFaceBin!=null)candidate=read(pendingFaceBin);
        else if(originalBin!=null)candidate=originalBin.clone();
        if(candidate!=null){
          byte[] unpacked=PspBinEdgeSplitter.unzip(PspBinEdgeSplitter.slice(candidate,32,candidate.length));
          int root=PspBinEdgeSplitter.u32(unpacked,8);
          int at=root+PspBinEdgeSplitter.u32(unpacked,root+36);
          int total=0;
          int partCount=PspBinEdgeSplitter.u32(unpacked,root+32);
          if(partCount<1||partCount>64)throw new Exception("Quantidade de partes invalida: "+partCount);
          for(int k=0;k<partCount;k++){
            if(at<0||at+96>unpacked.length)throw new Exception("Parte BIN fora do arquivo");
            int partSize=PspBinEdgeSplitter.u32(unpacked,at);
            if(partSize<96||partSize>unpacked.length-at)throw new Exception("Tamanho de parte BIN invalido");
            total+=PspBinEdgeSplitter.u16(unpacked,at+92);
            at+=partSize;
          }
          if(total==mesh.vertices.size()){
            pendingBinSplitSource=candidate;pendingBinSplitBaseCount=total;
          }else{
            toast("BIN selecionado: "+total+" vertices; modelo: "+mesh.vertices.size()+". Importe o BIN correto.");
            return;
          }
        }else{
          toast("Selecione o BIN original antes de Dividir Aresta para exportar BIN.");
          return;
        }
      }catch(Exception e){toast("Nao foi possivel ler o BIN original: "+e.getMessage());return;}
    }
    pushUndo();
    if(pendingBinSplitSource!=null&&mesh.vertices.size()==pendingBinSplitBaseCount+pendingBinSplits.size())
      pendingBinSplits.add(new int[]{a,b});
    while(mesh.faceUvs.size()<mesh.faces.size())mesh.faceUvs.add(mesh.faces.get(mesh.faceUvs.size()).clone());
    float[] va=mesh.vertices.get(a),vb=mesh.vertices.get(b);
    int mid=mesh.vertices.size();mesh.vertices.add(new float[]{(va[0]+vb[0])*.5f,(va[1]+vb[1])*.5f,(va[2]+vb[2])*.5f});
    // UVs are per-corner for OBJ, but per-vertex for PSP. Create midpoint UV for each affected face.
    for(int i=connected.size()-1;i>=0;i--){int fi=connected.get(i);int[] f=mesh.faces.get(fi);
      int ia=-1,ib=-1;for(int k=0;k<3;k++){if(f[k]==a)ia=k;if(f[k]==b)ib=k;}
      int ic=3-ia-ib;int c=f[ic];
      int[] uv=fi<mesh.faceUvs.size()?mesh.faceUvs.get(fi):f;
      int ua=uv[ia],ub=uv[ib],uc=uv[ic];
      float[] uva=ua>=0&&ua<mesh.uvs.size()?mesh.uvs.get(ua):new float[]{0,0};
      float[] uvb=ub>=0&&ub<mesh.uvs.size()?mesh.uvs.get(ub):new float[]{0,0};
      int um=mesh.uvs.size();mesh.uvs.add(new float[]{(uva[0]+uvb[0])*.5f,(uva[1]+uvb[1])*.5f});
      // Preserve winding by replacing the original directed edge with two triangles.
      int k=-1;for(int j=0;j<3;j++)if((f[j]==a&&f[(j+1)%3]==b)||(f[j]==b&&f[(j+1)%3]==a)){k=j;break;}
      if(k<0)continue;
      int v0=f[k],v1=f[(k+1)%3],v2=f[(k+2)%3];
      int t0=uv[k],t1=uv[(k+1)%3],t2=uv[(k+2)%3];
      mesh.faces.set(fi,new int[]{v0,mid,v2});mesh.faces.add(new int[]{mid,v1,v2});
      mesh.faceUvs.set(fi,new int[]{t0,um,t2});
      mesh.faceUvs.add(new int[]{um,t1,t2});
    }
    view.selected.clear();view.selected.add(mid);view.invalidate();if(uvView!=null)uvView.invalidate();
    status.setText("Aresta dividida: "+mesh.vertices.size()+" vértices • exporte OBJ");
    toast("Novo vértice criado no meio da linha");
  }

  class CubeLogo extends View{
    final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    CubeLogo(Context c){super(c);setContentDescription("Face & Hair Editor PSP");}
    void face(Canvas c,int color,float... xy){Path path=new Path();path.moveTo(xy[0],xy[1]);for(int i=2;i<xy.length;i+=2)path.lineTo(xy[i],xy[i+1]);path.close();p.setStyle(Paint.Style.FILL);p.setColor(color);c.drawPath(path,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));p.setColor(0xff9bcaff);c.drawPath(path,p);}
    protected void onDraw(Canvas c){float w=getWidth(),h=getHeight();face(c,0xff1478e7,w*.5f,h*.06f,w*.08f,h*.29f,w*.5f,h*.51f,w*.92f,h*.29f);face(c,0xff1764c3,w*.08f,h*.29f,w*.5f,h*.51f,w*.5f,h*.94f,w*.08f,h*.72f);face(c,0xff0c4da7,w*.5f,h*.51f,w*.92f,h*.29f,w*.92f,h*.72f,w*.5f,h*.94f);}
  }
  class Analog extends View{
    Paint p=new Paint(3);float cx,cy;boolean active=false;
    Analog(Context c){super(c);}
    protected void onDraw(Canvas c){float x=getWidth()/2f,y=getHeight()/2f,r=Math.min(x,y)-dp(5);p.setColor(themeColor(0xff29394c));p.setStyle(Paint.Style.FILL);c.drawCircle(x,y,r,p);p.setColor(themeColor(0xff56728d));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2));c.drawCircle(x,y,r,p);p.setStyle(Paint.Style.FILL);p.setColor(analogNavigationColor);c.drawCircle(x+cx,y+cy,r*.42f,p);}
    public boolean onTouchEvent(MotionEvent e){int a=e.getActionMasked();if(a==MotionEvent.ACTION_UP||a==MotionEvent.ACTION_CANCEL){cx=cy=0;active=false;invalidate();return true;}if(a==MotionEvent.ACTION_DOWN||a==MotionEvent.ACTION_MOVE){float r=Math.min(getWidth(),getHeight())*.37f;float dx=e.getX()-getWidth()/2f,dy=e.getY()-getHeight()/2f;float len=(float)Math.hypot(dx,dy);if(len>r){dx*=r/len;dy*=r/len;}if(active){view.yaw+=dx/r*.055f*navigationSensitivity/100f;view.pitch=Math.max(-1.5f,Math.min(1.5f,view.pitch+dy/r*.055f*navigationSensitivity/100f));view.rearView=false;view.centerGeometryForCurrentAngle();}cx=dx;cy=dy;active=true;invalidate();return true;}return true;}
  }
  static class Mesh{ArrayList<float[]> vertices=new ArrayList<>(),uvs=new ArrayList<>();ArrayList<int[]> faces=new ArrayList<>(),faceUvs=new ArrayList<>();String objectName="PES_PSP_Face",materialName="",materialLibrary="";}
  class ModelView extends View{
    Paint paint=new Paint(3);float yaw=0,pitch=0,zoom=1,panVerticalPx=0;boolean solid=false,rearView=false;
    boolean textured=false,previewOnly=false; float lastX,lastY,lastDist;float[][] pts=new float[0][];float scale=1;
    final HashSet<Integer> selected=new HashSet<>();
    long lastTap=0;float tapX,tapY;boolean selecting=false,positioning=false,dragging=false,changed=false;
    float[] dragOrigin=new float[3];int dragVertex=-1;
    float selX,selY,downX,downY;int axis=0;
    boolean clearedByLongPress=false;
    float cursorX,cursorY;
    boolean cursorWasMoved=false;
    long selectionFlashUntil=0;
    float cursorLastMotionX,cursorLastMotionY;
    final Runnable startBoxAfterPause=()->{
      if(positioning && cursorWasMoved){positioning=false;selecting=true;downX=selX=cursorX;downY=selY=cursorY;selectionFlashUntil=android.os.SystemClock.uptimeMillis()+180;postDelayed(()->invalidate(),190);invalidate();}
    };
    final Runnable clearOnLongPress=()->{
      if(!selecting && !changed && axis==0 && !selected.isEmpty()){
        selected.clear();sync3dToUv();clearedByLongPress=true;
        status.setText("Selecionados: 0 / "+mesh.vertices.size()+" vértices");invalidate();
      }
    }; // 0 free, 1 X, 2 Y, 3 Z
    ModelView(Context c){super(c);setBackgroundColor(viewportBackgroundColor);}
    // Keep the lower preview synchronized with every redraw of the editor.
    @Override public void invalidate(){
      super.invalidate();
      if(!previewOnly && previewEnabled && previewView!=null && previewView!=this)
        previewView.invalidate();
    }
    // Center the visible 3D geometry in the preview, not the model origin.
    float previewVerticalCenter(){
      float cosY=(float)Math.cos(yaw),sinY=(float)Math.sin(yaw);
      float cosP=(float)Math.cos(pitch),sinP=(float)Math.sin(pitch);
      float min=Float.POSITIVE_INFINITY,max=Float.NEGATIVE_INFINITY;
      ArrayList<Mesh> visibleMeshes=new ArrayList<>();
      if(faceVisible)visibleMeshes.add(faceMesh);
      if(hairVisible)visibleMeshes.add(hairMesh);
      for(ExtraObject o:extraFaces)if(o!=null&&o.visible&&o.mesh!=null)visibleMeshes.add(o.mesh);
      for(ExtraObject o:extraHairs)if(o!=null&&o.visible&&o.mesh!=null)visibleMeshes.add(o.mesh);
      for(Mesh m:visibleMeshes)for(float[] v:m.vertices){
        float depth=v[0]*sinY+v[1]*cosY;
        float vertical=v[2]*cosP-depth*sinP;
        min=Math.min(min,vertical);max=Math.max(max,vertical);
      }
      return min<=max?(min+max)*.5f:0f;
    }
    float cameraCenterX=0f,cameraCenterY=0f;
    // Recenter the projected bounds, not the model origin. This changes only
    // the camera translation and preserves zoom and all vertex coordinates.
    void centerGeometryForCurrentAngle(){
      float loX=Float.POSITIVE_INFINITY,hiX=Float.NEGATIVE_INFINITY;
      float loY=Float.POSITIVE_INFINITY,hiY=Float.NEGATIVE_INFINITY;
      float cy=(float)Math.cos(yaw),sy=(float)Math.sin(yaw);
      float cp=(float)Math.cos(pitch),sp=(float)Math.sin(pitch);
      ArrayList<Mesh> models=new ArrayList<>();
      if(faceVisible)models.add(faceMesh);
      if(hairVisible)models.add(hairMesh);
      for(ExtraObject o:extraFaces)if(o!=null&&o.visible&&o.mesh!=null)models.add(o.mesh);
      for(ExtraObject o:extraHairs)if(o!=null&&o.visible&&o.mesh!=null)models.add(o.mesh);
      for(Mesh m:models)if(m!=null)for(float[] v:m.vertices){
        float x=v[0]*cy-v[1]*sy;
        float depth=v[0]*sy+v[1]*cy;
        float vertical=v[2]*cp-depth*sp;
        loX=Math.min(loX,x);hiX=Math.max(hiX,x);
        loY=Math.min(loY,vertical);hiY=Math.max(hiY,vertical);
      }
      if(loX<=hiX){cameraCenterX=(loX+hiX)*.5f;cameraCenterY=(loY+hiY)*.5f;}
      else{cameraCenterX=0f;cameraCenterY=0f;}
      invalidate();
    }
    void angle(float y,float p){yaw=y;pitch=p;rearView=Math.abs(y-(float)Math.PI)<.001f;invalidate();}
    void reset(){yaw=0;pitch=0;rearView=false;invalidate();}
    void adjustZoom(float factor){zoom=Math.max(.15f,Math.min(12f,zoom*factor));saveZoom(zoom);invalidate();}
    void panVertical(float deltaPx){panVerticalPx+=deltaPx;saveVerticalPan(panVerticalPx);invalidate();}
    float[] center(){float x=0,y=0;int n=0;for(int i:selected){if(i<pts.length){x+=pts[i][0];y+=pts[i][1];n++;}}return n==0?new float[]{-100,-100}:new float[]{x/n,y/n};}
    protected void onDraw(Canvas c){super.onDraw(c);int w=getWidth(),h=getHeight();
      float visibleW=(!previewOnly&&(panelShown||transformShown||referenceShown))?Math.max(dp(90),w-panelWidthPx-dp(4)):w;
      float cameraScale=Math.min(visibleW,h)*.38f*zoom/sceneReferenceMax();
      float centerX=visibleW/2f-cameraCenterX*cameraScale;
      float centerY=h/2f+panVerticalPx+cameraCenterY*cameraScale;
      if(previewOnly)centerY+=previewVerticalCenter()*(Math.min(visibleW,h)*.38f*zoom/sceneReferenceMax());
      // Usar a MESMA distância em pixels para X e Y; as células são quadradas.
      // Ancorar ambos os eixos no centro e desenhar nos dois sentidos.
      float grid=Math.max(1,dp(gridSpacingDp));
      if(gridVisible&&!previewOnly&&!(gpuEnabled&&textured&&gpuSurface!=null)){
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor((Math.round(255*gridOpacity/100f)<<24)|(gridLineColor&0x00ffffff));
        paint.setStrokeWidth(dp(.7f));
        int columns=(int)Math.ceil(Math.max(centerX,w-centerX)/grid);
        int rows=(int)Math.ceil(Math.max(centerY,h-centerY)/grid);
        for(int i=-columns;i<=columns;i++){
          float x=centerX+i*grid;
          if(x>=0 && x<=w)c.drawLine(x,0,x,h,paint);
        }
        for(int i=-rows;i<=rows;i++){
          float y=centerY+i*grid;
          if(y>=0 && y<=h)c.drawLine(0,y,w,y,paint);
        }
      }
      // Acima de 100%, a linha já é opaca; reforçar a espessura para aumentar a visibilidade.
      if(!previewOnly&&!(gpuEnabled&&textured&&gpuSurface!=null)){paint.setStrokeWidth(dp(viewportAxisThickness/10f));
      paint.setColor((viewportHorizontalColor&0x00ffffff)|((viewportAxisIntensity*255/100)<<24));c.drawLine(0,centerY,w,centerY,paint);
      paint.setColor((viewportVerticalColor&0x00ffffff)|((viewportAxisIntensity*255/100)<<24));c.drawLine(centerX,0,centerX,h,paint);}
      if(!previewOnly&&referenceVisible&&referenceImage!=null){
        float sc=Math.min(visibleW,h)*.38f*zoom/sceneReferenceMax();
        float x=centerX+referenceX*sc,y=centerY-referenceZ*sc;
        RectF target=new RectF(x-referenceWidth*sc/2f,y-referenceHeight*sc/2f,x+referenceWidth*sc/2f,y+referenceHeight*sc/2f);
        paint.setStyle(Paint.Style.FILL);paint.setColor(Color.WHITE);paint.setAlpha(Math.round(referenceOpacity*255/100f));
        c.save();c.rotate(referenceRotation,x,y);c.drawBitmap(referenceImage,null,target,paint);c.restore();paint.setAlpha(255);
      }
      // OpenGL renders ALL visible meshes with a shared depth buffer.
      // Never paint parked OBJ/BIN objects into the transparent Canvas overlay:
      // Canvas ignores GPU depth and used to cover the face depending on selection.
      if(!(textured && gpuEnabled && gpuSurface!=null)){
        for(ExtraObject extra:extraFaces)if(extra!=null&&extra.mesh!=null&&extra.visible&&!extra.mesh.vertices.isEmpty())
          drawExtra(c,extra,centerX,centerY,visibleW,h);
        for(ExtraObject extra:extraHairs)if(extra!=null&&extra.mesh!=null&&extra.visible&&!extra.mesh.vertices.isEmpty())
          drawExtra(c,extra,centerX,centerY,visibleW,h);
      }
      Mesh other=activeHair?faceMesh:hairMesh;
      boolean activeVisible=activeHair?hairVisible:faceVisible;
      boolean otherVisible=activeHair?faceVisible:hairVisible;
      // Texture: um único buffer de profundidade para Face e Hair.
      if(previewOnly && previewSolidMode){
        gpuRenderer.setPreview(null,0,0,gpuSurface);
        drawSolidPreview(c,centerX,centerY,visibleW,h);return;
      }
      if(!textured && !previewOnly && gpuSurface!=null)gpuRenderer.update(new java.util.ArrayList<DirectGpuRenderer.Batch>(),viewportBackgroundColor,gpuSurface,w,h,centerX,centerY,gridVisible,dp(gridSpacingDp),gridLineColor,gridOpacity,viewportHorizontalColor,viewportVerticalColor,viewportAxisIntensity,dp(viewportAxisThickness/10f));
      if(textured){
        if(gpuEnabled && gpuSurface!=null && (!previewOnly || !previewSolidMode)){
          submitGpuFrame(w,h,centerX,centerY,visibleW);
        }else drawTexturedDepth(c,w,h,centerX,centerY,visibleW);
      }
      if(previewOnly)return;
      if(!textured && otherVisible && !other.vertices.isEmpty())drawOther(c,other,centerX,centerY,visibleW,h);
      if(!activeVisible){pts=new float[0][];drawAxisWidget(c,w,h);return;}
      if(mesh.vertices.isEmpty() && otherVisible && !other.vertices.isEmpty()){drawAxisWidget(c,w,h);return;}
      if(mesh.vertices.isEmpty()){paint.setStyle(Paint.Style.FILL);paint.setColor(blenderTheme?0xffd0d0d0:0xff8fa1b9);paint.setTextSize(dp(15));paint.setTextAlign(Paint.Align.CENTER);c.drawText("VISUALIZADOR 3D",centerX,centerY,paint);drawAxisWidget(c,w,h);return;}
      float max=sceneReferenceMax();
      scale=Math.min(visibleW,h)*.38f*zoom/max;pts=new float[mesh.vertices.size()][2];float[] depths=new float[pts.length];float cy=(float)Math.cos(yaw),sy=(float)Math.sin(yaw),cp=(float)Math.cos(pitch),sp=(float)Math.sin(pitch);
      for(int i=0;i<pts.length;i++){float[] v=mesh.vertices.get(i);float x=v[0]*cy-v[1]*sy,depth=v[0]*sy+v[1]*cy;float vertical=v[2]*cp-depth*sp;pts[i][0]=centerX+x*scale;pts[i][1]=centerY-vertical*scale;depths[i]=depth*cp+v[2]*sp;}
      ArrayList<int[]> ordered=new ArrayList<>();for(int[] f:mesh.faces){if(f.length<3)continue;boolean ok=true;for(int id:f)if(id<0||id>=pts.length)ok=false;if(ok)ordered.add(f);}
      // Vista frontal do Blender olha para +Y: menor profundidade fica mais perto.
      // Canvas não tem z-buffer; desenhar do fundo para a frente evita que
      // triângulos internos da boca cubram os lábios quando a câmera está reta.
      if(solid)Collections.sort(ordered,(a,b)->Float.compare((depths[b[0]]+depths[b[1]]+depths[b[2]])/3f,(depths[a[0]]+depths[a[1]]+depths[a[2]])/3f));
      Bitmap activeBitmap=activeHair?hairTexture:faceTexture;
      for(int[] f:ordered){
        if(textured)continue; // todas as superficies sao desenhadas pelo rasterizador unico
        Path path=new Path();path.moveTo(pts[f[0]][0],pts[f[0]][1]);path.lineTo(pts[f[1]][0],pts[f[1]][1]);path.lineTo(pts[f[2]][0],pts[f[2]][1]);path.close();paint.setStyle(solid?Paint.Style.FILL:Paint.Style.STROKE);paint.setColor(solid?Color.WHITE:wireColor(activeHair));paint.setStrokeWidth(dp(wireThickness/10f));if(solid||((activeHair?hairWireVisible:faceWireVisible) && (activeHair?hairUvWireVisible:faceUvWireVisible))){
          if(!solid && highlightSelectedEdges && selected.size()>=2){
            for(int k=0;k<3;k++){
              int a=f[k],b=f[(k+1)%3];
              paint.setColor(selected.contains(a)&&selected.contains(b)?selectedEdgeColor:wireColor(activeHair));
              c.drawLine(pts[a][0],pts[a][1],pts[b][0],pts[b][1],paint);
            }
          }else c.drawPath(path,paint);
        }}
      // A malha de edição é a MESMA geometria do Wireframe, nunca bordas
      // produzidas acidentalmente pelo recorte dos triângulos texturizados.
      if(textured && ((activeHair?hairWireVisible:faceWireVisible) && (activeHair?hairUvWireVisible:faceUvWireVisible))){
        paint.setShader(null);paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(wireThickness/10f));paint.setColor(wireColor(activeHair));
        for(int[] f:ordered){Path edge=new Path();edge.moveTo(pts[f[0]][0],pts[f[0]][1]);
          edge.lineTo(pts[f[1]][0],pts[f[1]][1]);edge.lineTo(pts[f[2]][0],pts[f[2]][1]);edge.close();
          if(highlightSelectedEdges && selected.size()>=2){
            for(int k=0;k<3;k++){
              int a=f[k],b=f[(k+1)%3];
              paint.setColor(selected.contains(a)&&selected.contains(b)?selectedEdgeColor:wireColor(activeHair));
              c.drawLine(pts[a][0],pts[a][1],pts[b][0],pts[b][1],paint);
            }
          }else c.drawPath(edge,paint);}
      }
      // Linhas selecionadas usam a mesma espessura do wireframe e sao
      // desenhadas como parte dele, sem sobreposicao ou contorno extra.
      if(((activeHair?hairWireVisible:faceWireVisible) && (activeHair?hairUvWireVisible:faceUvWireVisible)) && (activeHair?hairVertices:faceVertices)){
        // Duas passagens: os pontos selecionados sao desenhados POR ULTIMO.
        // Assim, pontos normais sobrepostos nao encobrem nem alteram
        // visualmente o diametro das bolinhas de selecao multipla.
        paint.setShader(null);paint.setStyle(Paint.Style.FILL);
        int pointColor=activeHair?hairVertexColor:faceVertexColor;
        paint.setColor(((vertexOpacity*255/100)<<24)|(pointColor&0xffffff));
        float normalRadius=dp(vertexSize/10f);
        for(int i=0;i<pts.length;i++)if(!selected.contains(i))
          c.drawCircle(pts[i][0],pts[i][1],normalRadius,paint);
        if(editPointVisible){
          paint.setColor(editPointColor);
          float selectedRadius=dp(editPointSize/10f);
          for(int i=0;i<pts.length;i++)if(selected.contains(i))
            c.drawCircle(pts[i][0],pts[i][1],selectedRadius,paint);
        }
      }
      if(editArrowsVisible && !(hideArrowsWhileDragging && dragging) && !selected.isEmpty() && (activeHair?hairVertices:faceVertices)){float[] mid=center();
        for(int a=1;a<=3;a++){float[] d=axisVector(a);float length=(float)Math.hypot(d[0],d[1]);if(length<0.18f)continue;
          float ux=d[0]/length,uy=d[1]/length,ex=mid[0]+ux*dp(29*editArrowSize/100f),ey=mid[1]+uy*dp(29*editArrowSize/100f);
          paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(editArrowThickness/100f));paint.setStrokeCap(Paint.Cap.ROUND);paint.setColor(a==1?editXColor:a==3?editZColor:axisColor(a));
          c.drawLine(mid[0],mid[1],ex,ey,paint);
          float bx=ex-ux*dp(6),by=ey-uy*dp(6),px=-uy,py=ux;
          Path arrow=new Path();arrow.moveTo(ex,ey);arrow.lineTo(bx+px*dp(2.7f),by+py*dp(2.7f));arrow.lineTo(bx-px*dp(2.7f),by-py*dp(2.7f));arrow.close();
          paint.setStyle(Paint.Style.FILL);c.drawPath(arrow,paint);
        }
        // Sem marcador laranja extra no centro do manipulador.
      }
      if(selecting){float l=Math.min(downX,selX),t=Math.min(downY,selY),r=Math.max(downX,selX),b=Math.max(downY,selY);
        paint.setStyle(Paint.Style.FILL);paint.setColor(colorAtIntensity(editSelectionColor,editSelectionIntensity*22/100));c.drawRect(l,t,r,b,paint);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(editSelectionCrossThickness/100f));paint.setColor(colorAtIntensity(editSelectionColor,editSelectionIntensity));c.drawRect(l,t,r,b,paint);
      }
      if(selecting||positioning){
        // Cruz pequena e branca, sem ponto laranja.
        float cross=dp(4), gap=dp(1.3f);
        float crossX=positioning?cursorX:selX, crossY=positioning?cursorY:selY;
        paint.setColor(colorAtIntensity(selecting && android.os.SystemClock.uptimeMillis()<selectionFlashUntil ? 0xffffa32b : editCrossColor,editCrossIntensity));paint.setStrokeWidth(dp(editSelectionCrossThickness/100f));
        c.drawLine(crossX-cross,crossY,crossX-gap,crossY,paint);
        c.drawLine(crossX+gap,crossY,crossX+cross,crossY,paint);
        c.drawLine(crossX,crossY-cross,crossX,crossY-gap,paint);
        c.drawLine(crossX,crossY+gap,crossX,crossY+cross,paint);
      }
      paint.setStyle(Paint.Style.FILL);if(rearView){paint.setColor(0xffa8b7cc);paint.setTextSize(dp(12));paint.setTextAlign(Paint.Align.CENTER);c.drawText("Trás: face aberta, sem geometria da nuca",centerX,dp(25),paint);}
      if(referenceAdjustMode && referenceVisible && referenceImage!=null)drawReferenceHandles(c,centerX,centerY);
      drawAxisWidget(c,w,h);
    }
    // Uma referência de escala para toda a cena, independente da visibilidade
    // ou de qual objeto está ativo. A Face define a escala quando carregada.
    // A escala da camera e capturada quando uma nova malha e carregada.
    // Nao recalcular pelos vertices editados: isso causava zoom-out ao
    // mover um unico vertice para fora dos limites originais.
    // Referencia unica de escala para todos os slots Face/Hair.
    // Trocar o objeto ativo nao pode alterar o enquadramento da camera.
    // v161: memoriza a escala original de cada malha ao entrar na cena.
    // Edicoes dos vertices nao devem alterar o enquadramento/zoom.
    final java.util.IdentityHashMap<Mesh,Float> originalMeshExtents=new java.util.IdentityHashMap<>();
    // v218: referencia estavel da camera: importar novos slots nao muda o zoom.
    // A geometria continua nas coordenadas originais de cada arquivo.
    float fixedCameraReference=0f;
    float sceneReferenceMax(){
      if(fixedCameraReference>0f)return fixedCameraReference;
      Mesh base=(faceMesh!=null&&!faceMesh.vertices.isEmpty())?faceMesh:hairMesh;
      if(base==null||base.vertices.isEmpty())return 1f;
      float extent=1f;
      for(float[] vertex:base.vertices)
        for(float coord:vertex)extent=Math.max(extent,Math.abs(coord));
      fixedCameraReference=extent;
      return fixedCameraReference;
    }
    void drawExtra(Canvas c,ExtraObject extra,float cx,float cy,float vw,int h){
      Mesh model=extra.mesh;
      float sc=Math.min(vw,h)*.38f*zoom/sceneReferenceMax();
      float yy=(float)Math.cos(yaw),ys=(float)Math.sin(yaw),pc=(float)Math.cos(pitch),ps=(float)Math.sin(pitch);
      float[][] points=new float[model.vertices.size()][2];
      for(int i=0;i<points.length;i++){
        float[] v=model.vertices.get(i);float x=v[0]*yy-v[1]*ys,depth=v[0]*ys+v[1]*yy;
        points[i][0]=cx+x*sc;points[i][1]=cy-(v[2]*pc-depth*ps)*sc;
      }
      paint.setStyle(solid?Paint.Style.FILL:Paint.Style.STROKE);
      paint.setStrokeWidth(dp(.5f));paint.setColor(solid?Color.WHITE:wireColor(activeHair));
      for(int[] f:model.faces){if(f.length<3)continue;
        boolean valid=true;for(int id:f)if(id<0||id>=points.length)valid=false;
        if(!valid)continue;
        Path path=new Path();path.moveTo(points[f[0]][0],points[f[0]][1]);
        path.lineTo(points[f[1]][0],points[f[1]][1]);path.lineTo(points[f[2]][0],points[f[2]][1]);path.close();
        if((!textured||extra.texture==null)&&(solid||(extra.wire&&extra.uvWire))){
          c.drawPath(path,paint);
          // Em Solid, selar as bordas dos triangulos com a mesma cor do
          // preenchimento evita linhas residuais de antialiasing em slots inativos.
          if(solid){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1.2f));
            paint.setColor(Color.WHITE);c.drawPath(path,paint);paint.setStyle(Paint.Style.FILL);}
        }
      }
    }
    void drawOther(Canvas c,Mesh other,float cx,float cy,float vw,int h){
      float sc=Math.min(vw,h)*.38f*zoom/sceneReferenceMax();
      float yy=(float)Math.cos(yaw),ys=(float)Math.sin(yaw),pc=(float)Math.cos(pitch),ps=(float)Math.sin(pitch);
      float[][] projected=new float[other.vertices.size()][2];float[] otherDepths=new float[projected.length];
      for(int i=0;i<projected.length;i++){float[] v=other.vertices.get(i);float x=v[0]*yy-v[1]*ys,depth=v[0]*ys+v[1]*yy;
        projected[i][0]=cx+x*sc;projected[i][1]=cy-(v[2]*pc-depth*ps)*sc;otherDepths[i]=depth*pc+v[2]*ps;}
      paint.setStrokeWidth(dp(.5f));paint.setColor(solid?Color.WHITE:wireColor(activeHair));paint.setStyle(solid?Paint.Style.FILL:Paint.Style.STROKE);
      Bitmap otherBitmap=activeHair?faceTexture:hairTexture;
      ArrayList<int[]> otherOrdered=new ArrayList<>(other.faces);
      if(solid)Collections.sort(otherOrdered,(a,b)->Float.compare(
        (otherDepths[b[0]]+otherDepths[b[1]]+otherDepths[b[2]])/3f,
        (otherDepths[a[0]]+otherDepths[a[1]]+otherDepths[a[2]])/3f));
      for(int[] f:otherOrdered){if(f.length<3)continue;boolean ok=true;for(int id:f)if(id<0||id>=projected.length)ok=false;if(!ok)continue;
        if(textured&&otherBitmap!=null){
          continue; // já desenhado pelo renderizador com z-buffer
        }
        Path path=new Path();path.moveTo(projected[f[0]][0],projected[f[0]][1]);
        path.lineTo(projected[f[1]][0],projected[f[1]][1]);path.lineTo(projected[f[2]][0],projected[f[2]][1]);path.close();if(solid || ((activeHair?faceWireVisible:hairWireVisible) && (activeHair?faceUvWireVisible:hairUvWireVisible))){
          c.drawPath(path,paint);
          if(solid){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1.2f));
            paint.setColor(Color.WHITE);c.drawPath(path,paint);paint.setStyle(Paint.Style.FILL);}
        }}
      // Objetos não ativos não exibem vértices editáveis.
    }
    // Rasterização ortográfica com teste de profundidade por pixel. O Canvas
    // não possui z-buffer para os triângulos recortados por clipPath.
    // Reutiliza pixels das texturas e buffers do rasterizador durante o arrasto.
    final java.util.IdentityHashMap<Bitmap,int[]> cachedTexturePixels=new java.util.IdentityHashMap<>();
    int[] rasterPixels=new int[0];
    float[] rasterDepth=new float[0];
    Bitmap rasterFrame;
    int rasterWidth=-1,rasterHeight=-1;
    int[] texturePixels(Bitmap tex){
      int[] cached=cachedTexturePixels.get(tex);
      int size=tex.getWidth()*tex.getHeight();
      if(cached==null||cached.length!=size){
        cached=new int[size];tex.getPixels(cached,0,tex.getWidth(),0,0,tex.getWidth(),tex.getHeight());
        cachedTexturePixels.put(tex,cached);
        // Impede acumular texturas antigas após importar novos arquivos.
        if(cachedTexturePixels.size()>12){cachedTexturePixels.clear();cachedTexturePixels.put(tex,cached);}
      }
      return cached;
    }
    // Keep the photo attached to each vertex at the moment the preview is opened.
    // Sampling at CURRENT positions reprojects a static face photograph and
    // makes edits around eyes/lips look unchanged even when geometry moves.
    final java.util.IdentityHashMap<Mesh,float[][]> photoAnchors=new java.util.IdentityHashMap<>();
    void capturePhotoAnchors(){
      clearTemporaryUvAtlas();
      photoAnchors.clear();
      ArrayList<Mesh> all=new ArrayList<>();all.add(faceMesh);all.add(hairMesh);
      for(ExtraObject o:extraFaces)if(o!=null&&o.mesh!=null)all.add(o.mesh);
      for(ExtraObject o:extraHairs)if(o!=null&&o.mesh!=null)all.add(o.mesh);
      for(Mesh m:all){
        float[][] points=new float[m.vertices.size()][2];
        for(int i=0;i<points.length;i++){
          float[] v=m.vertices.get(i);points[i][0]=v[0];points[i][1]=v[2];
        }
        photoAnchors.put(m,points);
      }
    }
    // Preview-only live photo projection. Coordinates use the same frontal
    // orthographic mapping as Foto -> UV, without writing UV/PNG/BIN.
    Bitmap livePhotoSource(){
      if(referenceImage==null)return null;
      if(!useColorBase||colorBaseImage==null)return referenceImage;
      if(livePhotoCache==null||livePhotoOriginal!=referenceImage||livePhotoBase!=colorBaseImage
          ||livePhotoBrightness!=matchBaseBrightness||livePhotoStrength!=baseBrightnessStrength){
        livePhotoCache=matchSkinTone(referenceImage,colorBaseImage);
        livePhotoOriginal=referenceImage;livePhotoBase=colorBaseImage;
        livePhotoBrightness=matchBaseBrightness;livePhotoStrength=baseBrightnessStrength;
      }
      return livePhotoCache;
    }
    // Temporary atlas: project photo into the actual UV coordinates once,
    // then render all subsequent vertex edits through the regular UV sampler.
    Bitmap temporaryUvAtlas; Mesh temporaryUvMesh;
    Bitmap temporaryUvPhoto; float[] temporaryUvParams;
    void clearTemporaryUvAtlas(){temporaryUvAtlas=null;temporaryUvMesh=null;temporaryUvPhoto=null;temporaryUvParams=null;}
    Bitmap temporaryPhotoAtlas(Mesh model,Bitmap photo){
      if(model==null||photo==null||model.faces.isEmpty())return null;
      float[] params={referenceX,referenceZ,referenceWidth,referenceHeight,referenceRotation};
      boolean unchanged=temporaryUvAtlas!=null&&temporaryUvMesh==model&&temporaryUvPhoto==photo&&
        java.util.Arrays.equals(params,temporaryUvParams);
      if(unchanged)return temporaryUvAtlas;
      float[][] anchor=photoAnchors.get(model);
      if(anchor==null||anchor.length!=model.vertices.size()){capturePhotoAnchors();anchor=photoAnchors.get(model);}
      final int size=1024;
      Bitmap atlas=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);
      Canvas c=new Canvas(atlas);c.drawColor(Color.TRANSPARENT,PorterDuff.Mode.CLEAR);
      double ang=Math.toRadians(referenceRotation),co=Math.cos(ang),si=Math.sin(ang);
      float rw=Math.max(.00001f,referenceWidth),rh=Math.max(.00001f,referenceHeight);
      Paint paint=new Paint(Paint.FILTER_BITMAP_FLAG);
      for(int fi=0;fi<model.faces.size();fi++){
        int[] f=model.faces.get(fi);
        int[] uvIds=fi<model.faceUvs.size()?model.faceUvs.get(fi):f;
        if(f.length<3||uvIds.length<3)continue;
        float[] source=new float[6],target=new float[6];boolean valid=true;
        for(int k=0;k<3;k++){
          int vi=f[k],ui=uvIds[k];
          if(vi<0||vi>=anchor.length||ui<0||ui>=model.uvs.size()){valid=false;break;}
          float x=anchor[vi][0]-referenceX,z=anchor[vi][1]-referenceZ;
          source[2*k]=(float)((x*co-z*si)/rw+.5f)*photo.getWidth();
          source[2*k+1]=(float)((-x*si-z*co)/rh+.5f)*photo.getHeight();
          float[] uv=model.uvs.get(ui);
          target[2*k]=uv[0]*size;target[2*k+1]=(1f-uv[1])*size;
        }
        if(!valid)continue;
        Matrix mat=new Matrix();if(!mat.setPolyToPoly(source,0,target,0,3))continue;
        Path clip=new Path();clip.moveTo(target[0],target[1]);clip.lineTo(target[2],target[3]);clip.lineTo(target[4],target[5]);clip.close();
        c.save();c.clipPath(clip);c.drawBitmap(photo,mat,paint);c.restore();
      }
      temporaryUvAtlas=atlas;temporaryUvMesh=model;temporaryUvPhoto=photo;temporaryUvParams=params;
      return atlas;
    }
    Bitmap livePhotoCache,livePhotoOriginal,livePhotoBase;
    boolean livePhotoBrightness;int livePhotoStrength=-1;
    void drawSolidPreview(Canvas c,float cx,float cy,float visibleW,int height){
      final float sc=Math.min(visibleW,height)*.38f*zoom/sceneReferenceMax();
      final float cyaw=(float)Math.cos(yaw),syaw=(float)Math.sin(yaw);
      final float cp=(float)Math.cos(pitch),sp=(float)Math.sin(pitch);
      class Triangle {float[] x=new float[3],y=new float[3];float depth;int color;}
      ArrayList<Triangle> tris=new ArrayList<>();
      ArrayList<Mesh> meshes=new ArrayList<>();
      if(faceVisible)meshes.add(faceMesh);
      if(hairVisible)meshes.add(hairMesh);
      for(ExtraObject o:extraFaces)if(o!=null&&o.visible&&o.mesh!=null)meshes.add(o.mesh);
      for(ExtraObject o:extraHairs)if(o!=null&&o.visible&&o.mesh!=null)meshes.add(o.mesh);
      for(Mesh model:meshes){
        int n=model.vertices.size();if(n==0)continue;
        float[][] coords=new float[n][3];
        for(int i=0;i<n;i++){
          float[] v=model.vertices.get(i);
          float xx=v[0]*cyaw-v[1]*syaw,dd=v[0]*syaw+v[1]*cyaw;
          coords[i][0]=cx+xx*sc;
          coords[i][1]=cy-(v[2]*cp-dd*sp)*sc;
          coords[i][2]=dd*cp+v[2]*sp;
        }
        for(int[] f:model.faces){
          if(f.length<3)continue;
          for(int k=1;k<f.length-1;k++){
            int[] ids={f[0],f[k],f[k+1]};
            if(ids[0]<0||ids[1]<0||ids[2]<0||ids[0]>=n||ids[1]>=n||ids[2]>=n)continue;
            Triangle t=new Triangle();float d=0;
            for(int j=0;j<3;j++){float[] q=coords[ids[j]];t.x[j]=q[0];t.y[j]=q[1];d+=q[2];}
            t.depth=d/3f;
            float[] a=coords[ids[0]],b=coords[ids[1]],cc=coords[ids[2]];
            float ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2];
            float vx=cc[0]-a[0],vy=cc[1]-a[1],vz=cc[2]-a[2];
            float nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;
            float len=(float)Math.sqrt(nx*nx+ny*ny+nz*nz);
            float light=len<.00001f?.65f:.38f+.62f*Math.abs((nx*.3f-ny*.45f+nz*.85f)/len);
            int value=Math.max(45,Math.min(220,(int)(185*light)));
            t.color=Color.rgb(value,value,value);
            tris.add(t);
          }
        }
      }
      // Larger camera depth is farther away in the front view.
      Collections.sort(tris,(a,b)->Float.compare(b.depth,a.depth));
      Paint fill=new Paint(Paint.ANTI_ALIAS_FLAG);fill.setStyle(Paint.Style.FILL);
      for(Triangle t:tris){
        Path path=new Path();path.moveTo(t.x[0],t.y[0]);path.lineTo(t.x[1],t.y[1]);path.lineTo(t.x[2],t.y[2]);path.close();
        fill.setColor(t.color);c.drawPath(path,fill);
      }
    }

    void submitGpuFrame(int w,int h,float cx,float cy,float visibleW){
      java.util.ArrayList<DirectGpuRenderer.Batch> batches=new java.util.ArrayList<>();
      float sc=Math.min(visibleW,h)*.38f*zoom/sceneReferenceMax();
      float cosY=(float)Math.cos(yaw),sinY=(float)Math.sin(yaw),cosP=(float)Math.cos(pitch),sinP=(float)Math.sin(pitch);
      java.util.ArrayList<Mesh> models=new java.util.ArrayList<>();
      java.util.ArrayList<Bitmap> textures=new java.util.ArrayList<>();
      models.add(faceMesh);textures.add(faceTexture);models.add(hairMesh);textures.add(hairTexture);
      for(ExtraObject o:extraFaces)if(o!=null&&o.visible&&o.mesh!=null){models.add(o.mesh);textures.add(o.texture);}
      for(ExtraObject o:extraHairs)if(o!=null&&o.visible&&o.mesh!=null){models.add(o.mesh);textures.add(o.texture);}
      // A troca do slot ativo move a malha entre os slots internos.
      // Renderizar sempre na mesma ordem de identidade, independente da selecao.
      // Preserva os pares malha/textura e evita que superficies coplanares
      // mudem de aparencia quando o usuario alterna Face 1/Face 2/Hair.
      java.util.ArrayList<Integer> drawOrder=new java.util.ArrayList<>();
      for(int i=0;i<models.size();i++){
        if(i==0&&!faceVisible||i==1&&!hairVisible)continue;
        if(models.get(i)!=null)drawOrder.add(i);
      }
      java.util.Collections.sort(drawOrder,(a,b)->Integer.compare(
          System.identityHashCode(models.get(a)),System.identityHashCode(models.get(b))));
      for(int orderedIndex:drawOrder){
        int m=orderedIndex;
        if(m==0&&!faceVisible||m==1&&!hairVisible)continue;
        Mesh model=models.get(m);Bitmap tex=textures.get(m);
        if(previewOnly && previewPhotoMode && referenceImage!=null &&
           (model==faceMesh || model==hairMesh || model==mesh)){
          Bitmap photo=getPreviewPhotoAtlas(model);
          if(photo!=null)tex=photo;
        }
        if(model==null||model.vertices.isEmpty())continue;
        float[] packed=new float[model.faces.size()*15];int k=0;
        for(int fi=0;fi<model.faces.size();fi++){
          int[] f=model.faces.get(fi);if(f.length!=3)continue;
          int[] ids=fi<model.faceUvs.size()?model.faceUvs.get(fi):f;
          for(int j=0;j<3;j++){
            int id=f[j];if(id<0||id>=model.vertices.size())continue;
            float[] v=model.vertices.get(id);
            float x=v[0]*cosY-v[1]*sinY,depth=v[0]*sinY+v[1]*cosY;
            float y=v[2]*cosP-depth*sinP;
            float z=depth*cosP+v[2]*sinP;
            packed[k++]=2f*(cx+x*sc)/w-1f;
            packed[k++]=1f-2f*(cy-y*sc)/h;
            packed[k++]=Math.max(-.99f,Math.min(.99f,z/100f));
            int ui=j<ids.length?ids[j]:-1;
            float[] uv=ui>=0&&ui<model.uvs.size()?model.uvs.get(ui):null;
            packed[k++]=uv==null?0:uv[0];packed[k++]=uv==null?0:1f-uv[1];
          }
        }
        if(k>0)batches.add(new DirectGpuRenderer.Batch(java.util.Arrays.copyOf(packed,k),tex));
      }
      if(previewOnly)gpuRenderer.setPreview(batches,h,previewView.getTop(),gpuSurface);
      else gpuRenderer.update(batches,viewportBackgroundColor,gpuSurface, w,h,cx,cy,gridVisible,dp(gridSpacingDp),gridLineColor,gridOpacity,viewportHorizontalColor,viewportVerticalColor,viewportAxisIntensity,dp(viewportAxisThickness/10f));
    }
    void drawTexturedDepth(Canvas canvas,int w,int h,float cx,float cy,float visibleW){
      if(w<=0||h<=0)return;
      // Reduzir apenas o raster das texturas, sem alterar a escala do modelo,
      // o wireframe, a seleção ou as coordenadas de toque na tela.
      final int outputW=w, outputH=h;
      final boolean fastDrag=dragging;
      if(fastDrag){
        final float quality=.65f;
        w=Math.max(1,Math.round(w*quality));
        h=Math.max(1,Math.round(h*quality));
        cx*=quality;cy*=quality;visibleW*=quality;
      }
      ArrayList<Mesh> models=new ArrayList<>();ArrayList<Bitmap> textures=new ArrayList<>();ArrayList<Boolean> visible=new ArrayList<>();
      models.add(faceMesh);textures.add(faceTexture);visible.add(faceVisible);
      models.add(hairMesh);textures.add(hairTexture);visible.add(hairVisible);
      for(ExtraObject o:extraFaces)if(o!=null&&o.mesh!=null){models.add(o.mesh);textures.add(o.texture);visible.add(o.visible);}
      for(ExtraObject o:extraHairs)if(o!=null&&o.mesh!=null){models.add(o.mesh);textures.add(o.texture);visible.add(o.visible);}
      // Only the lower 3D Preview gets the temporary photo. The upper editor
      // and the stored textures remain unchanged.
      Bitmap livePhoto=previewOnly&&previewPhotoMode&&referenceVisible?livePhotoSource():null;
      int[] liveTexels=livePhoto==null?null:texturePixels(livePhoto);
      int liveW=livePhoto==null?0:livePhoto.getWidth(),liveH=livePhoto==null?0:livePhoto.getHeight();
      float refHalfW=Math.max(.00001f,referenceWidth*.5f),refHalfH=Math.max(.00001f,referenceHeight*.5f);
      double refAngle=Math.toRadians(referenceRotation),refCos=Math.cos(refAngle),refSin=Math.sin(refAngle);
      float sc=Math.min(visibleW,h)*.38f*zoom/sceneReferenceMax();
      float cosY=(float)Math.cos(yaw),sinY=(float)Math.sin(yaw);
      float cosP=(float)Math.cos(pitch),sinP=(float)Math.sin(pitch);
      int count=w*h;
      if(rasterPixels.length<count){rasterPixels=new int[count];rasterDepth=new float[count];}
      java.util.Arrays.fill(rasterPixels,0,count,0);
      java.util.Arrays.fill(rasterDepth,0,count,Float.POSITIVE_INFINITY);
      int[] pixels=rasterPixels;float[] zbuffer=rasterDepth;
      boolean rendered=false;
      for(int m=0;m<models.size();m++){
        Mesh model=models.get(m);Bitmap tex=textures.get(m);
        boolean photoOnModel=false;
        // Usar no Preview a mesma textura UV calculada pela ação Foto -> UV,
        // inclusive quando a malha ativa for Hair ou um objeto extra.
        // Não substituir faceTexture/hairTexture nem os UVs persistentes.
        if(previewOnly&&previewPhotoMode&&referenceImage!=null &&
           (model==faceMesh || model==hairMesh || model==mesh)){
          Bitmap generated=getPreviewPhotoAtlas(model);
          if(generated!=null)tex=generated;
        }
        // Preview Foto now uses the exact Foto -> UV rasterization, without applying it.
        if(!visible.get(m)||model.vertices.isEmpty())continue;
        boolean flatWhite=tex==null && !photoOnModel;
        if(!flatWhite && !photoOnModel && model.uvs.isEmpty())continue;
        int tw=tex==null?0:tex.getWidth(),th=tex==null?0:tex.getHeight();
        if(!flatWhite&&!photoOnModel&&(tw<=0||th<=0))continue;
        int[] texels=tex==null?null:texturePixels(tex);
        int n=model.vertices.size();float[][] screen=new float[n][3];
        float[][] anchor=photoAnchors.get(model);
        if(previewOnly&&photoOnModel&&(anchor==null||anchor.length!=n)){capturePhotoAnchors();anchor=photoAnchors.get(model);}
        for(int i=0;i<n;i++){
          float[] v=model.vertices.get(i);
          float x=v[0]*cosY-v[1]*sinY;
          float depth=v[0]*sinY+v[1]*cosY;
          screen[i][0]=cx+x*sc;
          screen[i][1]=cy-(v[2]*cosP-depth*sinP)*sc;
          screen[i][2]=depth*cosP+v[2]*sinP;
        }
        for(int fi=0;fi<model.faces.size();fi++){
          int[] f=model.faces.get(fi);
          if(f.length!=3)continue;
          int[] faceUv=fi<model.faceUvs.size()?model.faceUvs.get(fi):f;
          if(!flatWhite&&!photoOnModel&&faceUv.length<3)continue;
          int u0=photoOnModel?0:faceUv[0],u1=photoOnModel?0:faceUv[1],u2=photoOnModel?0:faceUv[2];
          if(!flatWhite&&!photoOnModel&&(u0<0||u1<0||u2<0||u0>=model.uvs.size()||u1>=model.uvs.size()||u2>=model.uvs.size()))continue;
          int i0=f[0],i1=f[1],i2=f[2];
          if(i0<0||i1<0||i2<0||i0>=n||i1>=n||i2>=n)continue;
          float[] a=screen[i0],b=screen[i1],d=screen[i2];
          float area=(b[0]-a[0])*(d[1]-a[1])-(b[1]-a[1])*(d[0]-a[0]);
          if(Math.abs(area)<.00001f)continue;
          float[] uv0=(photoOnModel||flatWhite)?null:model.uvs.get(u0),uv1=(photoOnModel||flatWhite)?null:model.uvs.get(u1),uv2=(photoOnModel||flatWhite)?null:model.uvs.get(u2);
          float[] vert0=model.vertices.get(i0),vert1=model.vertices.get(i1),vert2=model.vertices.get(i2);
          int minX=Math.max(0,(int)Math.floor(Math.min(a[0],Math.min(b[0],d[0]))));
          int maxX=Math.min(w-1,(int)Math.ceil(Math.max(a[0],Math.max(b[0],d[0]))));
          int minY=Math.max(0,(int)Math.floor(Math.min(a[1],Math.min(b[1],d[1]))));
          int maxY=Math.min(h-1,(int)Math.ceil(Math.max(a[1],Math.max(b[1],d[1]))));
          for(int y=minY;y<=maxY;y++)for(int x=minX;x<=maxX;x++){
            float px=x+.5f,py=y+.5f;
            float wb=((d[0]-px)*(a[1]-py)-(d[1]-py)*(a[0]-px))/area;
            float wc=((a[0]-px)*(b[1]-py)-(a[1]-py)*(b[0]-px))/area;
            float wa=1f-wb-wc;
            if(wa<-.00001f||wb<-.00001f||wc<-.00001f)continue;
            float depth=wa*a[2]+wb*b[2]+wc*d[2];
            int idx=y*w+x;
            // Na vista frontal, o menor Y de câmera é a superfície próxima.
            if(depth>=zbuffer[idx])continue;
            if(flatWhite){pixels[idx]=Color.WHITE;zbuffer[idx]=depth;rendered=true;continue;}
            float u=photoOnModel?0f:wa*uv0[0]+wb*uv1[0]+wc*uv2[0];
            float v=photoOnModel?0f:1f-(wa*uv0[1]+wb*uv1[1]+wc*uv2[1]);
            boolean photoPixel=false;
            float tx=0,ty=0;
            int[] sampleTexels=texels;
            int sampleW=tw,sampleH=th;
            if(photoOnModel && liveTexels!=null){
              // Photo mode uses original vertex positions, not the UV atlas.
              // Keep the photograph mostly bound to the original vertices, so
              // eyes and lips follow mesh edits. Blend a small amount of the
              // current position to reduce extreme texture stretching at the
              // boundary of a moved vertex selection. This changes ONLY the
              // temporary preview; BIN geometry and stored UVs are untouched.
              float originalX=anchor!=null?wa*anchor[i0][0]+wb*anchor[i1][0]+wc*anchor[i2][0]:wa*vert0[0]+wb*vert1[0]+wc*vert2[0];
              float originalZ=anchor!=null?wa*anchor[i0][1]+wb*anchor[i1][1]+wc*anchor[i2][1]:wa*vert0[2]+wb*vert1[2]+wc*vert2[2];
              float currentX=wa*vert0[0]+wb*vert1[0]+wc*vert2[0];
              float currentZ=wa*vert0[2]+wb*vert1[2]+wc*vert2[2];
              float modelX=originalX-referenceX;
              float modelZ=originalZ-referenceZ;
              // Screen Y grows downwards; identical to generatePhotoUv().
              float localX=(float)(modelX*refCos-modelZ*refSin);
              float localY=(float)(-modelX*refSin-modelZ*refCos);
              float pu=(localX/(2f*refHalfW)+.5f),pv=(localY/(2f*refHalfH)+.5f);
              if(pu>=0&&pu<=1&&pv>=0&&pv<=1){
                photoPixel=true;sampleTexels=liveTexels;sampleW=liveW;sampleH=liveH;
                tx=pu*(sampleW-1);ty=pv*(sampleH-1);
              }
            }
            if(!photoPixel){
              // Never fall back to the UV texture in Preview Foto.
              if(photoOnModel||texels==null)continue;
              tx=Math.max(0,Math.min(tw-1,u*(tw-1)));
              ty=Math.max(0,Math.min(th-1,v*(th-1)));
            }
            int x0=(int)tx,y0=(int)ty,x1=Math.min(sampleW-1,x0+1),y1=Math.min(sampleH-1,y0+1);
            float fx=tx-x0,fy=ty-y0;
            int p00=sampleTexels[y0*sampleW+x0],p10=sampleTexels[y0*sampleW+x1],p01=sampleTexels[y1*sampleW+x0],p11=sampleTexels[y1*sampleW+x1];
            float k00=(1-fx)*(1-fy),k10=fx*(1-fy),k01=(1-fx)*fy,k11=fx*fy;
            int red=(int)(((p00>>16)&255)*k00+((p10>>16)&255)*k10+((p01>>16)&255)*k01+((p11>>16)&255)*k11);
            int green=(int)(((p00>>8)&255)*k00+((p10>>8)&255)*k10+((p01>>8)&255)*k01+((p11>>8)&255)*k11);
            int blue=(int)((p00&255)*k00+(p10&255)*k10+(p01&255)*k01+(p11&255)*k11);
            if(m==1 && hairAlphaMode!=HAIR_OPAQUE){
              // A textura Hair usa o canal alpha do PNG. O blend é feito
              // sobre a Face já renderizada, preservando o fundo transparente.
              float alpha=(((p00>>>24)&255)*k00+((p10>>>24)&255)*k10+
                           ((p01>>>24)&255)*k01+((p11>>>24)&255)*k11)/255f;
              if(hairAlphaMode==HAIR_ALPHA_CLIP){
                if(alpha<.5f)continue;
              }else{
                if(alpha<=.001f)continue;
                int base=pixels[idx];
                float outAlpha=alpha+(1f-alpha)*((base>>>24)&255)/255f;
                // Cor interpolada em alpha premultiplicado para reduzir halos.
                float rPrem=(((p00>>>16)&255)*((p00>>>24)&255)*k00+
                             ((p10>>>16)&255)*((p10>>>24)&255)*k10+
                             ((p01>>>16)&255)*((p01>>>24)&255)*k01+
                             ((p11>>>16)&255)*((p11>>>24)&255)*k11)/255f;
                float gPrem=(((p00>>>8)&255)*((p00>>>24)&255)*k00+
                             ((p10>>>8)&255)*((p10>>>24)&255)*k10+
                             ((p01>>>8)&255)*((p01>>>24)&255)*k01+
                             ((p11>>>8)&255)*((p11>>>24)&255)*k11)/255f;
                float bPrem=((p00&255)*((p00>>>24)&255)*k00+
                             (p10&255)*((p10>>>24)&255)*k10+
                             (p01&255)*((p01>>>24)&255)*k01+
                             (p11&255)*((p11>>>24)&255)*k11)/255f;
                float oldAlpha=((base>>>24)&255)/255f;
                float remain=(1f-alpha)*oldAlpha;
                if(outAlpha>0){
                  red=(int)Math.min(255,(rPrem+((base>>>16)&255)*remain)/outAlpha);
                  green=(int)Math.min(255,(gPrem+((base>>>8)&255)*remain)/outAlpha);
                  blue=(int)Math.min(255,(bPrem+(base&255)*remain)/outAlpha);
                }
                pixels[idx]=((int)(outAlpha*255)<<24)|(red<<16)|(green<<8)|blue;
                // Transparent pixels must not block the Face behind them.
                // Semi-transparent pixels blend without replacing the opaque z-buffer.
                if(alpha>=.999f)zbuffer[idx]=depth;
                rendered=true;continue;
              }
            }
            pixels[idx]=0xff000000|(red<<16)|(green<<8)|blue;
            zbuffer[idx]=depth;rendered=true;
          }
        }
      }
      if(rendered){
        if(rasterFrame==null||rasterWidth!=w||rasterHeight!=h||rasterFrame.isRecycled()){
          if(rasterFrame!=null&&!rasterFrame.isRecycled())rasterFrame.recycle();
          rasterFrame=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
          rasterWidth=w;rasterHeight=h;
        }
        rasterFrame.setPixels(pixels,0,w,0,0,w,h);
        Paint bitmapPaint=new Paint(Paint.FILTER_BITMAP_FLAG);
        if(fastDrag)canvas.drawBitmap(rasterFrame,null,new Rect(0,0,outputW,outputH),bitmapPaint);
        else canvas.drawBitmap(rasterFrame,0,0,bitmapPaint);
      }
    }
    boolean drawTexturedTriangle(Canvas canvas,Mesh model,Bitmap bitmap,int[] f,float[][] xy){
      if(f.length!=3||model.uvs.size()!=model.vertices.size())return false;
      float[] a=model.uvs.get(f[0]),b=model.uvs.get(f[1]),d=model.uvs.get(f[2]);
      float u0=a[0]*bitmap.getWidth(),v0=(1-a[1])*bitmap.getHeight();
      float u1=b[0]*bitmap.getWidth(),v1=(1-b[1])*bitmap.getHeight();
      float u2=d[0]*bitmap.getWidth(),v2=(1-d[1])*bitmap.getHeight();
      float det=(u1-u0)*(v2-v0)-(u2-u0)*(v1-v0);
      if(Math.abs(det)<.001f)return false;
      float x0=xy[f[0]][0],y0=xy[f[0]][1],x1=xy[f[1]][0],y1=xy[f[1]][1],x2=xy[f[2]][0],y2=xy[f[2]][1];
      float a00=((x1-x0)*(v2-v0)-(x2-x0)*(v1-v0))/det;
      float a01=((x2-x0)*(u1-u0)-(x1-x0)*(u2-u0))/det;
      float a10=((y1-y0)*(v2-v0)-(y2-y0)*(v1-v0))/det;
      float a11=((y2-y0)*(u1-u0)-(y1-y0)*(u2-u0))/det;
      Matrix matrix=new Matrix();matrix.setValues(new float[]{a00,a01,x0-a00*u0-a01*v0,a10,a11,y0-a10*u0-a11*v0,0,0,1});
      // Cada triângulo recebe um recorte ligeiramente expandido. Sem essa
      // cobertura, pixels de fundo escapam entre dois recortes adjacentes e
      // parecem linhas escuras fixas (mesmo sem vértices/arestas desenhados).
      float mx=(x0+x1+x2)/3f,my=(y0+y1+y2)/3f;
      float seam=0.85f; // pixels de tela, não altera coordenadas UV ou malha
      float[] xx={x0,x1,x2}, yy={y0,y1,y2};
      Path tri=new Path();
      for(int i=0;i<3;i++){
        float dx=xx[i]-mx,dy=yy[i]-my,len=(float)Math.hypot(dx,dy);
        float nx=xx[i]+(len>0?seam*dx/len:0),ny=yy[i]+(len>0?seam*dy/len:0);
        if(i==0)tri.moveTo(nx,ny);else tri.lineTo(nx,ny);
      }
      tri.close();
      int save=canvas.save();canvas.clipPath(tri);
      Paint texturePaint=new Paint(Paint.FILTER_BITMAP_FLAG);
      texturePaint.setAntiAlias(false);
      BitmapShader shader=new BitmapShader(bitmap,Shader.TileMode.CLAMP,Shader.TileMode.CLAMP);
      shader.setLocalMatrix(matrix);texturePaint.setShader(shader);
      canvas.drawPaint(texturePaint);canvas.restoreToCount(save);return true;
    }
    void drawAxisWidget(Canvas c,int w,int h){
      float x=dp(21),y=h-dp(25);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(2));paint.setStrokeCap(Paint.Cap.ROUND);
      paint.setColor(0xffed4b4b);c.drawLine(x,y,x+dp(26),y,paint);paint.setStyle(Paint.Style.FILL);paint.setTextSize(dp(10));paint.setTextAlign(Paint.Align.LEFT);c.drawText("X",x+dp(29),y+dp(4),paint);
      paint.setStyle(Paint.Style.STROKE);paint.setColor(0xff3478e5);c.drawLine(x,y,x,y-dp(26),paint);paint.setStyle(Paint.Style.FILL);c.drawText("Z",x-dp(3),y-dp(30),paint);
      paint.setColor(0xff37bd71);c.drawCircle(x,y,dp(3),paint);paint.setStyle(Paint.Style.FILL);
    }
    int axisColor(int a){return a==1?0xfff04d4d:a==2?0xff48c981:0xff4b9fff;}
    // Project the model-space unit axes into the screen plane, using the same camera as the mesh.
    float[] axisVector(int a){float cy=(float)Math.cos(yaw),sy=(float)Math.sin(yaw),cp=(float)Math.cos(pitch),sp=(float)Math.sin(pitch);
      if(a==1)return new float[]{cy,sy*sp};
      if(a==2)return new float[]{-sy,cy*sp};
      return new float[]{0,-cp};
    }
    int hitAxis(float x,float y){if(selected.isEmpty())return 0;float[] m=center();int hit=0;float best=dp(15);
      for(int a=1;a<=3;a++){float[] d=axisVector(a);float n=(float)Math.hypot(d[0],d[1]);if(n<.18f)continue;
        float ex=m[0]+d[0]/n*dp(29),ey=m[1]+d[1]/n*dp(29);
        float dist=(float)Math.hypot(x-ex,y-ey);if(dist<best){best=dist;hit=a;}}
      return hit;
    }
    void selectBox(){if(!cumulativeMultiSelection)selected.clear();float l=Math.min(downX,selX),r=Math.max(downX,selX),t=Math.min(downY,selY),b=Math.max(downY,selY);
      for(int i=0;i<pts.length;i++)if(pts[i][0]>=l&&pts[i][0]<=r&&pts[i][1]>=t&&pts[i][1]<=b)selected.add(i);
      status.setText("Selecionados: "+selected.size()+" / "+mesh.vertices.size()+" vértices");sync3dToUv();invalidate();}
    void moveSelection(float dx,float dy){if(selected.isEmpty())return;
      float a=dx/Math.max(scale,.0001f),b=-dy/Math.max(scale,.0001f);
      float cy=(float)Math.cos(yaw),sy=(float)Math.sin(yaw),cp=(float)Math.cos(pitch),sp=(float)Math.sin(pitch);
      float mx=0,my=0,mz=0;
      if(axis!=0){float[] d=axisVector(axis);float denom=d[0]*d[0]+d[1]*d[1];if(denom<.0324f)return;
        float delta=(a*d[0]-b*d[1])/denom;
        if(axis==1)mx=delta;else if(axis==2)my=delta;else mz=delta;
      }else{mx=a*cy+b*sp*sy;my=-a*sy+b*sp*cy;mz=b*cp;}
      int n=mesh.vertices.size();
      if(proportionalEditing && selected.size()<n){
        // Capture distances before moving any vertex; never cascade the falloff.
        float minX=Float.MAX_VALUE,minY=Float.MAX_VALUE,minZ=Float.MAX_VALUE;
        float maxX=-Float.MAX_VALUE,maxY=-Float.MAX_VALUE,maxZ=-Float.MAX_VALUE;
        for(float[] v:mesh.vertices){minX=Math.min(minX,v[0]);minY=Math.min(minY,v[1]);minZ=Math.min(minZ,v[2]);maxX=Math.max(maxX,v[0]);maxY=Math.max(maxY,v[1]);maxZ=Math.max(maxZ,v[2]);}
        float diagonal=(float)Math.sqrt((maxX-minX)*(maxX-minX)+(maxY-minY)*(maxY-minY)+(maxZ-minZ)*(maxZ-minZ));
        float radius=Math.max(.00001f,diagonal*proportionalRadius/100f);
        float[] weights=new float[n];
        for(int i=0;i<n;i++){
          if(selected.contains(i)){weights[i]=1f;continue;}
          float[] v=mesh.vertices.get(i);float closest=radius*radius;
          for(int j:selected){if(j<0||j>=n)continue;float[] q=mesh.vertices.get(j);
            float xx=v[0]-q[0],yy=v[1]-q[1],zz=v[2]-q[2];
            float dist=xx*xx+yy*yy+zz*zz;if(dist<closest)closest=dist;
          }
          float t=1f-(float)Math.sqrt(closest)/radius;
          weights[i]=t>0f?t*t*(3f-2f*t):0f;
        }
        for(int i=0;i<n;i++){float w=weights[i];if(w==0f)continue;float[] v=mesh.vertices.get(i);v[0]+=mx*w;v[1]+=my*w;v[2]+=mz*w;}
      }else for(int i:selected){if(i<0||i>=n)continue;float[] v=mesh.vertices.get(i);v[0]+=mx;v[1]+=my;v[2]+=mz;}
      invalidate();
    }
    float refTouchX,refTouchY,refPinchDist,refLastAngle;
    float refStartX,refStartY,refStartW,refStartH,refStartRotation,refDownX,refDownY;
    int refDragMode=0; // 1 mover, 2-9 alças, 10 girar, 11 pinça
    float refScale(){float vw=(panelShown||transformShown||referenceShown)?Math.max(dp(90),getWidth()-panelWidthPx-dp(4)):getWidth();return Math.min(vw,getHeight())*.38f*zoom/sceneReferenceMax();}
    float[] refCenter(){float vw=(panelShown||transformShown||referenceShown)?Math.max(dp(90),getWidth()-panelWidthPx-dp(4)):getWidth();float sc=refScale();return new float[]{vw/2f-cameraCenterX*sc+referenceX*sc,getHeight()/2f+panVerticalPx+cameraCenterY*sc-referenceZ*sc};}
    float[] refLocal(float x,float y){float[] cc=refCenter();double r=Math.toRadians(referenceRotation);float dx=x-cc[0],dy=y-cc[1];return new float[]{(float)(dx*Math.cos(r)+dy*Math.sin(r)),(float)(-dx*Math.sin(r)+dy*Math.cos(r))};}
    float[][] refHandles(){float sc=refScale(),w=referenceWidth*sc/2f,h=referenceHeight*sc/2f;return new float[][]{{-w,-h},{0,-h},{w,-h},{w,0},{w,h},{0,h},{-w,h},{-w,0}};}
    int frameAlpha(int color,int percent){return (Math.max(0,Math.min(100,percent))*255/100<<24)|(color&0x00ffffff);}
    void drawFrameDot(Canvas c,float x,float y,float radius){
      if(!frameDotsVisible)return;
      paint.setStyle(Paint.Style.FILL);paint.setColor(frameAlpha(frameDotColor,frameDotOpacity));c.drawCircle(x,y,radius,paint);
      paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(frameDotBorderThickness/10f));paint.setColor(frameAlpha(frameDotBorderColor,frameDotOpacity));c.drawCircle(x,y,radius,paint);
    }
    void drawReferenceHandles(Canvas c,float centerX,float centerY){float[] cc=refCenter();float w=referenceWidth*refScale()/2f,h=referenceHeight*refScale()/2f;
      c.save();c.rotate(referenceRotation,cc[0],cc[1]);
      paint.setShader(null);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(frameLineThickness/10f));paint.setColor(frameAlpha(frameLineColor,frameLineOpacity));
      c.drawRect(cc[0]-w,cc[1]-h,cc[0]+w,cc[1]+h,paint);
      c.drawLine(cc[0],cc[1]-h,cc[0],cc[1]-h-dp(30),paint);
      drawFrameDot(c,cc[0],cc[1]-h-dp(30),dp(frameDotSize/10f));
      for(float[] pt:refHandles())drawFrameDot(c,cc[0]+pt[0],cc[1]+pt[1],dp(frameDotSize/10f));
      paint.setStyle(Paint.Style.FILL);paint.setAlpha(255);c.restore();
    }
    public boolean onTouchEvent(MotionEvent e){
      if(previewOnly){
        int action=e.getActionMasked();
        if(action==MotionEvent.ACTION_DOWN){lastX=e.getX();lastY=e.getY();lastDist=0;return true;}
        if(action==MotionEvent.ACTION_POINTER_DOWN&&e.getPointerCount()>=2){lastDist=(float)Math.hypot(e.getX(0)-e.getX(1),e.getY(0)-e.getY(1));return true;}
        if(action==MotionEvent.ACTION_MOVE){
          if(e.getPointerCount()>=2){float d=(float)Math.hypot(e.getX(0)-e.getX(1),e.getY(0)-e.getY(1));if(lastDist>1)zoom=Math.max(.15f,Math.min(12f,zoom*d/lastDist));lastDist=d;}
          else {yaw+=(e.getX()-lastX)*.008f;pitch+=(e.getY()-lastY)*.008f;pitch=Math.max(-1.5f,Math.min(1.5f,pitch));lastX=e.getX();lastY=e.getY();}
          invalidate();return true;
        }
        if(action==MotionEvent.ACTION_POINTER_UP){lastDist=0;return true;}
        return true;
      }
      if(e.getActionMasked()==MotionEvent.ACTION_DOWN)uvNavigationFocus=false;
      if(referenceAdjustMode){
        int a=e.getActionMasked();
        if(a==MotionEvent.ACTION_DOWN){
          refTouchX=e.getX();refTouchY=e.getY();refDownX=refTouchX;refDownY=refTouchY;
          refStartX=referenceX;refStartY=referenceZ;refStartW=referenceWidth;refStartH=referenceHeight;refStartRotation=referenceRotation;refPinchDist=0;refDragMode=0;referenceGestureStart=referenceImage!=null?referenceSnapshot():null;
          if(referenceImage==null)return true;
          float[] local=refLocal(refTouchX,refTouchY);float w=referenceWidth*refScale()/2f,h=referenceHeight*refScale()/2f;
          float hit=dp(20),best=hit;
          float rotateDistance=(float)Math.hypot(local[0],local[1]+h+dp(30));
          if(rotateDistance<hit){refDragMode=10;float[] cc=refCenter();refLastAngle=(float)Math.atan2(refTouchY-cc[1],refTouchX-cc[0]);return true;}
          float[][] handles=refHandles();
          for(int i=0;i<handles.length;i++){float d=(float)Math.hypot(local[0]-handles[i][0],local[1]-handles[i][1]);if(d<best){best=d;refDragMode=i+2;}}
          if(refDragMode==0&&Math.abs(local[0])<=w&&Math.abs(local[1])<=h)refDragMode=1;
          return true;
        }
        if(a==MotionEvent.ACTION_POINTER_DOWN&&e.getPointerCount()>=2){refDragMode=11;refPinchDist=(float)Math.hypot(e.getX(0)-e.getX(1),e.getY(0)-e.getY(1));return true;}
        if(a==MotionEvent.ACTION_MOVE&&referenceImage!=null){
          if(refDragMode==11&&e.getPointerCount()>=2){float dist=(float)Math.hypot(e.getX(0)-e.getX(1),e.getY(0)-e.getY(1));if(refPinchDist>1){float ratio=dist/refPinchDist;referenceWidth=Math.max(.1f,Math.min(20f,referenceWidth*ratio));referenceHeight=Math.max(.1f,Math.min(20f,referenceHeight*ratio));}refPinchDist=dist;
          }else if(refDragMode==1){float sc=Math.max(.001f,refScale());referenceX+=(e.getX()-refTouchX)/sc;referenceZ-=(e.getY()-refTouchY)/sc;
          }else if(refDragMode==10){float[] cc=refCenter();float angle=(float)Math.atan2(e.getY()-cc[1],e.getX()-cc[0]);referenceRotation+=(float)Math.toDegrees(angle-refLastAngle);refLastAngle=angle;
          }else if(refDragMode>=2&&refDragMode<=9){
            // Use the gesture's original transform. Recomputing against the moving
            // centre on every frame makes the handle drift and the image shrink.
            float screenDx=e.getX()-refDownX,screenDy=e.getY()-refDownY;
            double r=Math.toRadians(refStartRotation);
            float dx=(float)((screenDx*Math.cos(r)+screenDy*Math.sin(r))/Math.max(.001f,refScale()));
            float dy=(float)((-screenDx*Math.sin(r)+screenDy*Math.cos(r))/Math.max(.001f,refScale()));
            int i=refDragMode-2;
            boolean left=i==0||i==6||i==7,right=i==2||i==3||i==4;
            boolean top=i==0||i==1||i==2,bottom=i==4||i==5||i==6;
            float dw=left?-dx:right?dx:0f,dh=top?-dy:bottom?dy:0f;
            // Side handles change only their own dimension. The opposite edge
            // remains anchored, just as in a photo editor.
            if(referenceKeepRatio&&(left||right)&&(top||bottom)){
              float fraction=Math.abs(dw/Math.max(refStartW,.001f))>=Math.abs(dh/Math.max(refStartH,.001f))
                  ?dw/Math.max(refStartW,.001f):dh/Math.max(refStartH,.001f);
              dw=refStartW*fraction;dh=refStartH*fraction;
            }
            referenceWidth=Math.max(.1f,Math.min(20f,refStartW+dw));
            referenceHeight=Math.max(.1f,Math.min(20f,refStartH+dh));
            float shiftX=(right?1:left?-1:0)*(referenceWidth-refStartW)/2f;
            float shiftY=(bottom?1:top?-1:0)*(referenceHeight-refStartH)/2f;
            referenceX=refStartX+(float)(shiftX*Math.cos(r)-shiftY*Math.sin(r));
            referenceZ=refStartY-(float)(shiftX*Math.sin(r)+shiftY*Math.cos(r));
          }
          refTouchX=e.getX();refTouchY=e.getY();invalidate();return true;
        }
        if(a==MotionEvent.ACTION_POINTER_UP){refDragMode=0;return true;}
        if(a==MotionEvent.ACTION_UP||a==MotionEvent.ACTION_CANCEL){commitReferenceGesture();refDragMode=0;refPinchDist=0;saveReferencePrefs();return true;}
        return true;
      }
      if(!(activeHair?hairVisible&&hairVertices:faceVisible&&faceVertices))return true;
      int act=e.getActionMasked();
      if(act==MotionEvent.ACTION_DOWN){
        downX=lastX=e.getX();downY=lastY=e.getY();
        long now=android.os.SystemClock.uptimeMillis();
        boolean dbl=now-lastTap<350&&Math.hypot(downX-tapX,downY-tapY)<dp(48);
        lastTap=now;tapX=downX;tapY=downY;
        positioning=dbl;selecting=false;dragging=false;changed=false;clearedByLongPress=false;axis=0;
        removeCallbacks(startBoxAfterPause);
        if(positioning){cursorX=downX;cursorY=Math.max(0,downY-dp(120));cursorWasMoved=false;cursorLastMotionX=downX;cursorLastMotionY=downY;}
        else if(!selected.isEmpty())axis=hitAxis(downX,downY);
        dragVertex=selected.isEmpty()?-1:selected.iterator().next();if(dragVertex>=0&&dragVertex<mesh.vertices.size())dragOrigin=mesh.vertices.get(dragVertex).clone();
        removeCallbacks(clearOnLongPress);
        if(!positioning&&axis==0&&!selected.isEmpty())postDelayed(clearOnLongPress,550);
        invalidate();return true;
      }
      if(act==MotionEvent.ACTION_MOVE){
        float x=e.getX(),y=e.getY();
        if(Math.hypot(x-downX,y-downY)>dp(8))removeCallbacks(clearOnLongPress);
        if(clearedByLongPress){lastX=x;lastY=y;return true;}
        if(positioning){
          if(Math.hypot(x-cursorLastMotionX,y-cursorLastMotionY)>dp(1)){cursorWasMoved=true;cursorLastMotionX=x;cursorLastMotionY=y;removeCallbacks(startBoxAfterPause);postDelayed(startBoxAfterPause,500);}
          cursorX=x;cursorY=Math.max(0,y-dp(120));invalidate();
        }else if(selecting){selX=x;selY=Math.max(0,y-dp(120));invalidate();}
        else if(!selected.isEmpty()){
          if(!changed&&Math.hypot(x-downX,y-downY)>dp(4)){pushUndo();changed=true;invalidate();}
          if(changed)dragging=true;
          if(changed){moveSelection(x-lastX,y-lastY);refreshTransformPanel();if(dragVertex>=0&&dragVertex<mesh.vertices.size()){float[] v=mesh.vertices.get(dragVertex);float dx=v[0]-dragOrigin[0],dy=v[1]-dragOrigin[1],dz=v[2]-dragOrigin[2];showMoveStatus(dx,dz,(float)Math.sqrt(dx*dx+dy*dy+dz*dz),false);}}
        }
        lastX=x;lastY=y;return true;
      }
      if(act==MotionEvent.ACTION_UP){
        removeCallbacks(clearOnLongPress);removeCallbacks(startBoxAfterPause);
        if(clearedByLongPress){dragging=false;changed=false;axis=0;invalidate();return true;}
        if(changed)restoreSelectionStatus();dragVertex=-1;dragging=false;axis=0;invalidate();
        if(selecting){selX=e.getX();selY=Math.max(0,e.getY()-dp(120));selectBox();selecting=false;invalidate();}
        else if(positioning){positioning=false;invalidate();}
        else if(!changed){
          int nearest=-1;float best=dp(18);
          for(int i=0;i<pts.length;i++){
            float dist=(float)Math.hypot(pts[i][0]-e.getX(),pts[i][1]-e.getY());
            if(dist<best){best=dist;nearest=i;}
          }
          if(nearest>=0){selected.clear();selected.add(nearest);sync3dToUv();status.setText("Selecionados: "+selected.size()+" / "+mesh.vertices.size()+" vértices");sync3dToUv();invalidate();}
        }
        return true;
      }
      if(act==MotionEvent.ACTION_CANCEL){removeCallbacks(clearOnLongPress);removeCallbacks(startBoxAfterPause);positioning=false;selecting=false;if(changed)restoreSelectionStatus();dragVertex=-1;dragging=false;axis=0;invalidate();invalidate();return true;}
      return true;
    }
  }

}
