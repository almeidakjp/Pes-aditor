package com.psp.facehaireditor;
import java.io.*;
import java.util.*;
import java.util.zip.*;

/** Experimental PSP BIN edge splitter. Input is never overwritten. */
public final class PspBinEdgeSplitter {
 static int u16(byte[] a,int p){return (a[p]&255)|((a[p+1]&255)<<8);}
 static int i16(byte[] a,int p){return (short)u16(a,p);}
 static int u32(byte[] a,int p){return u16(a,p)|(u16(a,p+2)<<16);}
 static void w16(byte[] a,int p,int v){a[p]=(byte)v;a[p+1]=(byte)(v>>>8);}
 static void w32(byte[] a,int p,int v){w16(a,p,v);w16(a,p+2,v>>>16);}
 static byte[] cat(byte[]... chunks)throws IOException{ByteArrayOutputStream o=new ByteArrayOutputStream();for(byte[] c:chunks)o.write(c);return o.toByteArray();}
 static byte[] slice(byte[] a,int s,int e){return Arrays.copyOfRange(a,s,e);}
 static byte[] unzip(byte[] compressed)throws Exception{InflaterInputStream in=new InflaterInputStream(new ByteArrayInputStream(compressed));ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toByteArray();}
 static byte[] zip(byte[] data)throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();DeflaterOutputStream d=new DeflaterOutputStream(out,new Deflater(9));d.write(data);d.close();return out.toByteArray();}
 static void check(boolean ok,String message)throws Exception{if(!ok)throw new Exception(message);}
 static byte[] repeated(int count)throws Exception{byte[] b=new byte[count*4];for(int i=0;i<count;i++){w16(b,i*4,3);w16(b,i*4+2,0x0404);}return b;}
 static byte[] indices(List<int[]> f)throws Exception{byte[] out=new byte[f.size()*6];int p=0;for(int[] t:f)for(int v:t){w16(out,p,v);p+=2;}return out;}
 static byte[] split(byte[] raw,int partNumber,int a,int b)throws Exception{
  check(partNumber>=1&&partNumber<=64,"Parte invalida");
  check(raw.length>=32,"BIN muito curto");
  byte[] d=unzip(slice(raw,32,raw.length));int root=u32(d,8);
  check(root>=0&&root+96<=d.length&&u32(d,root)==0xffff0003,"Root desconhecido");
  int at=root+u32(d,root+36);int num=u32(d,root+32);
  check(num>=1&&num<=64&&partNumber<=num,"Quantidade de partes invalida");
  for(int k=1;k<partNumber;k++){check(at+4<=d.length,"Parte fora do BIN");at+=u32(d,at);}
  check(at+256<=d.length,"Parte fora do BIN");int size=u32(d,at);
  check(size>=256&&at+size<=d.length,"Tamanho invalido");
  byte[] block=slice(d,at,at+size);int vo=u32(block,8),io=u32(block,12),count=u32(block,16),n=u16(block,92);
  check(u16(block,94)==14&&io-vo==n*14&&io+count*2<=size,"Layout incompatível");
  check(a>=0&&b>=0&&a<n&&b<n&&a!=b,"Aresta invalida");
  int first=u32(block,48);
  while(first+4<=vo&&(u32(block,first)>>>16)!=0x0404)first+=4;
  check(first<vo,"Comandos GPU nao encontrados");
  ArrayList<Integer> commands=new ArrayList<>();int q=first,total=0;
  while(q+4<=vo&&(u32(block,q)>>>16)==0x0404){int length=u16(block,q);commands.add(length);total+=length;q+=4;if(total>=count)break;}
  check(total==count,"Comandos GPU nao correspondem aos indices");
  int[] ids=new int[count];for(int i=0;i<count;i++){ids[i]=u16(block,io+i*2);check(ids[i]<n,"Indice invalido");}
  // Preserve unaffected GPU strips byte-for-byte in their index order.
  ArrayList<int[]> groups=new ArrayList<>();
  ArrayList<ArrayList<int[]>> groupFaces=new ArrayList<>();
  HashSet<Integer> affected=new HashSet<>();
  int cursor=0,hits=0,groupIndex=0;
  for(int length:commands){
   int[] group=Arrays.copyOfRange(ids,cursor,cursor+length);
   groups.add(group);
   ArrayList<int[]> fs=new ArrayList<>();
   for(int j=0;j<length-2;j++){
    int x=group[j],y=group[j+1],z=group[j+2];
    if((j&1)==1){int tmp=x;x=y;y=tmp;}
    if(x!=y&&y!=z&&x!=z){
     int[] f=new int[]{x,y,z};fs.add(f);
     if(contains(f,a)&&contains(f,b)){hits++;affected.add(groupIndex);}
    }
   }
   groupFaces.add(fs);cursor+=length;groupIndex++;
  }
  check(hits==2,"Aresta deve pertencer a exatamente dois triangulos; encontrados "+hits);
  ArrayList<Integer> outputCommands=new ArrayList<>();
  ByteArrayOutputStream outputIds=new ByteArrayOutputStream();
  for(int k=0;k<groups.size();k++){
   if(!affected.contains(k)){
    int[] group=groups.get(k);outputCommands.add(group.length);
    for(int id:group){outputIds.write(id&255);outputIds.write((id>>>8)&255);}
    continue;
   }
   for(int[] f:groupFaces.get(k)){
    if(contains(f,a)&&contains(f,b)){
     int c=-1,j=-1;
     for(int t=0;t<3;t++){if(f[t]!=a&&f[t]!=b)c=f[t];if(f[t]==a)j=t;}
     if(f[(j+1)%3]==b){appendFace(outputCommands,outputIds,a,n,c);appendFace(outputCommands,outputIds,n,b,c);}
     else{appendFace(outputCommands,outputIds,b,n,c);appendFace(outputCommands,outputIds,n,a,c);}
    }else appendFace(outputCommands,outputIds,f[0],f[1],f[2]);
   }
  }
  byte[] gpuCommands=new byte[outputCommands.size()*4];
  for(int k=0;k<outputCommands.size();k++){
   w16(gpuCommands,k*4,outputCommands.get(k));w16(gpuCommands,k*4+2,0x0404);
  }
  byte[] pre=cat(slice(block,0,first),gpuCommands,slice(block,q,vo));
  int newvo=pre.length,dvo=newvo-vo;
  byte[] records=slice(block,vo,io),rec=slice(records,b*14,(b+1)*14);
  for(int off:new int[]{0,2})w16(rec,off,(int)Math.rint((u16(records,a*14+off)+u16(records,b*14+off))/2.0));
  for(int off:new int[]{8,10,12})w16(rec,off,(int)Math.rint((i16(records,a*14+off)+i16(records,b*14+off))/2.0));
  records=cat(records,rec);int newio=newvo+records.length,dio=newio-io;
  byte[] out=cat(pre,records,outputIds.toByteArray(),slice(block,io+count*2,size));
  out=Arrays.copyOf(out,(out.length+15)&~15);
  w32(out,0,out.length);w32(out,8,newvo);w32(out,12,newio);w32(out,16,outputIds.size()/2);w16(out,92,n+1);
  for(int field:new int[]{48,52,56,60,64,68,72,76,80,84,88}){
   int v=u32(block,field);if(v>=io&&v<size)w32(out,field,v+dio);else if(v>=vo&&v<io)w32(out,field,v+dvo);
  }
  w32(out,0xcc,0x01000000+newvo-0xc8);w32(out,0xd0,0x02000000+newio-0xc8);
  int shift=out.length-size;byte[] result=cat(slice(d,0,at),out,slice(d,at+size,d.length));
  for(int field:new int[]{36,44,52,60,72,80,88,92}){int v=u32(result,root+field);if(v!=0&&root+v>=at+size)w32(result,root+field,v+shift);}
  w32(result,12,u32(result,12)+shift);
  byte[] packed=zip(result),header=slice(raw,0,32);w32(header,4,packed.length);w32(header,8,result.length);
  return cat(header,packed);
 }
 static void appendFace(ArrayList<Integer> commands,ByteArrayOutputStream out,int a,int b,int c){
  commands.add(3);
  for(int v:new int[]{a,b,c}){out.write(v&255);out.write((v>>>8)&255);}
 }
 static boolean contains(int[] f,int v){for(int x:f)if(x==v)return true;return false;}
}
