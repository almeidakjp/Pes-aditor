# v300 experimental: reconhecimento de todas as partes BIN

A validação de Dividir Aresta agora conta as partes declaradas no cabeçalho (root+32), em vez de apenas quatro. A reconstrução dinâmica aceita partes 1..N, sujeita às verificações do formato (stride 14, comandos GPU compatíveis, aresta compartilhada por dois triângulos).

**Não foi validado no PPSSPP para ID05997.** Faça cópia do BIN original.

```bash
cd ~ && unzip -oq /sdcard/Download/FaceHairEditorPSP_v300_Seis_Partes_Experimental.zip && cd FaceHairEditorPSP_v300_Seis_Partes_Experimental && bash gradlew assembleDebug && APK=$(find app/build/outputs/apk/debug -name '*.apk' -type f | head -1) && test -n "$APK" && cp "$APK" /sdcard/Download/FaceHairEditorPSP-v300.apk && test -s /sdcard/Download/FaceHairEditorPSP-v300.apk && ls -lh /sdcard/Download/FaceHairEditorPSP-v300.apk
```
